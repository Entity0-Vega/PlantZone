with open('css/styles.css', 'r', encoding='utf-8') as f:
    css = f.read()

classes_to_check = [
    'why-plants-section', 'section-why-plants',
    'best-plants-section', 'section-explore-plants',
    'loved-plants-section', 'section-loved-plants',
    'trending-section', 'section-trending',
    'news-section', 'section-news',
    'products-grid', 'loved-products-grid',
    'trending-bento-grid', 'news-grid'
]

for c in classes_to_check:
    print(f".{c}: count in CSS = {css.count('.' + c)}")
