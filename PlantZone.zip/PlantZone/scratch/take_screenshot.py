import os
import subprocess
import sys

chrome_path = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
screenshot_path = os.path.abspath("scratch/shot_pump_detail.png")
url = "http://localhost:8080/scratch/temp_pump_detail.html"

args = [
    chrome_path,
    "--headless",
    "--disable-gpu",
    "--window-size=1440,900",
    f"--screenshot={screenshot_path}",
    url
]

print("Running chrome...", args)
res = subprocess.run(args, capture_output=True, text=True)
print("Return code:", res.returncode)
print("Stdout:", res.stdout)
print("Stderr:", res.stderr)
print("Screenshot exists:", os.path.exists(screenshot_path))
