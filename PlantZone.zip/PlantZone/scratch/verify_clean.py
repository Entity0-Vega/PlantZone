import re

with open('js/app.js', 'r', encoding='utf-8') as f:
    js = f.read()
with open('index.html', 'r', encoding='utf-8') as f:
    idx = f.read()

js_ids = set(re.findall(r"getElementById\(['\"]([^'\"]+)['\"]\)", js))
idx_ids = set(re.findall(r'id=["\']([^"\']+)["\']', idx))

missing = js_ids - idx_ids
print(f"Total js IDs: {len(js_ids)}")
print(f"Total HTML IDs: {len(idx_ids)}")
print(f"Missing IDs in index.html ({len(missing)}): {missing}")
