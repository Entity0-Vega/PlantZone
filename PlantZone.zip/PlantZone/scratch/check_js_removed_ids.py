import sys
sys.stdout.reconfigure(encoding='utf-8')

with open('js/app.js', 'r', encoding='utf-8') as f:
    js = f.read()

import re
ids_to_check = ['detailBotanical', 'detailLocation', 'detailCareAdvice', 'detailRemoveBtn']

for i in ids_to_check:
    print(f"\n=== {i} in js/app.js ===")
    for m in re.finditer(rf'.{{0,50}}{i}.{{0,70}}', js):
        print(" ", m.group(0).strip())
