with open('scratch/test_assembled_index.html', 'r', encoding='utf-8') as f:
    content = f.read()

with open('index.html', 'w', encoding='utf-8') as f:
    f.write(content)

print(f"Successfully updated index.html! Bytes written: {len(content.encode('utf-8'))}")
