import sys
sys.stdout.reconfigure(encoding='utf-8')

with open('css/styles.css', 'r', encoding='utf-8') as f:
    css = f.read()

pos = css.find('.garden-detail-right')
if pos != -1:
    print(css[pos:pos+2500])
