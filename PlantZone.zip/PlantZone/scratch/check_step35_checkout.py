import sys
sys.stdout.reconfigure(encoding='utf-8')

with open('scratch/step35_index.html', 'r', encoding='utf-8') as f:
    text = f.read()

pos = text.find('checkoutBtn')
print("pos checkoutBtn in step35:", pos)
if pos != -1:
    print(text[pos-200:pos+300])
