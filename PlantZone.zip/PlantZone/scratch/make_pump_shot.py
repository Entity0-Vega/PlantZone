import os
import subprocess
import sys

sys.stdout.reconfigure(encoding='utf-8')

with open('index.html', 'r', encoding='utf-8') as f:
    html = f.read()

# Make garden modal active and detail view active
h = html.replace('class="garden-fullscreen-modal" id="gardenModal"', 'class="garden-fullscreen-modal active" id="gardenModal"')
h = h.replace('id="gardenOverviewView">', 'id="gardenOverviewView" style="display:none;">')
h = h.replace('id="gardenDetailView" style="display: none;">', 'id="gardenDetailView" style="display: block;">')

# Add auto-call to openPlantDetail(0)
trigger_script = """
<script>
window.addEventListener('load', function() {
  setTimeout(function() {
    if (typeof openPlantDetail === 'function') {
      openPlantDetail(0);
    }
  }, 300);
});
</script>
"""
h = h.replace('</body>', trigger_script + '\n</body>')

with open('temp_pump_detail.html', 'w', encoding='utf-8') as f:
    f.write(h)

print("temp_pump_detail.html created in root.")

chrome_path = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
screenshot_path = os.path.abspath("scratch/shot_pump_detail.png")
url = "http://localhost:8080/temp_pump_detail.html"

args = [
    chrome_path,
    "--headless",
    "--disable-gpu",
    "--window-size=1440,900",
    "--virtual-time-budget=2000",
    f"--screenshot={screenshot_path}",
    url
]

print("Running chrome...", args)
res = subprocess.run(args, capture_output=True, text=True)
print("Return code:", res.returncode)
print("Stderr:", res.stderr)
print("File size:", os.path.getsize(screenshot_path) if os.path.exists(screenshot_path) else 0)
