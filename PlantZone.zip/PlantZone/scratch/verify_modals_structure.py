import sys
sys.stdout.reconfigure(encoding='utf-8')

with open('scratch/garden_modals_extracted.html', 'r', encoding='utf-8') as f:
    text = f.read()

# Check open vs close divs
open_divs = text.count('<div')
close_divs = text.count('</div')
print(f"Open divs: {open_divs}, Close divs: {close_divs}")

# Check modals in it
import re
modals = re.findall(r'<div[^>]*id=["\']([^"\']+)["\']', text)
print("IDs in extracted garden modals:", modals)
