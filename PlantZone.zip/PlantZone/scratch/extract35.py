import json

with open(r'C:\Users\jyoti\.gemini\antigravity\brain\4ad97ca5-6190-40fa-a0b5-df67bba16f9a\.system_generated\logs\transcript_full.jsonl', 'r', encoding='utf-8') as f:
    for line in f:
        obj = json.loads(line)
        if obj.get('step_index') == 35:
            for tc in obj.get('tool_calls', []):
                if tc.get('name') == 'write_to_file':
                    c = tc['args']['CodeContent']
                    with open('scratch/step35_index.html', 'w', encoding='utf-8') as out:
                        out.write(c)
                    print("Saved scratch/step35_index.html, lines:", len(c.splitlines()))
