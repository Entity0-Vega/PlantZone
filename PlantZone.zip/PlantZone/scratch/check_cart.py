with open('scratch/step35_index.html', 'r', encoding='utf-8') as f:
    text = f.read()

pos = text.find('cartDrawer')
print("cartDrawer pos:", pos)
if pos != -1:
    print(text[pos-100:pos+800])
