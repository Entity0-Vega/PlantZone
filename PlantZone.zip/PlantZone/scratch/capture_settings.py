import subprocess
import time
import json
import urllib.request
import asyncio
import websockets
import tempfile
import base64
import http.server
import socketserver
import threading
import os

PORT = 5581

class QuietHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, format, *args):
        pass

def start_server():
    httpd = socketserver.TCPServer(("", PORT), QuietHandler)
    t = threading.Thread(target=httpd.serve_forever, daemon=True)
    t.start()
    return httpd

async def run():
    httpd = start_server()
    temp_dir = tempfile.mkdtemp()
    cdp_port = 9260
    chrome_path = r'C:\Program Files\Google\Chrome\Application\chrome.exe'
    
    cmd = [
        chrome_path,
        '--headless=new',
        f'--remote-debugging-port={cdp_port}',
        '--remote-allow-origins=*',
        f'--user-data-dir={temp_dir}',
        '--window-size=1440,1050',
        f'http://127.0.0.1:{PORT}/index.html'
    ]
    proc = subprocess.Popen(cmd)
    await asyncio.sleep(2.0)

    try:
        req = urllib.request.urlopen(f'http://localhost:{cdp_port}/json')
        tabs = json.loads(req.read().decode('utf-8'))
        page_tabs = [t for t in tabs if t.get('type') == 'page']
        ws_url = page_tabs[0]['webSocketDebuggerUrl']

        async with websockets.connect(ws_url) as ws:
            msg_id = 1
            async def send_cmd(method, params=None):
                nonlocal msg_id
                msg_id += 1
                payload = {'id': msg_id, 'method': method, 'params': params or {}}
                await ws.send(json.dumps(payload))
                while True:
                    resp = json.loads(await ws.recv())
                    if resp.get('id') == msg_id:
                        return resp.get('result', {})

            async def eval_js(expression):
                res = await send_cmd('Runtime.evaluate', {
                    'expression': expression,
                    'returnByValue': True,
                    'awaitPromise': True
                })
                return res.get('result', {}).get('value')

            await send_cmd('Page.enable')
            await send_cmd('Runtime.enable')
            await asyncio.sleep(0.5)

            # Dismiss blurContainer and open settings
            info = await eval_js('''
            (() => {
                const blur = document.getElementById('blurContainer');
                if (blur) blur.style.display = 'none';
                if (window.PlantZoneApp && window.PlantZoneApp.openSettings) {
                    window.PlantZoneApp.openSettings();
                } else {
                    document.getElementById('settingsBtn')?.click();
                }
                const modal = document.getElementById('settingsModal');
                const tabs = Array.from(document.querySelectorAll('.settings-tab-btn')).map(t => t.textContent.trim());
                return {
                    modalActive: modal ? modal.classList.contains('active') : false,
                    tabs: tabs
                };
            })()
            ''')
            print("Settings opened:", json.dumps(info, indent=2))
            await asyncio.sleep(0.5)

            # Capture Tab 1: Automation & Link
            shot1 = await send_cmd('Page.captureScreenshot', {'format': 'png'})
            with open('scratch/shot_settings_tab1_automation.png', 'wb') as f:
                f.write(base64.b64decode(shot1['data']))
            print("Saved scratch/shot_settings_tab1_automation.png")

            # Click Tab 2: Actuators & Safety
            await eval_js('''
            (() => {
                const tab2 = document.querySelector('[data-tab="tab-actuators"]');
                if (tab2) tab2.click();
            })()
            ''')
            await asyncio.sleep(0.4)
            shot2 = await send_cmd('Page.captureScreenshot', {'format': 'png'})
            with open('scratch/shot_settings_tab2_actuators.png', 'wb') as f:
                f.write(base64.b64decode(shot2['data']))
            print("Saved scratch/shot_settings_tab2_actuators.png")

            # Click Tab 3: IoT Simulator
            await eval_js('''
            (() => {
                const tab3 = document.querySelector('[data-tab="tab-simulation"]');
                if (tab3) tab3.click();
            })()
            ''')
            await asyncio.sleep(0.4)
            shot3 = await send_cmd('Page.captureScreenshot', {'format': 'png'})
            with open('scratch/shot_settings_tab3_simulator.png', 'wb') as f:
                f.write(base64.b64decode(shot3['data']))
            print("Saved scratch/shot_settings_tab3_simulator.png")

            # Click Tab 4: Data & Reset
            await eval_js('''
            (() => {
                const tab4 = document.querySelector('[data-tab="tab-data"]');
                if (tab4) tab4.click();
            })()
            ''')
            await asyncio.sleep(0.4)
            shot4 = await send_cmd('Page.captureScreenshot', {'format': 'png'})
            with open('scratch/shot_settings_tab4_data.png', 'wb') as f:
                f.write(base64.b64decode(shot4['data']))
            print("Saved scratch/shot_settings_tab4_data.png")

            # Test close button
            close_info = await eval_js('''
            (() => {
                const closeBtn = document.getElementById('closeSettingsBtn');
                closeBtn.click();
                return {
                    modalActive: document.getElementById('settingsModal')?.classList.contains('active')
                };
            })()
            ''')
            print("Modal active after close click:", close_info['modalActive'])
            assert not close_info['modalActive'], "Settings modal should close on closeBtn click"
            print("PASS: Close button works properly!")

    finally:
        proc.terminate()
        httpd.shutdown()

asyncio.run(run())
