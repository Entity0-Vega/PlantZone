import re
import os

with open('scratch/step35_index.html', 'r', encoding='utf-8') as f:
    s35 = f.read()

images = re.findall(r'<img[^>]+src=["\']([^"\']+)["\']', s35)
print(f"Total img tags in step35: {len(images)}")
missing = []
for img in set(images):
    if not os.path.exists(img):
        missing.append(img)

print(f"Missing images on disk ({len(missing)}):")
for m in missing:
    print(" ", m)
if not missing:
    print("ALL images in step35 exist on disk!")
