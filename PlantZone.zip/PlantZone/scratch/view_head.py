with open('scratch/step35_index.html', 'r', encoding='utf-8') as f:
    lines = f.readlines()

print("Lines 1-80:")
for i, l in enumerate(lines[:80], 1):
    print(f"{i:3d}: {l.rstrip()}")
