with open('js/app.js', 'r', encoding='utf-8') as f:
    js = f.read()

import re
for term in ['addPlantNavBtn', 'gardenNavBtn', 'openAddPlantModal', 'openGardenModal']:
    print(f"\n--- {term} ---")
    for m in re.finditer(rf'.{{0,100}}{term}.{{0,200}}', js):
        print(m.group(0))
