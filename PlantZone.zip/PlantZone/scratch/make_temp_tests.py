import sys
import subprocess
import time
sys.stdout.reconfigure(encoding='utf-8')

# We can create a test html that loads index.html's markup and executes openAddPlantWizard() on load!
with open('index.html', 'r', encoding='utf-8') as f:
    html = f.read()

# 1. Wizard on load
wizard_html = html.replace('</body>', '<script>window.addEventListener("DOMContentLoaded", () => { setTimeout(() => { const btn = document.getElementById("addPlantNavBtn"); if(btn) btn.click(); }, 300); });</script></body>')
with open('scratch/temp_wizard.html', 'w', encoding='utf-8') as f:
    f.write(wizard_html)

# 2. Garden dashboard on load
garden_html = html.replace('</body>', '<script>window.addEventListener("DOMContentLoaded", () => { setTimeout(() => { const btn = document.getElementById("gardenNavBtn"); if(btn) btn.click(); }, 300); });</script></body>')
with open('scratch/temp_garden.html', 'w', encoding='utf-8') as f:
    f.write(garden_html)

# 3. Garden detail inspection on load
detail_html = html.replace('</body>', '<script>window.addEventListener("DOMContentLoaded", () => { setTimeout(() => { const btn = document.getElementById("gardenNavBtn"); if(btn) btn.click(); setTimeout(() => { const card = document.querySelector("#gardenPlantsGrid .garden-plant-card"); if(card) card.click(); }, 200); }, 300); });</script></body>')
with open('scratch/temp_detail.html', 'w', encoding='utf-8') as f:
    f.write(detail_html)

print("Generated temp HTML test files!")
