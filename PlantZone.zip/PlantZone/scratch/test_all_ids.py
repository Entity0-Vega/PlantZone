import re

with open('scratch/garden_modals_extracted.html', 'r', encoding='utf-8') as f:
    modals = f.read()

with open('js/app.js', 'r', encoding='utf-8') as f:
    js = f.read()

js_ids = set(re.findall(r"getElementById\(['\"]([^'\"]+)['\"]\)", js))
modal_ids = set(re.findall(r'id=["\']([^"\']+)["\']', modals))

with open('scratch/step35_index.html', 'r', encoding='utf-8') as f:
    s35 = f.read()
s35_ids = set(re.findall(r'id=["\']([^"\']+)["\']', s35))

# Also what about the two nav items: addPlantNavBtn and gardenNavBtn?
nav_ids = {'addPlantNavBtn', 'gardenNavBtn', 'emptyCartShopBtn'}

all_accounted = s35_ids | modal_ids | nav_ids
missing = js_ids - all_accounted
print(f"Missing from (step35 + modals + nav_ids): {missing}")
