with open('index.html', 'r', encoding='utf-8') as f:
    text = f.read()

pos = text.find('id="gardenModal"')
print('pos:', pos)
if pos != -1:
    print(repr(text[pos-40:pos+40]))
