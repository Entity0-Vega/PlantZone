import sys
sys.stdout.reconfigure(encoding='utf-8')

with open('index.html', 'r', encoding='utf-8') as f:
    text = f.read()

pos = text.find('id="gardenDetailRight"')
if pos == -1:
    pos = text.find('class="garden-detail-right"')

print("pos gardenDetailRight:", pos)
if pos != -1:
    print(text[pos:pos+3500])
