import subprocess
import time
import json
import urllib.request
import asyncio
import websockets
import base64

async def run_tests():
    cmd = [
        r'C:\Program Files\Google\Chrome\Application\chrome.exe',
        '--headless',
        '--remote-debugging-port=9222',
        '--remote-allow-origins=*',
        '--window-size=1440,900',
        'about:blank'
    ]
    proc = subprocess.Popen(cmd)
    time.sleep(2)

    try:
        req = urllib.request.urlopen('http://localhost:9222/json')
        tabs = json.loads(req.read().decode('utf-8'))
        ws_url = tabs[0]['webSocketDebuggerUrl']

        async with websockets.connect(ws_url) as ws:
            msg_id = 1
            async def send_cmd(method, params=None):
                nonlocal msg_id
                msg_id += 1
                payload = {'id': msg_id, 'method': method, 'params': params or {}}
                await ws.send(json.dumps(payload))
                while True:
                    resp = json.loads(await ws.recv())
                    if resp.get('id') == msg_id:
                        return resp.get('result', {})

            await send_cmd('Page.enable')
            await send_cmd('Runtime.enable')
            await send_cmd('Page.navigate', {'url': 'http://localhost:8080/index.html'})
            await asyncio.sleep(2)

            # Test 1: Click + button in navbar
            print("Clicking #addPlantNavBtn...")
            res1 = await send_cmd('Runtime.evaluate', {
                'expression': '''
                (() => {
                    const btn = document.getElementById('addPlantNavBtn');
                    if (!btn) return 'NO_BTN';
                    btn.click();
                    const modal = document.getElementById('addGardenPlantModal');
                    return modal && modal.classList.contains('active') ? 'MODAL_ACTIVE' : 'MODAL_INACTIVE';
                })()
                '''
            })
            print("Result 1 (Add Plant Modal):", res1.get('result', {}).get('value'))

            shot1 = await send_cmd('Page.captureScreenshot')
            with open('scratch/test_add_plant_popup.png', 'wb') as f:
                f.write(base64.b64decode(shot1['data']))

            # Test 2: Select first plant in wizard step 1
            print("Selecting plant 1 in wizard...")
            res2 = await send_cmd('Runtime.evaluate', {
                'expression': '''
                (() => {
                    const firstCard = document.querySelector('#wizardPlantsGrid .wizard-plant-card');
                    if (!firstCard) return 'NO_CARD';
                    firstCard.click();
                    const step2 = document.getElementById('wizardStep2');
                    return step2 && step2.style.display !== 'none' ? 'STEP2_VISIBLE' : 'STEP2_HIDDEN';
                })()
                '''
            })
            print("Result 2 (Step 2 Visible):", res2.get('result', {}).get('value'))

            # Fill pot name and select sensor 1, then click Save
            print("Filling pot name and saving plant...")
            res3 = await send_cmd('Runtime.evaluate', {
                'expression': '''
                (() => {
                    const potInput = document.getElementById('wzPotNameInput');
                    if (potInput) {
                        potInput.value = 'Living Room Majesty';
                        potInput.dispatchEvent(new Event('input'));
                    }
                    const s1 = document.getElementById('soilSensor1Radio');
                    if (s1) {
                        s1.checked = true;
                        s1.dispatchEvent(new Event('change'));
                    }
                    const saveBtn = document.getElementById('wzSavePlantBtn');
                    if (saveBtn) saveBtn.click();
                    return 'SAVED';
                })()
                '''
            })
            print("Result 3 (Plant Saved):", res3.get('result', {}).get('value'))
            await asyncio.sleep(1)

            # Test 3: Open Garden Modal via navbar link
            print("Opening Garden Dashboard via #gardenNavBtn...")
            res4 = await send_cmd('Runtime.evaluate', {
                'expression': '''
                (() => {
                    const gBtn = document.getElementById('gardenNavBtn');
                    if (!gBtn) return 'NO_GBTN';
                    gBtn.click();
                    const gModal = document.getElementById('gardenModal');
                    return gModal && gModal.classList.contains('active') ? 'GARDEN_ACTIVE' : 'GARDEN_INACTIVE';
                })()
                '''
            })
            print("Result 4 (Garden Modal Active):", res4.get('result', {}).get('value'))

            shot2 = await send_cmd('Page.captureScreenshot')
            with open('scratch/test_garden_dashboard.png', 'wb') as f:
                f.write(base64.b64decode(shot2['data']))

            # Test 4: Click the plant card in Garden Dashboard to open Inspection View
            print("Clicking plant card in Garden to open Inspection view...")
            res5 = await send_cmd('Runtime.evaluate', {
                'expression': '''
                (() => {
                    const card = document.querySelector('#gardenPlantsGrid .garden-plant-card');
                    if (!card) return 'NO_GARDEN_CARD';
                    card.click();
                    const detailView = document.getElementById('gardenDetailView');
                    return detailView && detailView.style.display !== 'none' ? 'DETAIL_VISIBLE' : 'DETAIL_HIDDEN';
                })()
                '''
            })
            print("Result 5 (Detail View Visible):", res5.get('result', {}).get('value'))
            await asyncio.sleep(1)

            shot3 = await send_cmd('Page.captureScreenshot')
            with open('scratch/test_inspection_popup.png', 'wb') as f:
                f.write(base64.b64decode(shot3['data']))
            print("All screenshots successfully captured!")

    finally:
        proc.terminate()

asyncio.run(run_tests())
