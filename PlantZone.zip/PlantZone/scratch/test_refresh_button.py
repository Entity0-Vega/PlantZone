import subprocess
import time
import json
import urllib.request
import asyncio
import websockets
import tempfile
import os
import shutil
import http.server
import socketserver
import threading
import base64

PORT = 5592

class QuietHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, format, *args):
        pass

def start_server():
    httpd = socketserver.TCPServer(("", PORT), QuietHandler)
    t = threading.Thread(target=httpd.serve_forever, daemon=True)
    t.start()
    return httpd

async def run_tests():
    httpd = start_server()
    temp_dir = tempfile.mkdtemp()
    cdp_port = 9249
    chrome_path = r'C:\Program Files\Google\Chrome\Application\chrome.exe'
    
    cmd = [
        chrome_path,
        '--headless=new',
        f'--remote-debugging-port={cdp_port}',
        '--remote-allow-origins=*',
        f'--user-data-dir={temp_dir}',
        '--window-size=1440,900',
        f'http://127.0.0.1:{PORT}/index.html'
    ]
    proc = subprocess.Popen(cmd)
    await asyncio.sleep(2.0)

    try:
        req = urllib.request.urlopen(f'http://localhost:{cdp_port}/json')
        tabs = json.loads(req.read().decode('utf-8'))
        page_tabs = [t for t in tabs if t.get('type') == 'page']
        ws_url = page_tabs[0]['webSocketDebuggerUrl']

        async with websockets.connect(ws_url) as ws:
            msg_id = 1
            async def send_cmd(method, params=None):
                nonlocal msg_id
                msg_id += 1
                payload = {'id': msg_id, 'method': method, 'params': params or {}}
                await ws.send(json.dumps(payload))
                while True:
                    resp = json.loads(await ws.recv())
                    if resp.get('id') == msg_id:
                        return resp.get('result', {})

            async def eval_js(expression):
                res = await send_cmd('Runtime.evaluate', {
                    'expression': expression,
                    'returnByValue': True,
                    'awaitPromise': True
                })
                return res.get('result', {}).get('value')

            await send_cmd('Page.enable')
            await send_cmd('Runtime.enable')
            await asyncio.sleep(0.5)

            print("=== TEST 1: Inspect page opened and check Refresh + Close buttons ===")
            t1 = await eval_js('''
            (() => {
                // Open garden modal and inspect plant
                if (window.PlantZoneApp && window.PlantZoneApp.openGardenModal) {
                    window.PlantZoneApp.openGardenModal();
                    window.PlantZoneApp.openPlantDetail(0);
                } else {
                    document.getElementById('gardenNavBtn')?.click();
                    window.openPlantDetail(0);
                }

                const actions = document.getElementById('gardenFloatingActions');
                const refreshBtn = document.getElementById('btnRefreshInspect');
                const closeBtn = document.getElementById('closeGardenModalBtn');

                const rRect = refreshBtn ? refreshBtn.getBoundingClientRect() : null;
                const cRect = closeBtn ? closeBtn.getBoundingClientRect() : null;

                return {
                    actionsExists: !!actions,
                    refreshBtnExists: !!refreshBtn,
                    closeBtnExists: !!closeBtn,
                    refreshBtnText: refreshBtn?.querySelector('.refresh-btn-text')?.textContent,
                    rRect: rRect ? { top: rRect.top, left: rRect.left, width: rRect.width, height: rRect.height } : null,
                    cRect: cRect ? { top: cRect.top, left: cRect.left, width: cRect.width, height: cRect.height } : null,
                    detailVisible: document.getElementById('gardenDetailView')?.style.display !== 'none'
                };
            })()
            ''')
            print("Layout info:", json.dumps(t1, indent=2))
            assert t1['actionsExists'], "gardenFloatingActions container must exist"
            assert t1['refreshBtnExists'], "btnRefreshInspect must exist"
            assert t1['closeBtnExists'], "closeGardenModalBtn must exist"
            assert t1['refreshBtnText'] == "Refresh", f"Expected 'Refresh', got {t1['refreshBtnText']}"
            assert t1['rRect']['left'] < t1['cRect']['left'], "Refresh button should be to the left of Close button"
            print("PASS: Refresh and Close buttons are properly co-located in floating actions!")

            print("\n=== TEST 2: Click Refresh Button while Disconnected ===")
            t2 = await eval_js('''
            (() => {
                const btn = document.getElementById('btnRefreshInspect');
                btn.click();
                const isSpinning = btn.classList.contains('spinning');
                return { isSpinning };
            })()
            ''')
            print(f"Is spinning immediately on click: {t2['isSpinning']}")
            assert t2['isSpinning'], "Button should have spinning class"

            await asyncio.sleep(0.3)
            toast_info = await eval_js('''
            (() => {
                const toasts = Array.from(document.querySelectorAll('.toast'));
                return toasts.map(t => t.textContent);
            })()
            ''')
            print("Toasts displayed:", [t.encode('ascii', 'replace').decode() for t in toast_info])
            assert any("not connected" in t.lower() for t in toast_info), "Expected disconnected warning toast"
            print("PASS: Disconnected warning handled gracefully")

            await asyncio.sleep(0.8)
            t2_after = await eval_js('''
            (() => {
                const btn = document.getElementById('btnRefreshInspect');
                return { isSpinning: btn.classList.contains('spinning') };
            })()
            ''')
            assert not t2_after['isSpinning'], "Spinning class should be removed after 700ms"
            print("PASS: Spinning stopped cleanly after timer")

            print("\n=== TEST 3: Click Refresh Button with Hardware / Simulation Connected ===")
            t3 = await eval_js('''
            (() => {
                window.isSimulationMode = true;
                window.receivedSimCommands = [];
                const origSend = window.sendSimCommand;
                window.sendSimCommand = function(c) {
                    window.receivedSimCommands.push(c);
                    if (origSend) origSend(c);
                };

                const btn = document.getElementById('btnRefreshInspect');
                btn.click();
                return {
                    isSpinning: btn.classList.contains('spinning')
                };
            })()
            ''')
            print(f"Connected click spinning: {t3['isSpinning']}")
            assert t3['isSpinning'], "Button should spin"

            await asyncio.sleep(0.3)
            t3_check = await eval_js('''
            (() => {
                const toasts = Array.from(document.querySelectorAll('.toast')).map(t => t.textContent);
                return {
                    cmds: window.receivedSimCommands,
                    toasts: toasts,
                    moistureVal: document.getElementById('detailMoistureVal')?.textContent
                };
            })()
            ''')
            safe_t3 = {
                'cmds': t3_check['cmds'],
                'toasts': [t.encode('ascii', 'replace').decode() for t in t3_check['toasts']],
                'moistureVal': t3_check['moistureVal']
            }
            print("Command and toast info:", json.dumps(safe_t3, indent=2))
            assert 'S' in t3_check['cmds'], "Expected 'S' command dispatched"
            assert any("queried arduino" in t.lower() or "fresh telemetry" in t.lower() for t in t3_check['toasts']), "Expected success query toast"
            print("PASS: 'S' query command executed and telemetry updated!")

            # Take screenshot of inspect header with refresh and close button
            screenshot = await send_cmd('Page.captureScreenshot', {'format': 'png'})
            with open("scratch/shot_inspect_refresh_button.png", "wb") as f:
                f.write(base64.b64decode(screenshot['data']))
            print("PASS: Screenshot saved to scratch/shot_inspect_refresh_button.png")

            print("\n=== TEST 4: Close Button Closes Modal Cleanly ===")
            t4 = await eval_js('''
            (() => {
                const closeBtn = document.getElementById('closeGardenModalBtn');
                closeBtn.click();
                return {
                    modalActive: document.getElementById('gardenModal')?.classList.contains('active')
                };
            })()
            ''')
            print("Modal active after close click:", t4['modalActive'])
            assert not t4['modalActive'], "Modal should not be active after close click"
            print("PASS: Close button functioning smoothly!")

            print("\n=== ALL TESTS PASSED! ===")

    finally:
        proc.terminate()
        try:
            shutil.rmtree(temp_dir)
        except Exception:
            pass
        httpd.shutdown()

if __name__ == "__main__":
    asyncio.run(run_tests())
