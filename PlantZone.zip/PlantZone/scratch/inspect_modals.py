with open('scratch/step35_index.html', 'r', encoding='utf-8') as f:
    s35 = f.read()

# Let's inspect s35 lines and elements
print("step35 length:", len(s35))
print("step35 line count:", len(s35.splitlines()))

# Where does main page end and modals begin in step35?
# Search for modals in step35
import re
print("Modals in step35:")
for m in re.finditer(r'<div[^>]*class=["\'][^"\']*modal[^"\']*["\'][^>]*id=["\']([^"\']+)["\']', s35):
    print(" ", m.group(1))

# Modals in current index.html
with open('index.html', 'r', encoding='utf-8') as f:
    idx = f.read()
print("\nModals in current index.html:")
for m in re.finditer(r'<div[^>]*class=["\'][^"\']*modal[^"\']*["\'][^>]*id=["\']([^"\']+)["\']', idx):
    print(" ", m.group(1))

