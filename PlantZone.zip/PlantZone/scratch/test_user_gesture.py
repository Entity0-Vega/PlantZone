import subprocess
import time
import json
import urllib.request
import asyncio
import websockets
import tempfile
import shutil

async def run_tests():
    temp_dir = tempfile.mkdtemp()
    cmd = [
        r'C:\Program Files\Google\Chrome\Application\chrome.exe',
        '--headless=new',
        '--remote-debugging-port=9225',
        '--remote-allow-origins=*',
        f'--user-data-dir={temp_dir}',
        '--window-size=1440,900',
        'http://127.0.0.1:5500/index.html'
    ]
    proc = subprocess.Popen(cmd)
    time.sleep(3)

    try:
        req = urllib.request.urlopen('http://localhost:9225/json')
        tabs = json.loads(req.read().decode('utf-8'))
        page_tabs = [t for t in tabs if t.get('type') == 'page' and '5500' in t.get('url', '')]
        if not page_tabs:
            page_tabs = [t for t in tabs if t.get('type') == 'page']
        ws_url = page_tabs[0]['webSocketDebuggerUrl']

        async with websockets.connect(ws_url) as ws:
            msg_id = 1
            async def send_cmd(method, params=None):
                nonlocal msg_id
                msg_id += 1
                payload = {'id': msg_id, 'method': method, 'params': params or {}}
                await ws.send(json.dumps(payload))
                while True:
                    resp = json.loads(await ws.recv())
                    if resp.get('id') == msg_id:
                        return resp.get('result', {})

            await send_cmd('Page.enable')
            await send_cmd('Runtime.enable')
            await asyncio.sleep(1)

            print("--- Testing with userGesture: True ---")
            # Navigate to Arduino detail
            await send_cmd('Runtime.evaluate', {
                'expression': '''
                document.getElementById('userBtn').click();
                document.querySelector('.wallet[data-name="Arduino Nano"]').click();
                ''',
                'userGesture': True
            })
            await asyncio.sleep(0.5)

            # Click Connect with userGesture: True
            res = await send_cmd('Runtime.evaluate', {
                'expression': '''
                (() => {
                    const btn = document.getElementById('d-connect');
                    btn.click();
                    return btn.textContent;
                })()
                ''',
                'userGesture': True,
                'returnByValue': True
            })
            print("Connect button clicked with userGesture: True:", res)

            await asyncio.sleep(1)
            toast_res = await send_cmd('Runtime.evaluate', {
                'expression': 'document.getElementById("toast").textContent',
                'returnByValue': True
            })
            print("Toast output in headless (where native prompt appears or cancels):", toast_res.get('result', {}).get('value'))

    finally:
        proc.terminate()
        try:
            shutil.rmtree(temp_dir, ignore_errors=True)
        except:
            pass

asyncio.run(run_tests())
