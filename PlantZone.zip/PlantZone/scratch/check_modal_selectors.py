with open('css/styles.css', 'r', encoding='utf-8') as f:
    css = f.read()

import re
print("Matches for gardenModal:")
for m in re.finditer(r'.{0,40}gardenModal.{0,40}', css):
    print(" ", m.group(0))

print("\nMatches for addGardenPlantModal:")
for m in re.finditer(r'.{0,40}addGardenPlantModal.{0,40}', css):
    print(" ", m.group(0))

print("\nMatches for wizard:")
for m in re.finditer(r'.{0,40}wizard.{0,40}', css):
    print(" ", m.group(0))
