import subprocess
import time
import json
import urllib.request
import asyncio
import websockets
import base64
import os
import tempfile

async def main():
    user_data = tempfile.mkdtemp()
    chrome_cmd = [
        r'C:\Program Files\Google\Chrome\Application\chrome.exe',
        '--headless',
        '--remote-debugging-port=9222',
        '--remote-allow-origins=*',
        f'--user-data-dir={user_data}',
        '--window-size=1440,900',
        'about:blank'
    ]
    proc = subprocess.Popen(chrome_cmd)
    time.sleep(2)

    try:
        req = urllib.request.urlopen('http://127.0.0.1:9222/json')
        tabs = json.loads(req.read().decode('utf-8'))
        ws_url = tabs[0]['webSocketDebuggerUrl']

        async with websockets.connect(ws_url, max_size=20_000_000) as ws:
            msg_id = 1
            async def send_cmd(method, params=None):
                nonlocal msg_id
                msg_id += 1
                payload = {'id': msg_id, 'method': method, 'params': params or {}}
                await ws.send(json.dumps(payload))
                while True:
                    raw = await ws.recv()
                    resp = json.loads(raw)
                    if resp.get('id') == msg_id:
                        if 'error' in resp:
                            raise Exception(f"CDP Error in {method}: {resp['error']}")
                        return resp.get('result', {})

            await send_cmd('Page.enable')
            await send_cmd('Runtime.enable')
            await send_cmd('Page.navigate', {'url': 'http://127.0.0.1:5500/index.html'})
            await asyncio.sleep(2)

            # Test 1: Open Garden & Detail View
            print("--- Test 1: Open Garden Detail View ---", flush=True)
            res1 = await send_cmd('Runtime.evaluate', {
                'expression': '''
                (() => {
                    window.PlantZoneApp.openGardenModal();
                    window.PlantZoneApp.openPlantDetail(0);
                    const detail = document.getElementById('gardenDetailView');
                    const isVisible = detail && detail.style.display !== 'none';
                    const modeStrip = document.querySelector('.detail-mode-strip');
                    const waterBtn = document.getElementById('detailWaterBtn');
                    const modePill = document.getElementById('detailModePill');
                    const modeLabel = document.getElementById('detailModeLabel');
                    return JSON.stringify({
                        detailVisible: isVisible,
                        hasModeStrip: !!modeStrip,
                        hasWaterBtn: !!waterBtn,
                        waterBtnText: waterBtn ? waterBtn.innerText.replace(/\\s+/g, ' ').trim() : null,
                        modeLabelText: modeLabel ? modeLabel.textContent : null,
                        modePillClass: modePill ? modePill.className : null
                    });
                })()
                '''
            })
            val1 = json.loads(res1.get('result', {}).get('value', '{}'))
            print("Test 1 Result:", val1, flush=True)

            # Test 2: Mock Hardware Connection & Test Quick Water in Automatic Mode
            print("--- Test 2: Quick Water in Automatic Mode ---", flush=True)
            res2 = await send_cmd('Runtime.evaluate', {
                'expression': '''
                (() => {
                    window.sentCommands = [];
                    window.HardwareManager = {
                        isConnected: () => true,
                        isArduinoConnected: () => true,
                        isBluetoothConnected: () => false,
                        sendCommand: (cmd) => { window.sentCommands.push(cmd); return Promise.resolve(true); }
                    };

                    // Switch to Auto Mode
                    document.getElementById('btnDetailToggleAuto').click();
                    const autoModeLabel = document.getElementById('detailModeLabel').textContent;

                    // Click Quick Water Plant
                    document.getElementById('detailWaterBtn').click();
                    const toastMsg = document.getElementById('toast') ? document.getElementById('toast').textContent : null;

                    return JSON.stringify({
                        modeAfterToggle: autoModeLabel,
                        sentCommands: [...window.sentCommands],
                        toastText: toastMsg
                    });
                })()
                '''
            })
            val2 = json.loads(res2.get('result', {}).get('value', '{}'))
            print("Test 2 Result (Auto Mode Quick Water):", val2, flush=True)

            # Test 3: Test Quick Water in Manual Mode
            print("--- Test 3: Quick Water in Manual Mode ---", flush=True)
            res3 = await send_cmd('Runtime.evaluate', {
                'expression': '''
                (() => {
                    window.sentCommands = [];

                    // Switch to Manual Mode
                    document.getElementById('btnDetailToggleManual').click();
                    const manualModeLabel = document.getElementById('detailModeLabel').textContent;

                    // Click Quick Water Plant
                    document.getElementById('detailWaterBtn').click();
                    const toastMsg = document.getElementById('toast') ? document.getElementById('toast').textContent : null;

                    return JSON.stringify({
                        modeAfterToggle: manualModeLabel,
                        sentCommands: [...window.sentCommands],
                        toastText: toastMsg
                    });
                })()
                '''
            })
            val3 = json.loads(res3.get('result', {}).get('value', '{}'))
            print("Test 3 Result (Manual Mode Quick Water):", val3, flush=True)

            # Test 4: Verify Garden Overview Card Button
            print("--- Test 4: Garden Overview Card Quick Water Button ---", flush=True)
            res4 = await send_cmd('Runtime.evaluate', {
                'expression': '''
                (() => {
                    document.getElementById('btnBackToOverview').click();
                    const firstCardWaterBtn = document.querySelector('.btn-quick-water');
                    return JSON.stringify({
                        title: firstCardWaterBtn ? firstCardWaterBtn.getAttribute('title') : null,
                        text: firstCardWaterBtn ? firstCardWaterBtn.innerText.replace(/\\s+/g, ' ').trim() : null
                    });
                })()
                '''
            })
            val4 = json.loads(res4.get('result', {}).get('value', '{}'))
            print("Test 4 Result (Card Button):", val4, flush=True)

            # Test 5: Re-open Detail View & Capture Screenshot
            print("--- Test 5: Capture Screenshot of Detail View ---", flush=True)
            await send_cmd('Runtime.evaluate', {
                'expression': '''
                (() => {
                    window.PlantZoneApp.openPlantDetail(0);
                    document.getElementById('btnDetailToggleAuto').click();
                })()
                '''
            })
            await asyncio.sleep(1)

            shot = await send_cmd('Page.captureScreenshot', {'format': 'png'})
            shot_path = os.path.abspath('scratch/shot_quick_water_dual_mode.png')
            with open(shot_path, 'wb') as f:
                f.write(base64.b64decode(shot['data']))
            print("Screenshot saved to:", shot_path, "Exists:", os.path.exists(shot_path), flush=True)

            # Also copy to artifact directory
            artifact_path = r'C:\Users\jyoti\.gemini\antigravity\brain\08cfa30b-edc9-470f-a765-7d69d502529f\shot_quick_water_dual_mode.png'
            with open(artifact_path, 'wb') as f:
                f.write(base64.b64decode(shot['data']))
            print("Artifact screenshot saved to:", artifact_path, flush=True)

    finally:
        proc.terminate()
        proc.kill()

asyncio.run(main())
