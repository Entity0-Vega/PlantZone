with open('js/app.js', 'r', encoding='utf-8') as f:
    js = f.read()

import re
for m in re.finditer(r'.{0,60}emptyCartShopBtn.{0,60}', js):
    print("In js:", m.group(0))

with open('index.html', 'r', encoding='utf-8') as f:
    idx = f.read()
for m in re.finditer(r'.{0,60}emptyCartShopBtn.{0,60}', idx):
    print("In idx:", m.group(0))
