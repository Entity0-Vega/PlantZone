with open('index.html', 'r', encoding='utf-8') as f:
    html = f.read()

# 2. Garden
assert 'id="gardenModal"' in html
garden_html = html.replace('class="garden-fullscreen-modal" id="gardenModal"', 'class="garden-fullscreen-modal active" id="gardenModal"')
# Also call renderGarden on load in temp_garden
garden_html = garden_html.replace('</body>', '<script>window.addEventListener("DOMContentLoaded", () => { if(window.renderGarden) window.renderGarden(); });</script></body>')

with open('temp_garden.html', 'w', encoding='utf-8') as f:
    f.write(garden_html)

# 3. Garden Detail:
detail_html = garden_html.replace('id="gardenOverviewView">', 'id="gardenOverviewView" style="display:none;">')
detail_html = detail_html.replace('id="gardenDetailView" style="display: none;">', 'id="gardenDetailView" style="display: block;">')
with open('temp_detail.html', 'w', encoding='utf-8') as f:
    f.write(detail_html)

print("Created temp_garden.html and temp_detail.html with proper class replacement!")
