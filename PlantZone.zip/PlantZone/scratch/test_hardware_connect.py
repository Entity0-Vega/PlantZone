import subprocess
import time
import json
import urllib.request
import asyncio
import websockets
import tempfile
import shutil

async def run_tests():
    temp_dir = tempfile.mkdtemp()
    cmd = [
        r'C:\Program Files\Google\Chrome\Application\chrome.exe',
        '--headless=new',
        '--remote-debugging-port=9224',
        '--remote-allow-origins=*',
        f'--user-data-dir={temp_dir}',
        '--window-size=1440,900',
        'http://127.0.0.1:5500/index.html'
    ]
    proc = subprocess.Popen(cmd)
    time.sleep(3)

    try:
        req = urllib.request.urlopen('http://localhost:9224/json')
        tabs = json.loads(req.read().decode('utf-8'))
        page_tabs = [t for t in tabs if t.get('type') == 'page' and '5500' in t.get('url', '')]
        if not page_tabs:
            page_tabs = [t for t in tabs if t.get('type') == 'page']
        ws_url = page_tabs[0]['webSocketDebuggerUrl']

        async with websockets.connect(ws_url) as ws:
            msg_id = 1
            async def send_cmd(method, params=None):
                nonlocal msg_id
                msg_id += 1
                payload = {'id': msg_id, 'method': method, 'params': params or {}}
                await ws.send(json.dumps(payload))
                while True:
                    resp = json.loads(await ws.recv())
                    if resp.get('id') == msg_id:
                        return resp.get('result', {})

            await send_cmd('Page.enable')
            await send_cmd('Runtime.enable')
            await asyncio.sleep(2)

            print("--- Test 1: Verify Initial UI Structure (Zero UI alterations) ---")
            check_ui = await send_cmd('Runtime.evaluate', {
                'expression': '''
                (() => {
                    const connectBtn = document.getElementById('d-connect');
                    const blurContainer = document.getElementById('blurContainer');
                    const userBtn = document.getElementById('userBtn');
                    const wallets = document.querySelectorAll('.wallet');
                    return {
                        hasConnectBtn: !!connectBtn,
                        connectText: connectBtn ? connectBtn.textContent : null,
                        hasBlurContainer: !!blurContainer,
                        hasUserBtn: !!userBtn,
                        walletCount: wallets.length,
                        walletNames: Array.from(wallets).map(w => w.dataset.name)
                    };
                })()
                ''',
                'returnByValue': True
            })
            print("Initial UI Check:", json.dumps(check_ui.get('result', {}).get('value'), indent=2))

            print("\n--- Test 2: Open Connect Garden Modal & Select Arduino Nano ---")
            step2 = await send_cmd('Runtime.evaluate', {
                'expression': '''
                (() => {
                    const userBtn = document.getElementById('userBtn');
                    userBtn.click();
                    const arduinoBtn = document.querySelector('.wallet[data-name="Arduino Nano"]');
                    arduinoBtn.click();
                    const detailView = document.getElementById('detail-view');
                    const title = document.getElementById('d-title').textContent;
                    const connectBtn = document.getElementById('d-connect');
                    return {
                        detailVisible: detailView && !detailView.hidden,
                        title: title,
                        connectBtnText: connectBtn ? connectBtn.textContent : null
                    };
                })()
                ''',
                'returnByValue': True
            })
            print("Arduino Selection:", json.dumps(step2.get('result', {}).get('value'), indent=2))

            print("\n--- Test 3: Verify Chrome requestPort is called ONLY when clicking 'Connect' ---")
            step3 = await send_cmd('Runtime.evaluate', {
                'expression': '''
                (() => {
                    let requestPortCalled = false;
                    let openBaudRate = null;

                    // Mock navigator.serial
                    const mockStream = {
                        getReader() {
                            return {
                                read: () => new Promise(() => {}),
                                releaseLock: () => {}
                            };
                        }
                    };

                    const mockPort = {
                        readable: mockStream,
                        writable: {
                            getWriter() {
                                return {
                                    write: (chunk) => Promise.resolve(),
                                    releaseLock: () => {}
                                };
                            }
                        },
                        open: (opts) => {
                            openBaudRate = opts.baudRate;
                            return Promise.resolve();
                        },
                        close: () => Promise.resolve(),
                        addEventListener: () => {}
                    };

                    navigator.serial = {
                        requestPort: () => {
                            requestPortCalled = true;
                            return Promise.resolve(mockPort);
                        },
                        addEventListener: () => {}
                    };

                    // Click connect button
                    const connectBtn = document.getElementById('d-connect');
                    connectBtn.click();

                    return new Promise((resolve) => {
                        setTimeout(() => {
                            const toast = document.getElementById('toast');
                            resolve({
                                requestPortCalled,
                                openBaudRate,
                                newButtonText: connectBtn.textContent,
                                toastText: toast ? toast.textContent : null,
                                isConnected: window.HardwareManager.isArduinoConnected()
                            });
                        }, 200);
                    });
                })()
                ''',
                'awaitPromise': True,
                'returnByValue': True
            })
            print("Arduino Connect Click Result:", json.dumps(step3.get('result', {}).get('value'), indent=2))

            print("\n--- Test 4: Simulate Live Telemetry from Arduino ---")
            step4 = await send_cmd('Runtime.evaluate', {
                'expression': '''
                (() => {
                    // Send mock telemetry line as Arduino would send via Serial
                    window.PlantZoneApp.updateTelemetry({ sensorIndex: 0, moisture: 92, temperature: 25 });
                    const state = window.PlantZoneApp.getGardenState();
                    return {
                        plant1Moisture: state[0].moisture,
                        plant1Temp: state[0].temperature,
                        plant1LastWatered: state[0].lastWatered
                    };
                })()
                ''',
                'returnByValue': True
            })
            print("Telemetry Ingestion Result:", json.dumps(step4.get('result', {}).get('value'), indent=2))

            print("\n--- Test 5: Disconnect Arduino via button ---")
            step5 = await send_cmd('Runtime.evaluate', {
                'expression': '''
                (() => {
                    const connectBtn = document.getElementById('d-connect');
                    connectBtn.click(); // Should disconnect
                    return {
                        newButtonText: connectBtn.textContent,
                        isConnected: window.HardwareManager.isArduinoConnected()
                    };
                })()
                ''',
                'returnByValue': True
            })
            print("Arduino Disconnect Result:", json.dumps(step5.get('result', {}).get('value'), indent=2))

            print("\n--- Test 6: Go Back and Select Bluetooth ---")
            step6 = await send_cmd('Runtime.evaluate', {
                'expression': '''
                (() => {
                    document.getElementById('back').click();
                    const btBtn = document.querySelector('.wallet[data-name="Bluetooth"]');
                    btBtn.click();
                    const title = document.getElementById('d-title').textContent;
                    const connectBtn = document.getElementById('d-connect');
                    return {
                        title: title,
                        connectBtnText: connectBtn ? connectBtn.textContent : null
                    };
                })()
                ''',
                'returnByValue': True
            })
            print("Bluetooth Selection:", json.dumps(step6.get('result', {}).get('value'), indent=2))

            print("\n--- Test 7: Verify Chrome requestDevice is called ONLY when clicking 'Connect' ---")
            step7 = await send_cmd('Runtime.evaluate', {
                'expression': '''
                (() => {
                    let requestDeviceCalled = false;
                    let passedOptions = null;

                    const mockDevice = {
                        name: 'ESP32_Plant_Sensor',
                        addEventListener: () => {},
                        gatt: {
                            connected: true,
                            connect: () => Promise.resolve({
                                getPrimaryService: () => Promise.reject(new Error('Service discovery mock'))
                            }),
                            disconnect: () => {}
                        }
                    };

                    navigator.bluetooth = {
                        requestDevice: (opts) => {
                            requestDeviceCalled = true;
                            passedOptions = opts;
                            return Promise.resolve(mockDevice);
                        }
                    };

                    const connectBtn = document.getElementById('d-connect');
                    connectBtn.click();

                    return new Promise((resolve) => {
                        setTimeout(() => {
                            const toast = document.getElementById('toast');
                            resolve({
                                requestDeviceCalled,
                                acceptAllDevices: passedOptions ? passedOptions.acceptAllDevices : null,
                                hasOptionalServices: !!(passedOptions && passedOptions.optionalServices && passedOptions.optionalServices.length > 0),
                                newButtonText: connectBtn.textContent,
                                toastText: toast ? toast.textContent : null,
                                isConnected: window.HardwareManager.isBluetoothConnected()
                            });
                        }, 200);
                    });
                })()
                ''',
                'awaitPromise': True,
                'returnByValue': True
            })
            print("Bluetooth Connect Click Result:", json.dumps(step7.get('result', {}).get('value'), indent=2))

            print("\n--- Test 8: Back to List View - Verify Status and aria-pressed ---")
            step8 = await send_cmd('Runtime.evaluate', {
                'expression': '''
                (() => {
                    document.getElementById('back').click();
                    const btWallet = document.querySelector('.wallet[data-name="Bluetooth"]');
                    const ardWallet = document.querySelector('.wallet[data-name="Arduino Nano"]');
                    const status = document.getElementById('status');
                    return {
                        btAriaPressed: btWallet.getAttribute('aria-pressed'),
                        ardAriaPressed: ardWallet.getAttribute('aria-pressed'),
                        statusText: status.textContent
                    };
                })()
                ''',
                'returnByValue': True
            })
            print("List View Status Check:", json.dumps(step8.get('result', {}).get('value'), indent=2))

    finally:
        proc.terminate()
        try:
            shutil.rmtree(temp_dir, ignore_errors=True)
        except:
            pass

asyncio.run(run_tests())
