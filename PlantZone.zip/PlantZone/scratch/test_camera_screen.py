import subprocess
import time
import json
import urllib.request
import asyncio
import websockets
import tempfile
import os
import base64
import shutil

async def run_camera_test():
    temp_dir = tempfile.mkdtemp()
    port = 9240
    cmd = [
        r'C:\Program Files\Google\Chrome\Application\chrome.exe',
        '--headless=new',
        f'--remote-debugging-port={port}',
        '--remote-allow-origins=*',
        f'--user-data-dir={temp_dir}',
        '--window-size=1500,1200',
        'http://127.0.0.1:5500/index.html'
    ]
    proc = subprocess.Popen(cmd)
    await asyncio.sleep(2.5)

    try:
        req = urllib.request.urlopen(f'http://localhost:{port}/json')
        tabs = json.loads(req.read().decode('utf-8'))
        page_tabs = [t for t in tabs if t.get('type') == 'page']
        ws_url = page_tabs[0]['webSocketDebuggerUrl']

        async with websockets.connect(ws_url) as ws:
            msg_id = 1
            async def send_cmd(method, params=None):
                nonlocal msg_id
                msg_id += 1
                payload = {'id': msg_id, 'method': method, 'params': params or {}}
                await ws.send(json.dumps(payload))
                while True:
                    resp = json.loads(await ws.recv())
                    if resp.get('id') == msg_id:
                        return resp.get('result', {})

            async def eval_js(expression):
                res = await send_cmd('Runtime.evaluate', {
                    'expression': expression,
                    'returnByValue': True
                })
                return res.get('result', {}).get('value')

            await send_cmd('Page.enable')
            await send_cmd('Runtime.enable')
            await asyncio.sleep(1)

            print("--- STEP 1: Opening Garden Detail View ---")
            setup_res = await eval_js('''
            (() => {
                const blur = document.getElementById('blurContainer');
                if (blur) blur.style.display = 'none';
                if (window.PlantZoneApp) {
                    window.PlantZoneApp.openGardenModal();
                    window.PlantZoneApp.openPlantDetail(0);
                }
                const camScreen = document.getElementById('gardenCameraScreen');
                const detailSplit = document.querySelector('.garden-detail-split');
                const canvas = document.getElementById('plantCameraCanvas');
                
                // Check DOM placement: is camScreen next sibling or below garden-detail-split?
                const isBelow = detailSplit && camScreen && (detailSplit.compareDocumentPosition(camScreen) & Node.DOCUMENT_POSITION_FOLLOWING);
                const camRect = camScreen ? camScreen.getBoundingClientRect() : null;

                return {
                    detailVisible: document.getElementById('gardenDetailView')?.style.display !== 'none',
                    camExists: !!camScreen,
                    isBelowSplit: !!isBelow,
                    camWidth: camRect ? camRect.width : 0,
                    canvasReady: !!canvas && canvas.width > 0,
                    targetPlant: document.getElementById('camTargetPlantName')?.textContent,
                    parValue: document.getElementById('camParLight')?.textContent,
                    statusText: document.getElementById('camStatusText')?.textContent
                };
            })()
            ''')
            print("Setup result:", json.dumps(setup_res, indent=2))

            # Wait 1.5 seconds for canvas to render initial simulated plant
            await asyncio.sleep(1.5)

            print("\n--- STEP 2: Testing Controls (Zoom, Light, HUD, Filter) ---")
            controls_res = await eval_js('''
            (() => {
                // Test Zoom
                const btnZoom = document.getElementById('btnCycleZoom');
                if (btnZoom) btnZoom.click();
                const zoomVal = document.getElementById('zoomBtnLabel')?.textContent;

                // Test Grow Light
                const btnLight = document.getElementById('btnToggleCamLight');
                if (btnLight) btnLight.click();
                const lightActive = btnLight?.classList.contains('active');

                // Test NDVI Filter
                const ndviBtn = document.querySelector('.cam-filter-btn[data-filter="ndvi"]');
                if (ndviBtn) ndviBtn.click();
                const ndviActive = ndviBtn?.classList.contains('active');

                return {
                    zoomVal,
                    lightActive,
                    ndviActive
                };
            })()
            ''')
            print("Controls test result:", json.dumps(controls_res, indent=2))

            await asyncio.sleep(0.8)

            print("\n--- STEP 3: Testing Capture & AI Diagnostic Scan ---")
            capture_res = await eval_js('''
            (() => {
                // Switch back to RGB filter for crystal clear capture
                const rgbBtn = document.querySelector('.cam-filter-btn[data-filter="rgb"]');
                if (rgbBtn) rgbBtn.click();

                // Trigger Capture
                const btnCapture = document.getElementById('btnCameraCapture');
                if (btnCapture) btnCapture.click();

                const drawer = document.getElementById('camDiagnosticDrawer');
                const thumb = document.getElementById('diagnosticThumbImg');
                const score = document.getElementById('diagScoreVal');
                const heading = document.getElementById('diagScoreHeading');
                const advice = document.getElementById('diagAdvice');
                const downloadBtn = document.getElementById('btnDownloadSnapshot');

                return {
                    drawerVisible: drawer && drawer.style.display !== 'none',
                    thumbSrcLength: thumb?.src?.length || 0,
                    vigorScore: score?.textContent,
                    scoreHeading: heading?.textContent,
                    adviceText: advice?.textContent,
                    downloadHrefLength: downloadBtn?.href?.length || 0,
                    downloadFilename: downloadBtn?.download
                };
            })()
            ''')
            print("Capture test result:", json.dumps(capture_res, indent=2))

            await asyncio.sleep(1.0)

            print("\n--- STEP 4: Scroll Camera Screen into Focus and Take Screenshot ---")
            await eval_js('''
            (() => {
                const screen = document.getElementById('gardenCameraScreen');
                if (screen) {
                    screen.scrollIntoView({ behavior: 'instant', block: 'center' });
                }
            })()
            ''')
            await asyncio.sleep(0.8)

            # Capture CDP screenshot
            screenshot = await send_cmd('Page.captureScreenshot', {
                'format': 'png',
                'quality': 100
            })

            img_bytes = base64.b64decode(screenshot['data'])
            out_path = os.path.join(os.getcwd(), 'scratch', 'shot_camera_screen.png')
            with open(out_path, 'wb') as f:
                f.write(img_bytes)
            print(f"Screenshot successfully saved to {out_path} ({len(img_bytes)} bytes)")

            # Also copy to artifacts directory
            artifact_dir = r'C:\Users\jyoti\.gemini\antigravity\brain\52c49c00-c104-4019-8289-904347d80f07'
            if os.path.exists(artifact_dir):
                dest_path = os.path.join(artifact_dir, 'shot_camera_screen.png')
                shutil.copyfile(out_path, dest_path)
                print(f"Copied screenshot to artifact directory: {dest_path}")

    finally:
        proc.terminate()
        try:
            proc.wait(timeout=2)
        except:
            proc.kill()

if __name__ == '__main__':
    asyncio.run(run_camera_test())
