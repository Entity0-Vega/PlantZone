import subprocess
import time
import json
import urllib.request
import asyncio
import websockets
import tempfile
import shutil

async def run_tests():
    temp_dir = tempfile.mkdtemp()
    cmd = [
        r'C:\Program Files\Google\Chrome\Application\chrome.exe',
        '--headless=new',
        '--remote-debugging-port=9228',
        '--remote-allow-origins=*',
        f'--user-data-dir={temp_dir}',
        '--window-size=1440,900',
        'http://127.0.0.1:5500/index.html'
    ]
    proc = subprocess.Popen(cmd)
    time.sleep(3)

    try:
        req = urllib.request.urlopen('http://localhost:9228/json')
        tabs = json.loads(req.read().decode('utf-8'))
        page_tabs = [t for t in tabs if t.get('type') == 'page' and '5500' in t.get('url', '')]
        if not page_tabs:
            page_tabs = [t for t in tabs if t.get('type') == 'page']
        ws_url = page_tabs[0]['webSocketDebuggerUrl']

        async with websockets.connect(ws_url) as ws:
            msg_id = 1
            async def send_cmd(method, params=None):
                nonlocal msg_id
                msg_id += 1
                payload = {'id': msg_id, 'method': method, 'params': params or {}}
                await ws.send(json.dumps(payload))
                while True:
                    resp = json.loads(await ws.recv())
                    if resp.get('id') == msg_id:
                        return resp.get('result', {})

            await send_cmd('Page.enable')
            await send_cmd('Runtime.enable')
            await asyncio.sleep(1)

            print("--- Testing: After Pair Button Text and Go to Garden action ---")
            test_res = await send_cmd('Runtime.evaluate', {
                'expression': '''
                (async () => {
                    const mockPort = {
                        readable: {
                            getReader() {
                                return {
                                    read: () => new Promise(() => {}),
                                    releaseLock: () => {}
                                };
                            }
                        },
                        writable: {
                            getWriter() {
                                return {
                                    write: () => Promise.resolve(),
                                    releaseLock: () => {}
                                };
                            }
                        },
                        open: () => Promise.resolve(),
                        close: () => Promise.resolve(),
                        addEventListener: () => {}
                    };

                    Object.defineProperty(navigator, 'serial', {
                        value: {
                            requestPort: () => Promise.resolve(mockPort),
                            addEventListener: () => {}
                        },
                        configurable: true
                    });

                    // 1. Open modal & select Arduino Nano
                    document.getElementById('userBtn').click();
                    document.querySelector('.wallet[data-name="Arduino Nano"]').click();

                    const connectBtn = document.getElementById('d-connect');
                    const textBefore = connectBtn.textContent;

                    // 2. Click Connect to Pair
                    connectBtn.click();
                    await new Promise(r => setTimeout(r, 200));

                    const textAfterPair = connectBtn.textContent;

                    // 3. Click the button again (now saying "Connected, Go to Garden")
                    connectBtn.click();
                    await new Promise(r => setTimeout(r, 300));

                    const gardenModal = document.getElementById('gardenModal');
                    const blurContainer = document.getElementById('blurContainer');

                    const isGardenActive = gardenModal && gardenModal.classList.contains('active');
                    const isBlurHidden = !blurContainer || blurContainer.style.display === 'none' || blurContainer.classList.contains('remove');

                    return {
                        textBefore,
                        textAfterPair,
                        isGardenActive,
                        isBlurHidden
                    };
                })()
                ''',
                'awaitPromise': True,
                'returnByValue': True
            })
            print("Result:", json.dumps(test_res.get('result', {}).get('value'), indent=2))

    finally:
        proc.terminate()
        try:
            shutil.rmtree(temp_dir, ignore_errors=True)
        except:
            pass

asyncio.run(run_tests())
