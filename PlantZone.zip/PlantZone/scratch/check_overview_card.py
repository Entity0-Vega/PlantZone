import sys
sys.stdout.reconfigure(encoding='utf-8')

with open('js/app.js', 'r', encoding='utf-8') as f:
    text = f.read()

pos = text.find('gardenPlantsGrid.innerHTML')
if pos != -1:
    print(text[pos:pos+1500])
