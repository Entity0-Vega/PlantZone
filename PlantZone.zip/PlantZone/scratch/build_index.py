import sys
import re
sys.stdout.reconfigure(encoding='utf-8')

# 1. Read step35_index.html
with open('scratch/step35_index.html', 'r', encoding='utf-8') as f:
    s35 = f.read()

# Fix em-dash in title if needed
s35 = s35.replace('PlantZone \ufffd Bring Nature Home', 'PlantZone — Bring Nature Home')
s35 = s35.replace('PlantZone \u2014 Bring Nature Home', 'PlantZone — Bring Nature Home')

# 2. Add garden link in navMenu
target_nav = '<a href="#footer" class="nav-link">Contact Us</a>'
replacement_nav = '''<a href="#footer" class="nav-link">Contact Us</a>
        <a href="#garden" class="nav-link nav-link-garden" id="gardenNavBtn">Garden</a>'''
assert target_nav in s35, "target_nav not found in step35"
s35 = s35.replace(target_nav, replacement_nav, 1)

# 3. Add '+' button in nav-actions
target_actions = '<div class="nav-actions">\n        <!-- Search Trigger -->'
replacement_actions = '''<div class="nav-actions">
        <!-- Add Plant to Garden Trigger (+) -->
        <button class="icon-btn add-plant-nav-btn" id="addPlantNavBtn" aria-label="Add plants to your garden" title="Add plants to your garden">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round">
            <line x1="12" y1="5" x2="12" y2="19"></line>
            <line x1="5" y1="12" x2="19" y2="12"></line>
          </svg>
        </button>

        <!-- Search Trigger -->'''
assert target_actions in s35, "target_actions not found in step35"
s35 = s35.replace(target_actions, replacement_actions, 1)

# 4. Add emptyCartShopBtn in cart drawer
target_cart_btn = '<button class="btn btn-primary btn-block" id="checkoutBtn">Proceed to Checkout</button>'
replacement_cart_btn = '''<button class="btn btn-primary btn-block" id="checkoutBtn">Proceed to Checkout</button>
      <button class="btn btn-outline" id="emptyCartShopBtn" style="display:none; width:100%; margin-top:10px;">Explore Plants</button>'''
assert target_cart_btn in s35, "target_cart_btn not found in step35"
s35 = s35.replace(target_cart_btn, replacement_cart_btn, 1)

# 5. Read extracted garden modals
with open('scratch/garden_modals_extracted.html', 'r', encoding='utf-8') as f:
    garden_modals = f.read().strip()

# 6. Insert garden modals before <script src="js/app.js"></script>
target_script = '<script src="js/app.js"></script>'
assert target_script in s35, "target_script not found in step35"

final_html = s35.replace(target_script, f"{garden_modals}\n\n  {target_script}", 1)

with open('scratch/test_assembled_index.html', 'w', encoding='utf-8') as f:
    f.write(final_html)

print("Saved scratch/test_assembled_index.html!")
print(f"Total lines: {len(final_html.splitlines())}, total chars: {len(final_html)}")
