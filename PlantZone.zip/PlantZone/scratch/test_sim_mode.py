import subprocess
import time
import json
import urllib.request
import asyncio
import websockets
import tempfile
import os
import base64

async def run_tests():
    temp_dir = tempfile.mkdtemp()
    port = 9232
    cmd = [
        r'C:\Program Files\Google\Chrome\Application\chrome.exe',
        '--headless=new',
        f'--remote-debugging-port={port}',
        '--remote-allow-origins=*',
        f'--user-data-dir={temp_dir}',
        '--window-size=1440,1100',
        'http://127.0.0.1:5500/index.html'
    ]
    proc = subprocess.Popen(cmd)
    await asyncio.sleep(2.5)

    try:
        req = urllib.request.urlopen(f'http://localhost:{port}/json')
        tabs = json.loads(req.read().decode('utf-8'))
        page_tabs = [t for t in tabs if t.get('type') == 'page']
        ws_url = page_tabs[0]['webSocketDebuggerUrl']

        async with websockets.connect(ws_url) as ws:
            msg_id = 1
            async def send_cmd(method, params=None):
                nonlocal msg_id
                msg_id += 1
                payload = {'id': msg_id, 'method': method, 'params': params or {}}
                await ws.send(json.dumps(payload))
                while True:
                    resp = json.loads(await ws.recv())
                    if resp.get('id') == msg_id:
                        return resp.get('result', {})

            async def eval_js(expression):
                res = await send_cmd('Runtime.evaluate', {
                    'expression': expression,
                    'returnByValue': True
                })
                return res.get('result', {}).get('value')

            await send_cmd('Page.enable')
            await send_cmd('Runtime.enable')
            await asyncio.sleep(1)

            print("1. Opening Settings Modal...")
            s1 = await eval_js('''
            (() => {
                const blur = document.getElementById('blurContainer');
                if (blur) blur.style.display = 'none';
                if (window.PlantZoneApp) {
                    window.PlantZoneApp.openSettings();
                }
                const modal = document.getElementById('settingsModal');
                return {
                    opened: modal && modal.classList.contains('active'),
                    simPill: document.getElementById('settingSimPill')?.textContent,
                    simThreshold: document.getElementById('simAutoThreshold')?.value,
                    simThresholdLabel: document.getElementById('simAutoThresholdVal')?.textContent,
                    evapVal: document.getElementById('simEvapRate')?.value
                };
            })()
            ''')
            print("Settings State:", json.dumps(s1, indent=2))

            print("2. Starting Virtual Simulation...")
            s2 = await eval_js('''
            (() => {
                const btn = document.getElementById('btnToggleSimulation');
                if (btn) btn.click();
                return {
                    isSimMode: window.isSimulationMode,
                    simPillText: document.getElementById('settingSimPill')?.textContent,
                    btnText: btn?.textContent.trim(),
                    hwPillText: document.getElementById('settingsHwPill')?.textContent,
                    termLogLatest: document.getElementById('simTerminal')?.lastElementChild?.textContent
                };
            })()
            ''')
            print("After Start Sim:", json.dumps(s2, indent=2))

            await asyncio.sleep(2)

            print("3. Testing Step Telemetry Pulse...")
            s3 = await eval_js('''
            (() => {
                const stepBtn = document.getElementById('btnSimStepOnce');
                if (stepBtn) stepBtn.click();
                return {
                    termLines: document.getElementById('simTerminal')?.children.length,
                    latestLog: document.getElementById('simTerminal')?.lastElementChild?.textContent
                };
            })()
            ''')
            print("Telemetry Pulse:", json.dumps(s3, indent=2))

            print("4. Testing Soil Moisture Slider...")
            s4 = await eval_js('''
            (() => {
                const slider1 = document.getElementById('simSoil1Range');
                slider1.value = 54;
                slider1.dispatchEvent(new Event('input'));
                return {
                    slider1Val: slider1.value,
                    labelVal: document.getElementById('simSoil1Val')?.textContent,
                    plant1Moisture: window.PlantZoneApp?.getGardenState()[0]?.moisture
                };
            })()
            ''')
            print("Soil Slider Update:", json.dumps(s4, indent=2))

            print("5. Testing Climate Preset...")
            s5 = await eval_js('''
            (() => {
                const ghBtn = Array.from(document.querySelectorAll('.sim-preset-btn')).find(b => b.textContent.includes('Greenhouse'));
                if (ghBtn) ghBtn.click();
                return {
                    climateLabel: document.getElementById('simClimateLabel')?.textContent,
                    customTemp: document.getElementById('simCustomTempVal')?.textContent,
                    customHum: document.getElementById('simCustomHumVal')?.textContent
                };
            })()
            ''')
            print("Climate Preset:", json.dumps(s5, indent=2))

            print("6. Testing Fault Injection (Sensor 1 & DHT11)...")
            s6 = await eval_js('''
            (() => {
                const f1 = document.getElementById('simFaultSensor1');
                f1.checked = true;
                f1.dispatchEvent(new Event('change'));
                return {
                    plant1Fault: window.PlantZoneApp?.getGardenState()[0]?.isFaulty,
                    latestLog: document.getElementById('simTerminal')?.lastElementChild?.textContent
                };
            })()
            ''')
            print("Fault Injection:", json.dumps(s6, indent=2))

            print("7. Testing Quick Scenario Drought & Auto-Irrigation Trigger...")
            s7 = await eval_js('''
            (() => {
                const f1 = document.getElementById('simFaultSensor1');
                f1.checked = false;
                f1.dispatchEvent(new Event('change'));

                const autoBtn = document.getElementById('btnSetAutoMode');
                if (autoBtn) autoBtn.click();

                const dBtn = document.getElementById('btnScenarioDrought');
                if (dBtn) dBtn.click();

                return {
                    mode: window.arduinoMode,
                    s1: document.getElementById('simSoil1Range')?.value,
                    s2: document.getElementById('simSoil2Range')?.value
                };
            })()
            ''')
            print("Drought Scenario:", json.dumps(s7, indent=2))

            print("Waiting for auto-irrigation detection (3 seconds)...")
            await asyncio.sleep(3.2)

            s8 = await eval_js('''
            (() => {
                const logs = Array.from(document.getElementById('simTerminal')?.children || []).map(c => c.textContent);
                const autoTriggerLog = logs.find(l => l.includes('AUTO-IRRIGATION') || l.includes('Relay IN1'));
                return {
                    foundAutoLog: !!autoTriggerLog,
                    logSnippet: autoTriggerLog,
                    currentS1: document.getElementById('simSoil1Range')?.value
                };
            })()
            ''')
            print("Auto-Irrigation Trigger:", json.dumps(s8, indent=2))

            print("8. Testing Manual Pump Actuator Diagnostic...")
            s9 = await eval_js('''
            (() => {
                const testBtn = document.getElementById('btnTestPump1');
                if (testBtn) testBtn.click();
                return {
                    pump1CircleActive: document.getElementById('pumpCircle1')?.classList.contains('pump-watering-active'),
                    latestLog: document.getElementById('simTerminal')?.lastElementChild?.textContent
                };
            })()
            ''')
            print("Manual Pump 1 Pulse:", json.dumps(s9, indent=2))

            # Scroll settings modal to simulation section for a screenshot
            await eval_js('''
            (() => {
                const sec = document.querySelector('.simulation-section');
                if (sec) sec.scrollIntoView({ behavior: 'instant', block: 'center' });
            })()
            ''')
            await asyncio.sleep(0.5)

            # Capture Screenshot
            print("9. Capturing Screenshot of Simulation Section in Settings...")
            scr = await send_cmd('Page.captureScreenshot', {'format': 'png'})
            img_data = base64.b64decode(scr['data'])
            os.makedirs('scratch', exist_ok=True)
            with open('scratch/shot_settings_simulation.png', 'wb') as f:
                f.write(img_data)
            print("Saved scratch/shot_settings_simulation.png successfully!")

            print("10. Testing Scenario Reset & Stop Simulation...")
            s10 = await eval_js('''
            (() => {
                const resetBtn = document.getElementById('btnScenarioReset');
                if (resetBtn) resetBtn.click();
                const toggleBtn = document.getElementById('btnToggleSimulation');
                if (toggleBtn) toggleBtn.click();
                return {
                    isSimMode: window.isSimulationMode,
                    simPill: document.getElementById('settingSimPill')?.textContent,
                    hwPill: document.getElementById('settingsHwPill')?.textContent
                };
            })()
            ''')
            print("Stop Simulation Result:", json.dumps(s10, indent=2))

    finally:
        proc.kill()

if __name__ == '__main__':
    asyncio.run(run_tests())
