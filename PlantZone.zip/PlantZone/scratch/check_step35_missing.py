import re

with open('scratch/step35_index.html', 'r', encoding='utf-8') as f:
    s35 = f.read()

with open('js/app.js', 'r', encoding='utf-8') as f:
    js = f.read()

js_ids = set(re.findall(r"getElementById\(['\"]([^'\"]+)['\"]\)", js))
s35_ids = set(re.findall(r'id=["\']([^"\']+)["\']', s35))

missing = js_ids - s35_ids
print(f"Missing from step35 ({len(missing)}):")
for m in sorted(missing):
    print(" ", m)
