import re

with open('scratch/step35_index.html', 'r', encoding='utf-8') as f:
    s35 = f.read()
with open('index.html', 'r', encoding='utf-8') as f:
    idx = f.read()

def get_sections(html):
    return re.findall(r'<section[^>]*class=["\']([^"\']+)["\']', html)

print("step35 sections:", get_sections(s35))
print("index.html sections:", get_sections(idx))

# Compare lines or major elements
s35_lines = s35.splitlines()
idx_lines = idx.splitlines()
print(f"step35 lines: {len(s35_lines)}, index.html lines: {len(idx_lines)}")

# Let's see what is inside index.html up to the modals
# Where does modal start in index.html?
pos_modal_idx = idx.find('addGardenPlantModal')
print("addGardenPlantModal in index.html at char:", pos_modal_idx)

# Check if index.html before modals is identical or different from step35
print("Difference before modals?")
# Let's compare the header, hero, etc.
