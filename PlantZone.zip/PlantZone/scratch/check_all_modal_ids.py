import re

with open('scratch/garden_modals_extracted.html', 'r', encoding='utf-8') as f:
    text = f.read()

all_ids = re.findall(r'id=["\']([^"\']+)["\']', text)
print(f"Total IDs in extracted garden modals: {len(all_ids)}")
print(sorted(all_ids))
