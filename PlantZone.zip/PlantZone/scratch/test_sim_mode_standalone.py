import subprocess
import time
import json
import urllib.request
import asyncio
import websockets
import tempfile
import os
import shutil
import http.server
import socketserver
import threading

PORT = 5599

class QuietHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, format, *args):
        pass

def start_server():
    httpd = socketserver.TCPServer(("", PORT), QuietHandler)
    t = threading.Thread(target=httpd.serve_forever, daemon=True)
    t.start()
    return httpd

async def run_tests():
    httpd = start_server()
    temp_dir = tempfile.mkdtemp()
    cdp_port = 9249
    chrome_path = r'C:\Program Files\Google\Chrome\Application\chrome.exe'
    
    cmd = [
        chrome_path,
        '--headless=new',
        f'--remote-debugging-port={cdp_port}',
        '--remote-allow-origins=*',
        f'--user-data-dir={temp_dir}',
        '--window-size=1440,900',
        f'http://127.0.0.1:{PORT}/index.html'
    ]
    proc = subprocess.Popen(cmd)
    await asyncio.sleep(2.0)

    try:
        req = urllib.request.urlopen(f'http://localhost:{cdp_port}/json')
        tabs = json.loads(req.read().decode('utf-8'))
        page_tabs = [t for t in tabs if t.get('type') == 'page']
        ws_url = page_tabs[0]['webSocketDebuggerUrl']

        async with websockets.connect(ws_url) as ws:
            msg_id = 1
            async def send_cmd(method, params=None):
                nonlocal msg_id
                msg_id += 1
                payload = {'id': msg_id, 'method': method, 'params': params or {}}
                await ws.send(json.dumps(payload))
                while True:
                    resp = json.loads(await ws.recv())
                    if resp.get('id') == msg_id:
                        return resp.get('result', {})

            async def eval_js(expression):
                res = await send_cmd('Runtime.evaluate', {
                    'expression': expression,
                    'returnByValue': True,
                    'awaitPromise': True
                })
                return res.get('result', {}).get('value')

            await send_cmd('Page.enable')
            await send_cmd('Runtime.enable')
            await asyncio.sleep(0.5)

            print("=== TEST: Starting Virtual Simulation & verifying inspect page ===")
            sim_test = await eval_js('''
            (() => {
                // Start simulation
                window.startSimulation();

                // Open inspect page for plant 0
                window.PlantZoneApp.openGardenModal();
                window.PlantZoneApp.openPlantDetail(0);

                const moistureVal = document.getElementById('detailMoistureVal')?.textContent;
                const tempVal = document.getElementById('detailTempVal')?.textContent;
                const humVal = document.getElementById('detailHumidityVal')?.textContent;
                const phVal = document.getElementById('detailPhVal')?.textContent;
                const hudPar = document.getElementById('camParLight')?.textContent;

                return { moistureVal, tempVal, humVal, phVal, hudPar };
            })()
            ''')
            print("Sim Test Result:", json.dumps(sim_test, indent=2))
            assert sim_test['moistureVal'] == '78%', f"Expected 78%, got {sim_test['moistureVal']}"
            assert sim_test['tempVal'] in ['24°C', '24.0°C'], f"Expected 24°C, got {sim_test['tempVal']}"
            assert sim_test['humVal'] == '55%', f"Expected 55%, got {sim_test['humVal']}"
            assert sim_test['phVal'] == 'Not Available', f"Expected Not Available, got {sim_test['phVal']}"
            assert sim_test['hudPar'] == 'Not Available', f"Expected Not Available, got {sim_test['hudPar']}"
            print("PASS: Virtual simulation feeds accurate readings, and non-existent sensors (pH, PAR) correctly say Not Available!")

            print("\n=== TEST: Stop Virtual Simulation ===")
            stop_test = await eval_js('''
            (() => {
                window.stopSimulation();
                const moistureVal = document.getElementById('detailMoistureVal')?.textContent;
                const tempVal = document.getElementById('detailTempVal')?.textContent;
                const humVal = document.getElementById('detailHumidityVal')?.textContent;
                const phVal = document.getElementById('detailPhVal')?.textContent;
                const hudPar = document.getElementById('camParLight')?.textContent;
                return { moistureVal, tempVal, humVal, phVal, hudPar };
            })()
            ''')
            print("Stop Test Result:", json.dumps(stop_test, indent=2))
            assert stop_test['moistureVal'] == 'Not Available'
            assert stop_test['tempVal'] == 'Not Available'
            assert stop_test['humVal'] == 'Not Available'
            assert stop_test['phVal'] == 'Not Available'
            assert stop_test['hudPar'] == 'Not Available'
            print("PASS: After stopping simulation, inspect page immediately says Not Available!")

    finally:
        proc.terminate()
        try:
            shutil.rmtree(temp_dir, ignore_errors=True)
        except:
            pass

asyncio.run(run_tests())
