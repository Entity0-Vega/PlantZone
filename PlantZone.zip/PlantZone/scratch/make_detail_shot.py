with open('index.html', 'r', encoding='utf-8') as f:
    html = f.read()

# Make garden modal active and detail view active
garden_html = html.replace('class="garden-fullscreen-modal" id="gardenModal"', 'class="garden-fullscreen-modal active" id="gardenModal"')
detail_html = garden_html.replace('id="gardenOverviewView">', 'id="gardenOverviewView" style="display:none;">')
detail_html = detail_html.replace('id="gardenDetailView" style="display: none;">', 'id="gardenDetailView" style="display: block;">')

with open('temp_detail.html', 'w', encoding='utf-8') as f:
    f.write(detail_html)

print("Created temp_detail.html!")
