with open('scratch/garden_modals_extracted.html', 'r', encoding='utf-8') as f:
    modals = f.read()

import re
matches = set(re.findall(r'class=["\']([^"\']+)["\']', modals))
all_classes = set()
for m in matches:
    for c in m.split():
        all_classes.add(c)

print("Garden fullscreen modal present:", 'garden-fullscreen-modal' in all_classes)
print("Wizard modal content present:", 'wizard-modal-content' in all_classes)
print("Garden detail left present:", 'garden-detail-left' in all_classes)
print("Showcase aura present:", 'showcase-aura' in all_classes)
print("Floating leaf present:", 'floating-leaf' in all_classes)
print("Showcase benefit badge present:", 'showcase-benefit-badge' in all_classes)
