with open('css/styles.css', 'r', encoding='utf-8') as f:
    css = f.read()

print("CSS length:", len(css))
print("CSS line count:", len(css.splitlines()))

# Check garden styles
garden_classes = [
    'garden-wizard-modal', 'garden-modal', 'garden-detail-split',
    'garden-detail-left', 'showcase-aura', 'floating-leaf',
    'showcase-benefit-badge', 'benefit-badge-icon', 'benefit-badge-title',
    'benefit-badge-desc', 'detail-showcase-center', 'plant-circle-podium',
    'showcase-plant-img', 'add-plant-nav-btn', 'nav-link-garden'
]

for gc in garden_classes:
    print(f".{gc}: {css.count('.' + gc)}")
