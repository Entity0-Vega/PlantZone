import sys
sys.stdout.reconfigure(encoding='utf-8')

with open('scratch/garden_modals_extracted.html', 'r', encoding='utf-8') as f:
    text = f.read()

pos_detail = text.find('id="gardenDetailView"')
print("pos detail:", pos_detail)
if pos_detail != -1:
    print(text[pos_detail:pos_detail+2500])
