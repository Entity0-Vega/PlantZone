with open('css/styles.css', 'r', encoding='utf-8') as f:
    css = f.read()

import re
matches = set(re.findall(r'(\.[a-zA-Z0-9_-]*garden[a-zA-Z0-9_-]*)', css))
print("Classes with 'garden' in CSS:")
for m in sorted(matches):
    print(" ", m)
