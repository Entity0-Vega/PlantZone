import urllib.request
import re

html = urllib.request.urlopen('http://localhost:8080').read().decode('utf-8')
srcs = re.findall(r'(?:src|href)=["\']([^"\']+\.(?:png|jpg|css|js))["\']', html)
print(f'Checking {len(srcs)} resources...')

errors = 0
for src in srcs:
    if src.startswith('http'):
        url = src
    else:
        url = f'http://localhost:8080/{src}'
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        res = urllib.request.urlopen(req)
        print(f'  [200 OK] {src}')
    except Exception as e:
        print(f'  [ERROR] {src}: {e}')
        errors += 1

print(f'Done. {errors} errors found.')
