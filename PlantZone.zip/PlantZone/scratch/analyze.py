import re

# Check js/app.js for getElementById references
with open('js/app.js', 'r', encoding='utf-8') as f:
    js_content = f.read()

js_ids = set(re.findall(r"getElementById\(['\"]([^'\"]+)['\"]\)", js_content))
print(f"Total IDs referenced in js/app.js: {len(js_ids)}")
print("IDs in js/app.js:")
for gid in sorted(js_ids):
    print("  ", gid)

with open('scratch/step35_index.html', 'r', encoding='utf-8') as f:
    s35_content = f.read()

s35_ids = set(re.findall(r'id=["\']([^"\']+)["\']', s35_content))
print(f"\nTotal IDs in step35_index.html: {len(s35_ids)}")

with open('scratch/step384_replacement.html', 'r', encoding='utf-8') as f:
    s384_content = f.read()

s384_ids = set(re.findall(r'id=["\']([^"\']+)["\']', s384_content))
print(f"Total IDs in step384_replacement.html: {len(s384_ids)}")

combined_ids = s35_ids | s384_ids
missing_in_combined = js_ids - combined_ids
print(f"Missing in step35 + step384: {missing_in_combined}")

# Also check current index.html
with open('index.html', 'r', encoding='utf-8') as f:
    idx_content = f.read()
idx_ids = set(re.findall(r'id=["\']([^"\']+)["\']', idx_content))
missing_in_idx = js_ids - idx_ids
print(f"Missing in current index.html: {missing_in_idx}")
