with open('index.html', 'r', encoding='utf-8') as f:
    idx = f.read()

pos_add = idx.find('<div class="modal garden-wizard-modal"')
if pos_add == -1:
    pos_add = idx.find('id="addGardenPlantModal"')
    # find beginning of tag
    pos_add = idx.rfind('<div', 0, pos_add)

pos_script = idx.find('<script src="js/app.js">')

garden_modals_html = idx[pos_add:pos_script]
print(f"Garden modals length: {len(garden_modals_html)}")
with open('scratch/garden_modals_extracted.html', 'w', encoding='utf-8') as f:
    f.write(garden_modals_html)
print("Saved scratch/garden_modals_extracted.html")
