import os
import subprocess
import shutil

with open('index.html', 'r', encoding='utf-8') as f:
    content = f.read()

# Completely hide the initial blur-container and show the garden modal in detail view
content = content.replace('class="blur-container" id="blurContainer"', 'class="blur-container" id="blurContainer" style="display:none !important;"')
content = content.replace('class="garden-fullscreen-modal" id="gardenModal"', 'class="garden-fullscreen-modal active" id="gardenModal" style="opacity:1 !important; visibility:visible !important; display:flex !important;"')
content = content.replace('id="gardenOverviewView"', 'id="gardenOverviewView" style="display:none !important;"')
content = content.replace('id="gardenDetailView" style="display: none;"', 'id="gardenDetailView" style="display:block !important;"')

auto_script = """
<script>
window.addEventListener('DOMContentLoaded', () => {
  if (window.PlantZoneApp) {
    window.PlantZoneApp.openPlantDetail(0);
  }
});
</script>
"""
modified_html = content.replace('</body>', auto_script + '\n</body>')

with open('temp_quick_water.html', 'w', encoding='utf-8') as f:
    f.write(modified_html)

chrome_path = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
screenshot_path = os.path.abspath("scratch/shot_quick_water_dual_mode.png")
artifact_path = os.path.abspath(r"C:\Users\jyoti\.gemini\antigravity\brain\08cfa30b-edc9-470f-a765-7d69d502529f\shot_quick_water_dual_mode.png")
url = "http://127.0.0.1:5500/temp_quick_water.html"

args = [
    chrome_path,
    "--headless",
    "--disable-gpu",
    "--window-size=1440,900",
    "--virtual-time-budget=2000",
    f"--screenshot={screenshot_path}",
    url
]

print("Capturing screenshot via Chrome CLI...")
res = subprocess.run(args, capture_output=True, text=True)
print("Return code:", res.returncode)

if os.path.exists(screenshot_path):
    shutil.copyfile(screenshot_path, artifact_path)
    print("Copied to artifact path:", os.path.exists(artifact_path))

if os.path.exists('temp_quick_water.html'):
    os.remove('temp_quick_water.html')
