import subprocess
import time
import json
import urllib.request
import asyncio
import websockets
import tempfile
import os
import shutil
import http.server
import socketserver
import threading
import sys

sys.stdout.reconfigure(encoding='utf-8')
sys.stderr.reconfigure(encoding='utf-8')

PORT = 5599

class QuietHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, format, *args):
        pass

def start_server():
    httpd = socketserver.TCPServer(("", PORT), QuietHandler)
    t = threading.Thread(target=httpd.serve_forever, daemon=True)
    t.start()
    return httpd

async def run_tests():
    httpd = start_server()
    temp_dir = tempfile.mkdtemp()
    cdp_port = 9255
    chrome_path = r'C:\Program Files\Google\Chrome\Application\chrome.exe'
    
    cmd = [
        chrome_path,
        '--headless=new',
        f'--remote-debugging-port={cdp_port}',
        '--remote-allow-origins=*',
        f'--user-data-dir={temp_dir}',
        '--window-size=1440,900',
        f'http://127.0.0.1:{PORT}/index.html'
    ]
    proc = subprocess.Popen(cmd)
    await asyncio.sleep(2.0)

    try:
        req = urllib.request.urlopen(f'http://localhost:{cdp_port}/json')
        tabs = json.loads(req.read().decode('utf-8'))
        page_tabs = [t for t in tabs if t.get('type') == 'page']
        ws_url = page_tabs[0]['webSocketDebuggerUrl']

        async with websockets.connect(ws_url) as ws:
            msg_id = 1
            async def send_cmd(method, params=None):
                nonlocal msg_id
                msg_id += 1
                payload = {'id': msg_id, 'method': method, 'params': params or {}}
                await ws.send(json.dumps(payload))
                while True:
                    resp = json.loads(await ws.recv())
                    if resp.get('id') == msg_id:
                        return resp.get('result')

            async def evaluate(expr):
                res = await send_cmd('Runtime.evaluate', {'expression': expr, 'returnByValue': True, 'awaitPromise': True})
                return res.get('result', {}).get('value')

            print("=== TEST 1: Disconnected State ===")
            res1 = await evaluate("""
                (() => {
                    const btn = document.getElementById('btnCalibDry');
                    if (!btn) return 'NO_BTN';
                    btn.click();
                    const toast = document.getElementById('toast');
                    return toast ? toast.textContent : '';
                })()
            """)
            print(f"Toast output: {res1}")
            assert "not connected" in res1.lower(), "Should show not connected error toast"
            print("-> PASSED: Disconnected click safely halted with error toast.")

            print("\n=== TEST 2: Start Simulation Mode ===")
            await evaluate("""
                (() => {
                    if (typeof window.startSimulation === 'function') {
                        window.startSimulation();
                    }
                })()
            """)
            await asyncio.sleep(0.5)
            is_sim = await evaluate("!!window.isSimulationMode")
            is_conn = await evaluate("window.HardwareManager.isConnected()")
            print(f"Simulation active: {is_sim}, Hardware connected: {is_conn}")
            assert is_sim and is_conn, "Simulation mode must be active and connected"
            print("-> PASSED: Simulation mode connected.")

            print("\n=== TEST 3: User Cancels Prompt (null) ===")
            res3 = await evaluate("""
                (() => {
                    let promptAsked = null;
                    const origPrompt = window.prompt;
                    window.prompt = (msg, def) => {
                        promptAsked = { msg, def };
                        return null; // simulate user clicking Cancel
                    };
                    document.getElementById('btnCalibDry').click();
                    window.prompt = origPrompt;
                    const toast = document.getElementById('toast');
                    return {
                        promptAsked,
                        toast: toast ? toast.textContent : '',
                        pump3Active: document.getElementById('pumpCircle3').classList.contains('pump-watering-active')
                    };
                })()
            """)
            print(f"Prompt question: {res3.get('promptAsked')}")
            print(f"Toast: {res3.get('toast')}")
            print(f"Pump 3 active: {res3.get('pump3Active')}")
            assert "canceled" in res3.get('toast', '').lower(), "Toast should state canceled"
            assert res3.get('pump3Active') is False, "Pump 3 must NOT be activated when canceled"
            print("-> PASSED: Cancel properly handled.")

            print("\n=== TEST 4: Invalid Duration Input ===")
            res4 = await evaluate("""
                (() => {
                    const origPrompt = window.prompt;
                    window.prompt = () => "invalid_abc";
                    document.getElementById('btnCalibDry').click();
                    window.prompt = origPrompt;
                    const toast = document.getElementById('toast');
                    return {
                        toast: toast ? toast.textContent : '',
                        pump3Active: document.getElementById('pumpCircle3').classList.contains('pump-watering-active')
                    };
                })()
            """)
            print(f"Toast on invalid: {res4.get('toast')}")
            assert "valid duration" in res4.get('toast', '').lower(), "Should warn about invalid duration"
            assert res4.get('pump3Active') is False, "Pump 3 must NOT be activated on invalid input"
            print("-> PASSED: Invalid input validated.")

            print("\n=== TEST 5: Valid Custom Duration Prompt (3 seconds) ===")
            await evaluate("""
                (() => {
                    const origPrompt = window.prompt;
                    window.prompt = (msg, def) => "3";
                    document.getElementById('btnCalibDry').click();
                    window.prompt = origPrompt;
                })()
            """)
            await asyncio.sleep(0.3)
            res5 = await evaluate("""
                (() => {
                    const toast = document.getElementById('toast');
                    return {
                        toast: toast ? toast.textContent : '',
                        pump3Active: document.getElementById('pumpCircle3').classList.contains('pump-watering-active')
                    };
                })()
            """)
            print(f"Toast after prompt: {res5.get('toast')}")
            print(f"Pump 3 active: {res5.get('pump3Active')}")
            assert "calibrated dry" in res5.get('toast', '').lower() and "3s" in res5.get('toast', '').lower()
            assert res5.get('pump3Active') is True, "Pump 3 circle must be active"

            print("Waiting 3.2s for Pump 3 duration to complete...")
            await asyncio.sleep(3.2)
            p3_off = await evaluate("!document.getElementById('pumpCircle3').classList.contains('pump-watering-active')")
            print(f"Pump 3 off after 3s: {p3_off}")
            assert p3_off is True, "Pump 3 must turn off after 3 seconds"
            print("-> PASSED: Pump 3 turned on for exact 3s and turned off cleanly.")

            print("\n=== TEST 6: Programmatic activateDryPump3(2) API ===")
            await evaluate("window.PlantZoneApp.activateDryPump3(2)")
            p3_prog_on = await evaluate("document.getElementById('pumpCircle3').classList.contains('pump-watering-active')")
            print(f"Pump 3 active immediately: {p3_prog_on}")
            assert p3_prog_on is True
            await asyncio.sleep(2.3)
            p3_prog_off = await evaluate("!document.getElementById('pumpCircle3').classList.contains('pump-watering-active')")
            print(f"Pump 3 off after 2s: {p3_prog_off}")
            assert p3_prog_off is True
            print("-> PASSED: activateDryPump3 programmatic API works perfectly.")

            print("\n==========================================")
            print("ALL 6 TESTS PASSED FLAWLESSLY!")
            print("==========================================")

    finally:
        proc.kill()
        httpd.shutdown()
        shutil.rmtree(temp_dir, ignore_errors=True)

if __name__ == '__main__':
    asyncio.run(run_tests())
