import sys
sys.stdout.reconfigure(encoding='utf-8')

with open('index.html', 'r', encoding='utf-8') as f:
    idx = f.read()

pos = idx.find('emptyCartShopBtn')
print("pos in idx:", pos)
if pos != -1:
    print(idx[pos-150:pos+200])
