with open('index.html', 'r', encoding='utf-8') as f:
    idx = f.read()

pos_add = idx.find('id="addGardenPlantModal"')
print("pos addGardenPlantModal:", pos_add)
if pos_add != -1:
    # let's see how big the modal is
    pos_garden = idx.find('id="gardenModal"')
    print("pos gardenModal:", pos_garden)
    pos_script = idx.find('<script src="js/app.js">')
    print("pos script:", pos_script)
