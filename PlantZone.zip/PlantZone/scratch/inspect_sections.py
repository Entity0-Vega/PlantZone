import re
import sys
sys.stdout.reconfigure(encoding='utf-8')

with open('scratch/step35_index.html', 'r', encoding='utf-8') as f:
    s35 = f.read()

# Find all section tags and their headings
sections = re.findall(r'<section[^>]*class=["\']([^"\']+)["\'][^>]*>(.*?)</section>', s35, re.DOTALL)
print(f"Found {len(sections)} sections in step35:")
for cls, content in sections:
    h = re.findall(r'<h[1-6][^>]*>(.*?)</h[1-6]>', content)
    print(f"  Class: {cls} | Headings: {h[:3]}")

# Check footer
footer = re.search(r'<footer[^>]*class=["\']([^"\']+)["\']', s35)
print(f"Footer class: {footer.group(1) if footer else 'None'}")
