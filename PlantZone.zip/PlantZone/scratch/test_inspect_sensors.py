import subprocess
import time
import json
import urllib.request
import asyncio
import websockets
import tempfile
import os
import shutil
import http.server
import socketserver
import threading

PORT = 5588

class QuietHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, format, *args):
        pass

def start_server():
    httpd = socketserver.TCPServer(("", PORT), QuietHandler)
    t = threading.Thread(target=httpd.serve_forever, daemon=True)
    t.start()
    return httpd

async def run_tests():
    httpd = start_server()
    temp_dir = tempfile.mkdtemp()
    cdp_port = 9245
    chrome_path = r'C:\Program Files\Google\Chrome\Application\chrome.exe'
    
    cmd = [
        chrome_path,
        '--headless=new',
        f'--remote-debugging-port={cdp_port}',
        '--remote-allow-origins=*',
        f'--user-data-dir={temp_dir}',
        '--window-size=1440,900',
        f'http://127.0.0.1:{PORT}/index.html'
    ]
    proc = subprocess.Popen(cmd)
    await asyncio.sleep(2.0)

    try:
        req = urllib.request.urlopen(f'http://localhost:{cdp_port}/json')
        tabs = json.loads(req.read().decode('utf-8'))
        page_tabs = [t for t in tabs if t.get('type') == 'page']
        ws_url = page_tabs[0]['webSocketDebuggerUrl']

        async with websockets.connect(ws_url) as ws:
            msg_id = 1
            async def send_cmd(method, params=None):
                nonlocal msg_id
                msg_id += 1
                payload = {'id': msg_id, 'method': method, 'params': params or {}}
                await ws.send(json.dumps(payload))
                while True:
                    resp = json.loads(await ws.recv())
                    if resp.get('id') == msg_id:
                        return resp.get('result', {})

            async def eval_js(expression):
                res = await send_cmd('Runtime.evaluate', {
                    'expression': expression,
                    'returnByValue': True,
                    'awaitPromise': True
                })
                return res.get('result', {}).get('value')

            await send_cmd('Page.enable')
            await send_cmd('Runtime.enable')
            await asyncio.sleep(0.5)

            print("=== TEST 1: Inspect page initial state (Arduino Disconnected) ===")
            t1 = await eval_js('''
            (() => {
                // Open garden modal and inspect first plant
                window.PlantZoneApp.openGardenModal();
                window.PlantZoneApp.openPlantDetail(0);

                const moistureVal = document.getElementById('detailMoistureVal')?.textContent;
                const moistureStatus = document.getElementById('detailMoistureStatus')?.textContent;
                const moistureFill = document.getElementById('detailMoistureFill')?.style.width;
                const tempVal = document.getElementById('detailTempVal')?.textContent;
                const tempStatus = document.getElementById('detailTempStatus')?.textContent;
                const phVal = document.getElementById('detailPhVal')?.textContent;
                const phStatus = document.getElementById('detailPhStatus')?.textContent;
                const humVal = document.getElementById('detailHumidityVal')?.textContent;
                const humStatus = document.getElementById('detailHumidityStatus')?.textContent;
                const hudTurgor = document.getElementById('camHudTurgor')?.textContent;
                const hudPar = document.getElementById('camParLight')?.textContent;
                const indicatorOffline = document.getElementById('detailSensorIndicator')?.classList.contains('offline');

                return {
                    moistureVal,
                    moistureStatus,
                    moistureFill,
                    tempVal,
                    tempStatus,
                    phVal,
                    phStatus,
                    humVal,
                    humStatus,
                    hudTurgor,
                    hudPar,
                    indicatorOffline
                };
            })()
            ''')
            print("Test 1 Result:", json.dumps(t1, indent=2))
            assert t1['moistureVal'] == 'Not Available', f"Expected Not Available, got {t1['moistureVal']}"
            assert t1['tempVal'] == 'Not Available', f"Expected Not Available, got {t1['tempVal']}"
            assert t1['phVal'] == 'Not Available', f"Expected Not Available, got {t1['phVal']}"
            assert t1['humVal'] == 'Not Available', f"Expected Not Available, got {t1['humVal']}"
            assert t1['hudPar'] == 'Not Available', f"Expected Not Available, got {t1['hudPar']}"
            assert t1['hudTurgor'] == 'Not Available', f"Expected Not Available, got {t1['hudTurgor']}"
            assert t1['moistureFill'] == '0%', f"Expected 0%, got {t1['moistureFill']}"
            assert t1['indicatorOffline'] is True, f"Expected indicatorOffline to be true"
            print("PASS: Test 1 - All sensors correctly report Not Available when Arduino is not connected!")

            print("\n=== TEST 2: Arduino connects and sends genuine telemetry ===")
            t2 = await eval_js('''
            (() => {
                // Simulate Arduino connection via mock
                window.HardwareManager = window.HardwareManager || {};
                const origIsConnected = window.HardwareManager.isConnected;
                window.HardwareManager.isConnected = () => true;
                window.HardwareManager.isArduinoConnected = () => true;

                // Notify connection change
                window.PlantZoneApp.onHardwareConnectionChange(true);

                // Feed genuine PlantoPRO telemetry packet:
                // SOIL1=78%  SOIL2=64%  TEMP=24.5C  HUMIDITY=55.0%  MODE=AUTO  BT=CONNECTED  RAW1=420  RAW2=510
                window.handleTelemetryLine("SOIL1=78%  SOIL2=64%  TEMP=24.5C  HUMIDITY=55.0%  MODE=AUTO  BT=CONNECTED  RAW1=420  RAW2=510");

                // Check Plant 1 (Sensor 1)
                const moistureVal1 = document.getElementById('detailMoistureVal')?.textContent;
                const moistureFill1 = document.getElementById('detailMoistureFill')?.style.width;
                const moistureStatus1 = document.getElementById('detailMoistureStatus')?.textContent;
                const tempVal1 = document.getElementById('detailTempVal')?.textContent;
                const phVal1 = document.getElementById('detailPhVal')?.textContent;
                const humVal1 = document.getElementById('detailHumidityVal')?.textContent;
                const hudTurgor1 = document.getElementById('camHudTurgor')?.textContent;
                const hudPar1 = document.getElementById('camParLight')?.textContent;
                const indicatorOffline1 = document.getElementById('detailSensorIndicator')?.classList.contains('offline');

                // Now switch to Plant 2 (Sensor 2)
                window.PlantZoneApp.openPlantDetail(1);
                const moistureVal2 = document.getElementById('detailMoistureVal')?.textContent;
                const moistureFill2 = document.getElementById('detailMoistureFill')?.style.width;
                const tempVal2 = document.getElementById('detailTempVal')?.textContent;
                const humVal2 = document.getElementById('detailHumidityVal')?.textContent;

                return {
                    plant1: {
                        moistureVal: moistureVal1,
                        moistureFill: moistureFill1,
                        moistureStatus: moistureStatus1,
                        tempVal: tempVal1,
                        phVal: phVal1,
                        humVal: humVal1,
                        hudTurgor: hudTurgor1,
                        hudPar: hudPar1,
                        indicatorOffline: indicatorOffline1
                    },
                    plant2: {
                        moistureVal: moistureVal2,
                        moistureFill: moistureFill2,
                        tempVal: tempVal2,
                        humVal: humVal2
                    }
                };
            })()
            ''')
            print("Test 2 Result:", json.dumps(t2, indent=2))
            assert t2['plant1']['moistureVal'] == '78%', f"Expected 78%, got {t2['plant1']['moistureVal']}"
            assert t2['plant1']['moistureFill'] == '78%', f"Expected 78%, got {t2['plant1']['moistureFill']}"
            assert 'ADC: 420' in t2['plant1']['moistureStatus'], f"Expected ADC 420, got {t2['plant1']['moistureStatus']}"
            assert t2['plant1']['tempVal'] == '24.5°C', f"Expected 24.5°C, got {t2['plant1']['tempVal']}"
            assert t2['plant1']['phVal'] == 'Not Available', f"Expected Not Available for pH, got {t2['plant1']['phVal']}"
            assert t2['plant1']['humVal'] == '55%', f"Expected 55%, got {t2['plant1']['humVal']}"
            assert t2['plant1']['hudTurgor'] == 'Hydrated (78%)', f"Expected Hydrated (78%), got {t2['plant1']['hudTurgor']}"
            assert t2['plant1']['hudPar'] == 'Not Available', f"Expected Not Available, got {t2['plant1']['hudPar']}"
            assert t2['plant1']['indicatorOffline'] is False, f"Expected indicator not offline"

            assert t2['plant2']['moistureVal'] == '64%', f"Expected 64%, got {t2['plant2']['moistureVal']}"
            assert t2['plant2']['moistureFill'] == '64%', f"Expected 64%, got {t2['plant2']['moistureFill']}"
            assert t2['plant2']['tempVal'] == '24.5°C', f"Expected 24.5°C, got {t2['plant2']['tempVal']}"
            assert t2['plant2']['humVal'] == '55%', f"Expected 55%, got {t2['plant2']['humVal']}"
            print("PASS: Test 2 - Accurate genuine readings displayed for both connected sensors!")

            print("\n=== TEST 3: Soil Sensor 1 fault / open circuit ===")
            t3 = await eval_js('''
            (() => {
                // Switch back to Plant 1
                window.PlantZoneApp.openPlantDetail(0);

                // Arduino reports SOIL1=ERR
                window.handleTelemetryLine("SOIL1=ERR  SOIL2=64%  TEMP=24.5C  HUMIDITY=55.0%  MODE=AUTO  BT=CONNECTED  RAW1=20  RAW2=510");

                const moistureVal1 = document.getElementById('detailMoistureVal')?.textContent;
                const moistureStatus1 = document.getElementById('detailMoistureStatus')?.textContent;
                const moistureFill1 = document.getElementById('detailMoistureFill')?.style.width;

                // Plant 2 should still have healthy 64%
                window.PlantZoneApp.openPlantDetail(1);
                const moistureVal2 = document.getElementById('detailMoistureVal')?.textContent;

                return {
                    plant1Moisture: moistureVal1,
                    plant1Status: moistureStatus1,
                    plant1Fill: moistureFill1,
                    plant2Moisture: moistureVal2
                };
            })()
            ''')
            print("Test 3 Result:", json.dumps(t3, indent=2))
            assert t3['plant1Moisture'] == 'Not Available', f"Expected Not Available, got {t3['plant1Moisture']}"
            assert 'fault' in t3['plant1Status'].lower(), f"Expected fault in status, got {t3['plant1Status']}"
            assert t3['plant1Fill'] == '0%', f"Expected 0%, got {t3['plant1Fill']}"
            assert t3['plant2Moisture'] == '64%', f"Expected 64%, got {t3['plant2Moisture']}"
            print("PASS: Test 3 - Faulty sensor correctly shows Not Available!")

            print("\n=== TEST 4: DHT11 temperature and humidity fault ===")
            t4 = await eval_js('''
            (() => {
                window.handleTelemetryLine("SOIL1=80%  SOIL2=64%  TEMP=ERR  HUMIDITY=ERR  MODE=AUTO  BT=CONNECTED  RAW1=400  RAW2=510");

                window.PlantZoneApp.openPlantDetail(0);
                const tempVal = document.getElementById('detailTempVal')?.textContent;
                const tempStatus = document.getElementById('detailTempStatus')?.textContent;
                const humVal = document.getElementById('detailHumidityVal')?.textContent;
                const humStatus = document.getElementById('detailHumidityStatus')?.textContent;

                return { tempVal, tempStatus, humVal, humStatus };
            })()
            ''')
            print("Test 4 Result:", json.dumps(t4, indent=2))
            assert t4['tempVal'] == 'Not Available', f"Expected Not Available, got {t4['tempVal']}"
            assert t4['humVal'] == 'Not Available', f"Expected Not Available, got {t4['humVal']}"
            print("PASS: Test 4 - Faulty DHT11 readings correctly show Not Available!")

            print("\n=== TEST 5: Arduino disconnects ===")
            t5 = await eval_js('''
            (() => {
                window.HardwareManager.isConnected = () => false;
                window.HardwareManager.isArduinoConnected = () => false;
                window.PlantZoneApp.onHardwareConnectionChange(false);

                const moistureVal = document.getElementById('detailMoistureVal')?.textContent;
                const tempVal = document.getElementById('detailTempVal')?.textContent;
                const humVal = document.getElementById('detailHumidityVal')?.textContent;
                const phVal = document.getElementById('detailPhVal')?.textContent;
                const hudTurgor = document.getElementById('camHudTurgor')?.textContent;
                const hudPar = document.getElementById('camParLight')?.textContent;
                const indicatorOffline = document.getElementById('detailSensorIndicator')?.classList.contains('offline');

                return {
                    moistureVal,
                    tempVal,
                    humVal,
                    phVal,
                    hudTurgor,
                    hudPar,
                    indicatorOffline
                };
            })()
            ''')
            print("Test 5 Result:", json.dumps(t5, indent=2))
            assert t5['moistureVal'] == 'Not Available'
            assert t5['tempVal'] == 'Not Available'
            assert t5['humVal'] == 'Not Available'
            assert t5['phVal'] == 'Not Available'
            assert t5['hudTurgor'] == 'Not Available'
            assert t5['hudPar'] == 'Not Available'
            assert t5['indicatorOffline'] is True
            print("PASS: Test 5 - On disconnect, all sensors immediately update to Not Available!")

            print("\n=== ALL 5 INTEGRATION TESTS PASSED PERFECTLY! ===")

    finally:
        proc.terminate()
        try:
            shutil.rmtree(temp_dir, ignore_errors=True)
        except:
            pass

asyncio.run(run_tests())
