with open('index.html', 'r', encoding='utf-8') as f:
    html = f.read()

# 1. Wizard
wizard_html = html.replace('<div class="modal-overlay" id="addGardenPlantModal">', '<div class="modal-overlay active" id="addGardenPlantModal">')
with open('temp_wizard.html', 'w', encoding='utf-8') as f:
    f.write(wizard_html)

# 2. Garden
garden_html = html.replace('<div class="garden-fullscreen-modal" id="gardenModal">', '<div class="garden-fullscreen-modal active" id="gardenModal">')
with open('temp_garden.html', 'w', encoding='utf-8') as f:
    f.write(garden_html)

# 3. Garden Detail: also hide overview and show detail
detail_html = garden_html.replace('id="gardenOverviewView">', 'id="gardenOverviewView" style="display:none;">')
detail_html = detail_html.replace('id="gardenDetailView" style="display: none;">', 'id="gardenDetailView" style="display: block;">')
with open('temp_detail.html', 'w', encoding='utf-8') as f:
    f.write(detail_html)

print("Created temp_wizard.html, temp_garden.html, and temp_detail.html!")
