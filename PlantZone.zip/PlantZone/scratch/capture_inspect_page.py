import subprocess
import time
import json
import urllib.request
import asyncio
import websockets
import tempfile
import base64
import http.server
import socketserver
import threading
import os

PORT = 5578

class QuietHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, format, *args):
        pass

def start_server():
    httpd = socketserver.TCPServer(("", PORT), QuietHandler)
    t = threading.Thread(target=httpd.serve_forever, daemon=True)
    t.start()
    return httpd

async def run():
    httpd = start_server()
    temp_dir = tempfile.mkdtemp()
    cdp_port = 9256
    chrome_path = r'C:\Program Files\Google\Chrome\Application\chrome.exe'
    
    cmd = [
        chrome_path,
        '--headless=new',
        f'--remote-debugging-port={cdp_port}',
        '--remote-allow-origins=*',
        f'--user-data-dir={temp_dir}',
        '--window-size=1440,950',
        f'http://127.0.0.1:{PORT}/index.html'
    ]
    proc = subprocess.Popen(cmd)
    await asyncio.sleep(2.0)

    try:
        req = urllib.request.urlopen(f'http://localhost:{cdp_port}/json')
        tabs = json.loads(req.read().decode('utf-8'))
        page_tabs = [t for t in tabs if t.get('type') == 'page']
        ws_url = page_tabs[0]['webSocketDebuggerUrl']

        async with websockets.connect(ws_url) as ws:
            msg_id = 1
            async def send_cmd(method, params=None):
                nonlocal msg_id
                msg_id += 1
                payload = {'id': msg_id, 'method': method, 'params': params or {}}
                await ws.send(json.dumps(payload))
                while True:
                    resp = json.loads(await ws.recv())
                    if resp.get('id') == msg_id:
                        return resp.get('result', {})

            async def eval_js(expression):
                res = await send_cmd('Runtime.evaluate', {
                    'expression': expression,
                    'returnByValue': True,
                    'awaitPromise': True
                })
                return res.get('result', {}).get('value')

            await send_cmd('Page.enable')
            await send_cmd('Runtime.enable')
            await asyncio.sleep(0.5)

            # Dismiss connect/blur modal and open inspect page
            await eval_js('''
            (() => {
                const blur = document.getElementById('blurContainer');
                if (blur) blur.style.display = 'none';
                const settingsModal = document.getElementById('settingsModal');
                if (settingsModal) settingsModal.classList.remove('active');

                window.PlantZoneApp.openGardenModal();
                window.PlantZoneApp.openPlantDetail(0);
            })()
            ''')
            await asyncio.sleep(0.6)

            # 1. Full view screenshot showing Refresh button alongside Close button
            shot1 = await send_cmd('Page.captureScreenshot', {'format': 'png'})
            with open('scratch/shot_inspect_refresh_button.png', 'wb') as f:
                f.write(base64.b64decode(shot1['data']))
            print("Saved scratch/shot_inspect_refresh_button.png")

            # 2. Capture with button actively spinning
            await eval_js('''
            (() => {
                const btn = document.getElementById('btnRefreshInspect');
                if (btn) btn.classList.add('spinning');
            })()
            ''')
            await asyncio.sleep(0.1)
            shot2 = await send_cmd('Page.captureScreenshot', {
                'format': 'png',
                'clip': {
                    'x': 1000,
                    'y': 0,
                    'width': 440,
                    'height': 150,
                    'scale': 1
                }
            })
            with open('scratch/shot_refresh_btn_close_zoom.png', 'wb') as f:
                f.write(base64.b64decode(shot2['data']))
            print("Saved scratch/shot_refresh_btn_close_zoom.png")

    finally:
        proc.terminate()
        httpd.shutdown()

asyncio.run(run())
