import re

with open('js/app.js', 'r', encoding='utf-8') as f:
    js = f.read()

with open('scratch/test_assembled_index.html', 'r', encoding='utf-8') as f:
    html = f.read()

# Find all querySelector and querySelectorAll in js
queries = re.findall(r"querySelector(?:All)?\(['\"]([^'\"]+)['\"]\)", js)
print(f"Total querySelector(All) calls in js: {len(queries)}")

unmatched = []
for q in set(queries):
    # If it's a class selector like .why-card, check if in html
    if q.startswith('.'):
        cls = q[1:].split()[0].split(':')[0]
        if f'class="{cls}' not in html and f'class=".*{cls}' not in html and cls not in html:
            unmatched.append(q)
    elif q.startswith('#'):
        elem_id = q[1:].split()[0]
        if f'id="{elem_id}"' not in html:
            unmatched.append(q)
    else:
        # tag or complex
        pass

print(f"Potentially unmatched queries ({len(unmatched)}): {unmatched}")
