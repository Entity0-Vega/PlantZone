import sys
import re
import os
sys.stdout.reconfigure(encoding='utf-8')

with open('scratch/test_assembled_index.html', 'r', encoding='utf-8') as f:
    html = f.read()

with open('js/app.js', 'r', encoding='utf-8') as f:
    js = f.read()

# 1. Check all getElementById in js/app.js
js_ids = set(re.findall(r"getElementById\(['\"]([^'\"]+)['\"]\)", js))
html_ids = set(re.findall(r'id=["\']([^"\']+)["\']', html))

missing_in_html = js_ids - html_ids
print(f"Total IDs in js/app.js: {len(js_ids)}")
print(f"Total IDs in assembled HTML: {len(html_ids)}")
print(f"Missing IDs in assembled HTML ({len(missing_in_html)}): {missing_in_html}")

# 2. Check all images
img_srcs = re.findall(r'<img[^>]+src=["\']([^"\']+)["\']', html)
print(f"Total img elements: {len(img_srcs)}")
missing_imgs = [src for src in set(img_srcs) if not os.path.exists(src)]
print(f"Missing img files on disk ({len(missing_imgs)}): {missing_imgs}")

# 3. Check section classes
sections = re.findall(r'<section[^>]*class=["\']([^"\']+)["\']', html)
print("Sections found:", sections)

# 4. Check CSS match for all section classes
with open('css/styles.css', 'r', encoding='utf-8') as f:
    css = f.read()

for s in sections:
    # First class token
    cls = s.split()[0]
    count = css.count('.' + cls)
    print(f"Section class .{cls} in CSS: {count} matches")
