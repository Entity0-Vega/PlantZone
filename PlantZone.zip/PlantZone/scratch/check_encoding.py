with open('scratch/step35_index.html', 'r', encoding='utf-8', errors='replace') as f:
    text = f.read()

bad_chars = [c for c in text if ord(c) == 0xfffd]
print("Replacement character count (U+FFFD):", len(bad_chars))
if bad_chars:
    import re
    for line_num, line in enumerate(text.splitlines(), 1):
        if '\ufffd' in line:
            print(f"Line {line_num}: {line}")
