import sys
sys.stdout.reconfigure(encoding='utf-8')

with open('index.html', 'r', encoding='utf-8') as f:
    html = f.read()

# Put active class directly on addGardenPlantModal so no setTimeout needed!
wizard_html = html.replace('id="addGardenPlantModal"', 'id="addGardenPlantModal" class="modal-overlay active"')
with open('temp_wizard.html', 'w', encoding='utf-8') as f:
    f.write(wizard_html)

# Put active class directly on gardenModal
garden_html = html.replace('id="gardenModal"', 'id="gardenModal" class="garden-fullscreen-modal active"')
with open('temp_garden.html', 'w', encoding='utf-8') as f:
    f.write(garden_html)

print("Created temp_wizard.html and temp_garden.html in root!")
