with open('css/styles.css', 'r', encoding='utf-8') as f:
    css = f.read()

import re
print("Active modal selectors:")
for m in re.finditer(r'([^{}]*garden[^{}]*active[^{}]*\{[^{}]*\})', css, re.IGNORECASE):
    print(m.group(0))

print("\ngarden-fullscreen-modal:")
for m in re.finditer(r'(\.garden-fullscreen-modal[^{}]*\{[^{}]*\})', css):
    print(m.group(0))
