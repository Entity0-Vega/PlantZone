/**
 * PlantZone - Interactive Frontend Application
 * Handles Wishlist, Modals, Search, Sliders, and Toasts
 */

document.addEventListener('DOMContentLoaded', () => {
  // ---------------- DOM References ----------------
  const toast = document.getElementById('toast');

  // Settings Modal DOM
  const settingsBtn = document.getElementById('settingsBtn');
  const settingsModal = document.getElementById('settingsModal');
  const closeSettingsBtn = document.getElementById('closeSettingsBtn');
  const settingModePill = document.getElementById('settingModePill');
  const btnSetAutoMode = document.getElementById('btnSetAutoMode');
  const btnSetManualMode = document.getElementById('btnSetManualMode');
  const btnEmergencyStop = document.getElementById('btnEmergencyStop');
  const btnCalibDry = document.getElementById('btnCalibDry');
  const btnCalibWet = document.getElementById('btnCalibWet');
  const btnCalibReset = document.getElementById('btnCalibReset');
  const btnTestPump1 = document.getElementById('btnTestPump1');
  const btnTestPump2 = document.getElementById('btnTestPump2');
  const btnTestPump3 = document.getElementById('btnTestPump3');
  const settingsHwDesc = document.getElementById('settingsHwDesc');
  const settingsHwPill = document.getElementById('settingsHwPill');
  const btnSettingsOpenConnect = document.getElementById('btnSettingsOpenConnect');
  const btnSettingsDisconnect = document.getElementById('btnSettingsDisconnect');
  const btnRestoreDefaultGarden = document.getElementById('btnRestoreDefaultGarden');
  const btnClearGardenState = document.getElementById('btnClearGardenState');

  // Simulation Controls DOM
  const settingSimPill = document.getElementById('settingSimPill');
  const btnToggleSimulation = document.getElementById('btnToggleSimulation');
  const btnSimStepOnce = document.getElementById('btnSimStepOnce');
  const simEvapRate = document.getElementById('simEvapRate');
  const simEvapRateLabel = document.getElementById('simEvapRateLabel');
  const simAutoThreshold = document.getElementById('simAutoThreshold');
  const simAutoThresholdVal = document.getElementById('simAutoThresholdVal');
  const simSoil1Range = document.getElementById('simSoil1Range');
  const simSoil1Val = document.getElementById('simSoil1Val');
  const simSoil2Range = document.getElementById('simSoil2Range');
  const simSoil2Val = document.getElementById('simSoil2Val');
  const simClimateLabel = document.getElementById('simClimateLabel');
  const simCustomTemp = document.getElementById('simCustomTemp');
  const simCustomTempVal = document.getElementById('simCustomTempVal');
  const simCustomHum = document.getElementById('simCustomHum');
  const simCustomHumVal = document.getElementById('simCustomHumVal');
  const simFaultSensor1 = document.getElementById('simFaultSensor1');
  const simFaultSensor2 = document.getElementById('simFaultSensor2');
  const simFaultDHT11 = document.getElementById('simFaultDHT11');
  const simTerminal = document.getElementById('simTerminal');
  const btnClearSimTerminal = document.getElementById('btnClearSimTerminal');
  const btnScenarioDrought = document.getElementById('btnScenarioDrought');
  const btnScenarioSoak = document.getElementById('btnScenarioSoak');
  const btnScenarioReset = document.getElementById('btnScenarioReset');

  // Search Modal DOM
  const searchBtn = document.getElementById('searchBtn');
  const searchModal = document.getElementById('searchModal');
  const closeSearchBtn = document.getElementById('closeSearchBtn');
  const plantSearchInput = document.getElementById('plantSearchInput');
  const searchResultsList = document.getElementById('searchResultsList');

  // Quick View Modal DOM
  const quickViewModal = document.getElementById('quickViewModal');
  const closeQuickViewBtn = document.getElementById('closeQuickViewBtn');
  const qvImg = document.getElementById('qvImg');
  const qvTitle = document.getElementById('qvTitle');
  const qvCategory = document.getElementById('qvCategory');
  let currentQvProduct = null;

  // Video Modal DOM
  const watchVideoBtn = document.getElementById('watchVideoBtn');
  const videoModal = document.getElementById('videoModal');
  const closeVideoBtn = document.getElementById('closeVideoBtn');

  // Navigation & Mobile Menu
  const siteHeader = document.querySelector('.site-header');
  const mobileMenuToggle = document.getElementById('mobileMenuToggle');
  const navMenu = document.getElementById('navMenu');
  const navLinks = document.querySelectorAll('.nav-link');

  // Sliders DOM
  const whyPrevBtn = document.getElementById('whyPrevBtn');
  const whyNextBtn = document.getElementById('whyNextBtn');
  const whyCardsContainer = document.getElementById('whyCardsContainer');

  const lovedPrevBtn = document.getElementById('lovedPrevBtn');
  const lovedNextBtn = document.getElementById('lovedNextBtn');
  const lovedGrid = document.getElementById('lovedGrid');

  // Forms
  const newsletterForm = document.getElementById('newsletterForm');

  // ---------------- Catalog Data for Search & QuickView ----------------
  const catalogData = [
    {
      id: 1,
      name: 'DRACAENA (Flowering Anthurium)',
      category: 'Top Products',
      img: 'assets/images/plant_anthurium.jpg',
      desc: 'Elegant heart-shaped vibrant flowers with dark emerald foliage. Thrives in moderate to bright indirect sunlight with modest moisture.'
    },
    {
      id: 2,
      name: 'DRACAENA (Sage Ceramic)',
      category: 'Top Products',
      img: 'assets/images/plant_dracaena_sage.jpg',
      desc: 'Sculptural indoor foliage planted in a soothing sage glazed ceramic pot. Known for exceptional air purifying qualities.'
    },
    {
      id: 3,
      name: 'DRACAENA (Blush Palm)',
      category: 'Top Products',
      img: 'assets/images/plant_palm_pink.jpg',
      desc: 'Feathery palm fronds that lend a calming tropical aesthetic to any home office, study, or living space.'
    },
    {
      id: 4,
      name: 'DRACAENA (Ribbed Clay Planter)',
      category: 'Top Products',
      img: 'assets/images/plant_ribbed_pot.jpg',
      desc: 'Rich green foliage complemented by a tactile artisanal ribbed ceramic planter. Excellent table centerpiece.'
    },
    {
      id: 5,
      name: 'DRACAENA (Ruby Bloom)',
      category: 'Top Products',
      img: 'assets/images/plant_anthurium.jpg',
      desc: 'Striking red spathes that bloom year-round with standard weekly watering and indirect ambient light.'
    },
    {
      id: 6,
      name: 'DRACAENA (Charcoal Column)',
      category: 'Top Products',
      img: 'assets/images/plant_cypress_dark.jpg',
      desc: 'Architectural vertical accent tree in a matte charcoal planter. Brings sophisticated height and balance to room corners.'
    },
    {
      id: 101,
      name: 'Cilum dolent garden look (ZZ Plant)',
      category: 'Most Loved',
      img: 'assets/images/plant_zz.jpg',
      desc: 'Virtually indestructible waxy dark green stems that require watering only once every 2-3 weeks.'
    },
    {
      id: 102,
      name: 'Sinrex variable garden (Snake Plant)',
      category: 'Most Loved',
      img: 'assets/images/plant_snake.jpg',
      desc: 'NASA-certified oxygen generator that releases oxygen through the night, perfect for bedrooms.'
    },
    {
      id: 103,
      name: 'Aliquam furniture garden look (Pilea)',
      category: 'Most Loved',
      img: 'assets/images/plant_pilea.jpg',
      desc: 'The famous Chinese Money Plant with coin-shaped leaves. Symbolic of prosperity, good fortune, and positive energy.'
    },
    {
      id: 104,
      name: 'Plant beautiful garden look (Peace Lily)',
      category: 'Most Loved',
      img: 'assets/images/plant_peace_lily.jpg',
      desc: 'Graceful white flower sails and deep green leaves. Communicates clearly when thirsty by gently drooping.'
    }
  ];

  // ---------------- Toast Notifications ----------------
  let toastTimer = null;
  function showToast(message, type = 'info') {
    if (toastTimer) clearTimeout(toastTimer);
    toast.textContent = message;
    toast.className = 'toast';
    if (type === 'error') {
      toast.classList.add('toast-error');
    } else if (type === 'warning') {
      toast.classList.add('toast-warning');
    }
    toast.classList.add('show');
    toastTimer = setTimeout(() => {
      toast.classList.remove('show');
    }, 3500);
  }

  function isHardwareConnected() {
    return !!(window.HardwareManager && typeof window.HardwareManager.isConnected === 'function' && window.HardwareManager.isConnected());
  }

  // ---------------- Wishlist Handling ----------------
  document.querySelectorAll('.wishlist-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const isActive = btn.classList.toggle('active');
      const card = btn.closest('.plant-card') || btn.closest('.loved-card');
      const plantName = card ? (card.dataset.name || 'Plant') : 'Plant';
      
      const svg = btn.querySelector('svg');
      if (isActive) {
        svg.setAttribute('fill', '#67a838');
        svg.setAttribute('stroke', '#67a838');
        showToast(`Saved "${plantName}" to your wishlist! ❤️`);
      } else {
        svg.setAttribute('fill', 'none');
        svg.setAttribute('stroke', 'currentColor');
        showToast(`Removed "${plantName}" from wishlist`);
      }
    });
  });

  // ---------------- Quick View Handling ----------------
  function openQuickView(product) {
    currentQvProduct = product;
    if (qvImg) {
      qvImg.src = product.img;
      qvImg.alt = product.name;
    }
    if (qvTitle) qvTitle.textContent = product.name;
    if (qvCategory) qvCategory.textContent = product.category || 'Curated Plant';
    const qvDescEl = document.getElementById('qvDesc');
    if (qvDescEl) {
      qvDescEl.textContent = product.desc || 'Specially grown and nursery-hardened for thriving indoors with minimal maintenance.';
    }
    
    if (quickViewModal) {
      quickViewModal.classList.add('active');
      document.body.style.overflow = 'hidden';
    }
  }

  function closeQuickView() {
    if (quickViewModal) {
      quickViewModal.classList.remove('active');
      document.body.style.overflow = '';
    }
  }

  if (closeQuickViewBtn) closeQuickViewBtn.addEventListener('click', closeQuickView);
  if (quickViewModal) {
    quickViewModal.addEventListener('click', (e) => {
      if (e.target === quickViewModal) closeQuickView();
    });
  }

  // Attach card click & button listeners
  document.querySelectorAll('.plant-card, .loved-card').forEach(card => {
    const qvBtn = card.querySelector('.btn-quick-view');
    
    const prodData = {
      id: card.dataset.id,
      name: card.dataset.name,
      img: card.dataset.img
    };

    if (qvBtn) {
      qvBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        openQuickView(prodData);
      });
    }

    // Clicking image box also opens quick view
    const imgBox = card.querySelector('.card-image-box, .loved-image-box');
    if (imgBox) {
      imgBox.addEventListener('click', (e) => {
        if (!e.target.closest('.wishlist-btn')) {
          openQuickView(prodData);
        }
      });
    }
  });

  // ---------------- Watch Video Modal ----------------
  watchVideoBtn.addEventListener('click', () => {
    videoModal.classList.add('active');
    document.body.style.overflow = 'hidden';
  });

  closeVideoBtn.addEventListener('click', () => {
    videoModal.classList.remove('active');
    document.body.style.overflow = '';
  });

  videoModal.addEventListener('click', (e) => {
    if (e.target === videoModal) {
      videoModal.classList.remove('active');
      document.body.style.overflow = '';
    }
  });

  // ---------------- Search Modal & Filtering ----------------
  function openSearch() {
    searchModal.classList.add('active');
    document.body.style.overflow = 'hidden';
    setTimeout(() => plantSearchInput.focus(), 100);
  }

  function closeSearch() {
    searchModal.classList.remove('active');
    document.body.style.overflow = '';
  }

  if (searchBtn) searchBtn.addEventListener('click', openSearch);
  document.querySelectorAll('.search-trigger-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      openSearch();
    });
  });
  if (closeSearchBtn) closeSearchBtn.addEventListener('click', closeSearch);
  if (searchModal) {
    searchModal.addEventListener('click', (e) => {
      if (e.target === searchModal) closeSearch();
    });
  }

  plantSearchInput.addEventListener('input', (e) => {
    const term = e.target.value.toLowerCase().trim();
    if (!term) {
      searchResultsList.innerHTML = `<div class="search-hint">Type to find Dracaena, Snake Plant, Anthurium, Pilea, Cacti...</div>`;
      return;
    }

    const matches = catalogData.filter(item => 
      item.name.toLowerCase().includes(term) || 
      item.category.toLowerCase().includes(term) ||
      item.desc.toLowerCase().includes(term)
    );

    if (matches.length === 0) {
      searchResultsList.innerHTML = `<div class="search-hint">No plants matching "${term}". Try another search!</div>`;
      return;
    }

    searchResultsList.innerHTML = matches.map(m => `
      <div class="search-result-item" data-id="${m.id}">
        <img src="${m.img}" alt="${m.name}" class="search-res-img">
        <div class="search-res-info">
          <h4>${m.name}</h4>
          <span>${m.category || 'Curated Plant'}</span>
        </div>
      </div>
    `).join('');

    searchResultsList.querySelectorAll('.search-result-item').forEach(item => {
      item.addEventListener('click', () => {
        const id = parseInt(item.dataset.id, 10);
        const prod = catalogData.find(p => p.id === id);
        if (prod) {
          closeSearch();
          openQuickView(prod);
        }
      });
    });
  });

  // ---------------- Settings Modal & Hardware Controls ----------------
  function updateSettingsUI() {
    // Mode pill & toggles
    const mode = window.arduinoMode || 'AUTO';
    if (settingModePill) {
      if (mode === 'AUTO') {
        settingModePill.textContent = 'AUTO ACTIVE';
        settingModePill.className = 'settings-status-pill pill-auto';
        if (btnSetAutoMode) btnSetAutoMode.classList.add('active');
        if (btnSetManualMode) btnSetManualMode.classList.remove('active');
      } else {
        settingModePill.textContent = 'MANUAL MODE';
        settingModePill.className = 'settings-status-pill pill-manual';
        if (btnSetAutoMode) btnSetAutoMode.classList.remove('active');
        if (btnSetManualMode) btnSetManualMode.classList.add('active');
      }
    }

    // Detail View Mode Strip Elements
    const detailModePill = document.getElementById('detailModePill');
    const detailModeLabel = document.getElementById('detailModeLabel');
    const btnDetailToggleAuto = document.getElementById('btnDetailToggleAuto');
    const btnDetailToggleManual = document.getElementById('btnDetailToggleManual');

    if (detailModePill && detailModeLabel) {
      if (mode === 'AUTO') {
        detailModePill.className = 'detail-mode-pill pill-auto';
        detailModeLabel.textContent = 'Auto Mode: Active';
        if (btnDetailToggleAuto) btnDetailToggleAuto.classList.add('active');
        if (btnDetailToggleManual) btnDetailToggleManual.classList.remove('active');
      } else {
        detailModePill.className = 'detail-mode-pill pill-manual';
        detailModeLabel.textContent = 'Manual Mode: Active';
        if (btnDetailToggleAuto) btnDetailToggleAuto.classList.remove('active');
        if (btnDetailToggleManual) btnDetailToggleManual.classList.add('active');
      }
    }

    // Hardware pill & description
    const isConn = isHardwareConnected();
    if (settingsHwPill) {
      if (window.isSimulationMode) {
        settingsHwPill.textContent = 'VIRTUAL SIM';
        settingsHwPill.className = 'settings-status-pill pill-sim-on';
        if (settingsHwDesc) settingsHwDesc.textContent = 'Virtual IoT Arduino simulator running • Virtual telemetry active.';
      } else if (isConn) {
        const isBt = window.HardwareManager && window.HardwareManager.isBluetoothConnected();
        const isSerial = window.HardwareManager && window.HardwareManager.isArduinoConnected();
        settingsHwPill.textContent = isSerial && isBt ? 'SERIAL & BT' : isSerial ? 'SERIAL (9600)' : 'BLUETOOTH';
        settingsHwPill.className = 'settings-status-pill pill-connected';
        if (settingsHwDesc) settingsHwDesc.textContent = 'Hardware connected & active • Live telemetry synchronized.';
      } else {
        settingsHwPill.textContent = 'OFFLINE';
        settingsHwPill.className = 'settings-status-pill pill-disconnected';
        if (settingsHwDesc) settingsHwDesc.textContent = 'Arduino Nano USB Serial (9600 baud) or Bluetooth HC-02.';
      }
    }

    // Simulation section status pill & toggle button
    if (settingSimPill) {
      if (window.isSimulationMode) {
        settingSimPill.textContent = 'SIMULATION ACTIVE';
        settingSimPill.className = 'settings-status-pill pill-sim-on';
      } else {
        settingSimPill.textContent = 'SIMULATION OFF';
        settingSimPill.className = 'settings-status-pill pill-sim-off';
      }
    }
    if (btnToggleSimulation) {
      if (window.isSimulationMode) {
        btnToggleSimulation.textContent = '⏹️ Stop Virtual Simulation';
        btnToggleSimulation.classList.add('active');
      } else {
        btnToggleSimulation.textContent = '🎮 Start Virtual Simulation';
        btnToggleSimulation.classList.remove('active');
      }
    }
  }

  function openSettings() {
    updateSettingsUI();
    if (settingsModal) {
      settingsModal.classList.add('active');
      document.body.style.overflow = 'hidden';
      const currentActiveTab = settingsModal.querySelector('.settings-tab-btn.active');
      if (!currentActiveTab && settingsTabBtns && settingsTabBtns[0]) {
        settingsTabBtns[0].click();
      }
    }
  }

  function closeSettings() {
    if (settingsModal) {
      settingsModal.classList.remove('active');
      document.body.style.overflow = '';
    }
  }

  if (settingsBtn) settingsBtn.addEventListener('click', openSettings);
  if (closeSettingsBtn) closeSettingsBtn.addEventListener('click', closeSettings);
  if (settingsModal) {
    settingsModal.addEventListener('click', (e) => {
      if (e.target === settingsModal) closeSettings();
    });
  }

  // Settings Category Tabs Controller
  const settingsTabBtns = document.querySelectorAll('.settings-tab-btn');
  const settingsTabPanes = document.querySelectorAll('.settings-tab-pane');

  if (settingsTabBtns.length > 0) {
    settingsTabBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        const targetTabId = btn.getAttribute('data-tab');
        settingsTabBtns.forEach(b => {
          b.classList.remove('active');
          b.setAttribute('aria-selected', 'false');
        });
        settingsTabPanes.forEach(pane => pane.classList.remove('active'));

        btn.classList.add('active');
        btn.setAttribute('aria-selected', 'true');
        const targetPane = document.getElementById(targetTabId);
        if (targetPane) targetPane.classList.add('active');
      });
    });
  }

  // 1. Irrigation Mode Controls ('A' / 'M')
  if (btnSetAutoMode) {
    btnSetAutoMode.addEventListener('click', () => {
      if (!isHardwareConnected()) {
        showToast('⚠️ Error: Arduino is not connected! Cannot switch mode.', 'error');
        return;
      }
      if (window.HardwareManager && typeof window.HardwareManager.sendCommand === 'function') {
        window.HardwareManager.sendCommand('A');
      }
      window.arduinoMode = 'AUTO';
      updateSettingsUI();
      showToast('🌱 Sent command \'A\': Automatic Irrigation Enabled (<40% threshold)! Quick Water works in both modes.');
    });
  }

  if (btnSetManualMode) {
    btnSetManualMode.addEventListener('click', () => {
      if (!isHardwareConnected()) {
        showToast('⚠️ Error: Arduino is not connected! Cannot switch mode.', 'error');
        return;
      }
      if (window.HardwareManager && typeof window.HardwareManager.sendCommand === 'function') {
        window.HardwareManager.sendCommand('M');
      }
      window.arduinoMode = 'MANUAL';
      updateSettingsUI();
      showToast('✋ Sent command \'M\': Auto Mode Paused. Use "Quick Water" buttons for on-demand manual pulses.');
    });
  }

  // Detail View Mode Toggle Buttons
  const btnDetailToggleAuto = document.getElementById('btnDetailToggleAuto');
  const btnDetailToggleManual = document.getElementById('btnDetailToggleManual');

  if (btnDetailToggleAuto) {
    btnDetailToggleAuto.addEventListener('click', () => {
      if (!isHardwareConnected()) {
        showToast('⚠️ Error: Arduino is not connected! Cannot switch mode.', 'error');
        return;
      }
      if (window.HardwareManager && typeof window.HardwareManager.sendCommand === 'function') {
        window.HardwareManager.sendCommand('A');
      }
      window.arduinoMode = 'AUTO';
      updateSettingsUI();
      showToast('🌱 Sent command \'A\': Automatic Irrigation Enabled! "Quick Water" remains fully active on demand.');
    });
  }

  if (btnDetailToggleManual) {
    btnDetailToggleManual.addEventListener('click', () => {
      if (!isHardwareConnected()) {
        showToast('⚠️ Error: Arduino is not connected! Cannot switch mode.', 'error');
        return;
      }
      if (window.HardwareManager && typeof window.HardwareManager.sendCommand === 'function') {
        window.HardwareManager.sendCommand('M');
      }
      window.arduinoMode = 'MANUAL';
      updateSettingsUI();
      showToast('✋ Sent command \'M\': Automatic irrigation paused. Use "Quick Water" for manual pulses.');
    });
  }

  // 2. Emergency Stop ('X')
  if (btnEmergencyStop) {
    btnEmergencyStop.addEventListener('click', () => {
      if (!isHardwareConnected()) {
        showToast('⚠️ Error: Arduino is not connected!', 'error');
        return;
      }
      if (window.HardwareManager && typeof window.HardwareManager.sendCommand === 'function') {
        window.HardwareManager.sendCommand('X');
      }
      // Deactivate any pump ripple animations
      [1, 2, 3].forEach(n => {
        const c = document.getElementById(`pumpCircle${n}`);
        if (c) c.classList.remove('pump-watering-active');
      });
      showToast('🛑 Sent command \'X\': Emergency Stop! All pumps shut OFF immediately.', 'error');
    });
  }

  // 3. Dynamic Soil Calibration ('D', 'W', 'R') & Pump 3 Activation
  if (btnCalibDry) {
    btnCalibDry.addEventListener('click', async () => {
      if (!isHardwareConnected()) {
        showToast("⚠️ Error: Arduino is not connected! Connect Arduino or start IoT Simulator to activate Pump 3.", "error");
        return;
      }

      // Ask user for how much time (seconds) to turn on Pump 3
      const durationInput = prompt("How many seconds would you like to turn ON Pump 3? (e.g. 3, 5, 10):", "5");

      if (durationInput === null) {
        showToast("Pump 3 activation canceled.");
        return;
      }

      const cleanInput = String(durationInput).trim().replace(/[^\d.]/g, '');
      const seconds = parseFloat(cleanInput);

      if (isNaN(seconds) || seconds <= 0) {
        showToast("⚠️ Please enter a valid duration in seconds (e.g. 3, 5, 10).", "warning");
        return;
      }

      const durationMs = Math.round(seconds * 1000);

      // Trigger Pump 3 ripple animation on #pumpCircle3
      const c = document.getElementById('pumpCircle3');
      if (c) {
        c.classList.add('pump-watering-active');
        setTimeout(() => c.classList.remove('pump-watering-active'), durationMs);
      }

      // Send command 'D' to calibrate DRY baseline
      if (window.HardwareManager && typeof window.HardwareManager.sendCommand === 'function') {
        await window.HardwareManager.sendCommand('D');
      }

      // Safe delay between commands to prevent serial port lock collisions
      await new Promise(r => setTimeout(r, 100));

      // Turn ON Pump 3 for the requested duration
      if (window.HardwareManager && typeof window.HardwareManager.sendCommand === 'function') {
        await window.HardwareManager.sendCommand('3', durationMs);
      } else if (window.isSimulationMode && typeof window.sendSimCommand === 'function') {
        window.sendSimCommand('3', durationMs);
      }

      showToast(`🌵 Calibrated DRY & Turned ON Pump 3 for ${seconds}s!`);
    });
  }

  if (btnCalibWet) {
    btnCalibWet.addEventListener('click', () => {
      if (!isHardwareConnected()) {
        showToast('⚠️ Error: Arduino is not connected! Connect Arduino to calibrate.', 'error');
        return;
      }
      if (window.HardwareManager && typeof window.HardwareManager.sendCommand === 'function') {
        window.HardwareManager.sendCommand('W');
      }
      showToast('💧 Sent command \'W\': Saved current sensor readings as WET (100% moisture baseline).');
    });
  }

  if (btnCalibReset) {
    btnCalibReset.addEventListener('click', () => {
      if (!isHardwareConnected()) {
        showToast('⚠️ Error: Arduino is not connected! Connect Arduino to calibrate.', 'error');
        return;
      }
      if (window.HardwareManager && typeof window.HardwareManager.sendCommand === 'function') {
        window.HardwareManager.sendCommand('R');
      }
      showToast('🔄 Sent command \'R\': Calibration reset to standard factory defaults (800 / 300).');
    });
  }

  // 4. Manual Pump Actuator Diagnostic Tests ('1', '2', '3')
  if (btnTestPump1) {
    btnTestPump1.addEventListener('click', () => {
      if (!isHardwareConnected()) {
        showToast('⚠️ Error: Arduino is not connected! Cannot test Pump 1.', 'error');
        return;
      }
      const c = document.getElementById('pumpCircle1');
      if (c) {
        c.classList.add('pump-watering-active');
        setTimeout(() => c.classList.remove('pump-watering-active'), 3200);
      }
      if (window.HardwareManager && typeof window.HardwareManager.sendCommand === 'function') {
        window.HardwareManager.sendCommand('1');
      }
      showToast('⚡ Sent command \'1\': Pulsing Pump 1 (Relay IN1 / D7 for 3s).');
    });
  }

  if (btnTestPump2) {
    btnTestPump2.addEventListener('click', () => {
      if (!isHardwareConnected()) {
        showToast('⚠️ Error: Arduino is not connected! Cannot test Pump 2.', 'error');
        return;
      }
      const c = document.getElementById('pumpCircle2');
      if (c) {
        c.classList.add('pump-watering-active');
        setTimeout(() => c.classList.remove('pump-watering-active'), 3200);
      }
      if (window.HardwareManager && typeof window.HardwareManager.sendCommand === 'function') {
        window.HardwareManager.sendCommand('2');
      }
      showToast('⚡ Sent command \'2\': Pulsing Pump 2 (Relay IN2 / D6 for 3s).');
    });
  }

  if (btnTestPump3) {
    btnTestPump3.addEventListener('click', () => {
      if (!isHardwareConnected()) {
        showToast('⚠️ Error: Arduino is not connected! Cannot test Pump 3.', 'error');
        return;
      }
      const c = document.getElementById('pumpCircle3');
      if (c) {
        c.classList.add('pump-watering-active');
        setTimeout(() => c.classList.remove('pump-watering-active'), 3200);
      }
      if (window.HardwareManager && typeof window.HardwareManager.sendCommand === 'function') {
        window.HardwareManager.sendCommand('3');
      }
      showToast('⚡ Sent command \'3\': Pulsing Pump 3 (Manual Valve IN4 / D8 for 3s).');
    });
  }

  // 5. Hardware Link Actions
  if (btnSettingsOpenConnect) {
    btnSettingsOpenConnect.addEventListener('click', () => {
      closeSettings();
      const userBtn = document.getElementById('userBtn');
      if (userBtn) userBtn.click();
    });
  }

  if (btnSettingsDisconnect) {
    btnSettingsDisconnect.addEventListener('click', () => {
      if (!isHardwareConnected()) {
        showToast('Hardware is already disconnected.');
        return;
      }
      if (window.isSimulationMode && typeof window.stopSimulation === 'function') {
        window.stopSimulation();
      }
      if (window.HardwareManager && typeof window.HardwareManager.disconnectAll === 'function') {
        window.HardwareManager.disconnectAll();
      }
      updateSettingsUI();
      showToast('🔌 Disconnected Arduino & Bluetooth hardware.');
    });
  }

  // ---------------- Virtual IoT Simulation Engine & Configurations ----------------
  const SimState = {
    running: false,
    evapRateSec: 5,
    autoThreshold: 40,
    waterBoost: 35,
    soil1: 78,
    soil2: 64,
    temp: 24.0,
    humidity: 55.0,
    faultSensor1: false,
    faultSensor2: false,
    faultDHT11: false,
    pumps: { 1: false, 2: false, 3: false },
    pumpTimers: { 1: null, 2: null, 3: null },
    ticker: null,
    tickCount: 0,
    calibDry: 800,
    calibWet: 300
  };

  function logSimTerminal(msg, type = '') {
    if (!simTerminal) return;
    const now = new Date();
    const timeStr = [now.getHours(), now.getMinutes(), now.getSeconds()]
      .map(n => String(n).padStart(2, '0')).join(':');

    const div = document.createElement('div');
    div.className = `term-line ${type}`.trim();
    div.textContent = `[${timeStr}] ${msg}`;
    simTerminal.appendChild(div);

    while (simTerminal.children.length > 80) {
      simTerminal.removeChild(simTerminal.firstChild);
    }
    simTerminal.scrollTop = simTerminal.scrollHeight;
  }

  function emitSimTelemetry() {
    const s1Str = SimState.faultSensor1 ? 'ERR' : `${Math.round(SimState.soil1)}%`;
    const s2Str = SimState.faultSensor2 ? 'ERR' : `${Math.round(SimState.soil2)}%`;
    const tempStr = SimState.faultDHT11 ? 'ERR' : `${SimState.temp.toFixed(1)}C`;
    const humStr = SimState.faultDHT11 ? 'ERR' : `${SimState.humidity.toFixed(1)}%`;
    const modeStr = (window.arduinoMode || 'AUTO').toUpperCase();
    const raw1 = SimState.faultSensor1 ? 15 : Math.round(SimState.calibDry - (SimState.soil1 / 100) * (SimState.calibDry - SimState.calibWet));
    const raw2 = SimState.faultSensor2 ? 18 : Math.round(SimState.calibDry - (SimState.soil2 / 100) * (SimState.calibDry - SimState.calibWet));

    const line = `SOIL1=${s1Str}  SOIL2=${s2Str}  TEMP=${tempStr}  HUMIDITY=${humStr}  MODE=${modeStr}  BT=STANDBY  RAW1=${raw1}  RAW2=${raw2}`;
    logSimTerminal(`[TX] ${line}`);

    if (typeof window.handleTelemetryLine === 'function') {
      window.handleTelemetryLine(line);
    } else if (window.PlantZoneApp && typeof window.PlantZoneApp.updateTelemetry === 'function') {
      window.PlantZoneApp.updateTelemetry({
        sensorName: 'SOIL SENSOR 1',
        sensorIndex: 0,
        moisture: SimState.faultSensor1 ? null : SimState.soil1,
        isFaulty: SimState.faultSensor1,
        temperature: SimState.faultDHT11 ? null : SimState.temp,
        isTempFault: SimState.faultDHT11,
        humidity: SimState.faultDHT11 ? null : SimState.humidity,
        isHumFault: SimState.faultDHT11,
        rawADC: raw1,
        mode: modeStr
      });
      window.PlantZoneApp.updateTelemetry({
        sensorName: 'SOIL SENSOR 2',
        sensorIndex: 1,
        moisture: SimState.faultSensor2 ? null : SimState.soil2,
        isFaulty: SimState.faultSensor2,
        temperature: SimState.faultDHT11 ? null : SimState.temp,
        isTempFault: SimState.faultDHT11,
        humidity: SimState.faultDHT11 ? null : SimState.humidity,
        isHumFault: SimState.faultDHT11,
        rawADC: raw2,
        mode: modeStr
      });
    }
  }

  function triggerSimPump(pumpNum, durationMs = 3000, isAuto = false) {
    if (SimState.pumps[pumpNum]) return;
    SimState.pumps[pumpNum] = true;

    if (window.PlantZoneApp && typeof window.PlantZoneApp.setPumpState === 'function') {
      window.PlantZoneApp.setPumpState(pumpNum, true);
    }
    const lineOn = `Pump ${pumpNum} ON`;
    if (typeof window.handleTelemetryLine === 'function') {
      window.handleTelemetryLine(lineOn);
    }

    if (pumpNum === 1) {
      SimState.soil1 = Math.min(95, SimState.soil1 + SimState.waterBoost);
      if (simSoil1Range) simSoil1Range.value = SimState.soil1;
      if (simSoil1Val) simSoil1Val.textContent = `${SimState.soil1}%`;
    } else if (pumpNum === 2) {
      SimState.soil2 = Math.min(95, SimState.soil2 + SimState.waterBoost);
      if (simSoil2Range) simSoil2Range.value = SimState.soil2;
      if (simSoil2Val) simSoil2Val.textContent = `${SimState.soil2}%`;
    }

    if (SimState.pumpTimers[pumpNum]) clearTimeout(SimState.pumpTimers[pumpNum]);

    SimState.pumpTimers[pumpNum] = setTimeout(() => {
      SimState.pumps[pumpNum] = false;
      SimState.pumpTimers[pumpNum] = null;
      if (window.PlantZoneApp && typeof window.PlantZoneApp.setPumpState === 'function') {
        window.PlantZoneApp.setPumpState(pumpNum, false);
      }
      const lineOff = `Pump ${pumpNum} OFF`;
      if (typeof window.handleTelemetryLine === 'function') {
        window.handleTelemetryLine(lineOff);
      }
      logSimTerminal(`[PUMP] Relay IN${pumpNum === 1 ? '1' : pumpNum === 2 ? '2' : '4'} (Pump ${pumpNum}) OFF`, 'pump');
      emitSimTelemetry();
    }, durationMs);
  }

  window.sendSimCommand = function(cmd, customDurationMs) {
    if (!cmd) return;
    const sCmd = String(cmd).trim().toUpperCase();
    const dur = (typeof customDurationMs === 'number' && customDurationMs > 0) ? customDurationMs : 3000;

    if (sCmd === '1' || sCmd === 'PUMP 1') {
      logSimTerminal("[RX CMD '1'] Relay IN1 (Pump 1 / D7) Triggered (3s pulse)", 'cmd');
      triggerSimPump(1, 3000, false);
    } else if (sCmd === '2' || sCmd === 'PUMP 2') {
      logSimTerminal("[RX CMD '2'] Relay IN2 (Pump 2 / D6) Triggered (3s pulse)", 'cmd');
      triggerSimPump(2, 3000, false);
    } else if (sCmd === '3' || sCmd === 'PUMP 3' || sCmd.startsWith('3:')) {
      const parts = sCmd.split(':');
      const finalDur = parts[1] ? (parseFloat(parts[1]) * 1000 || dur) : dur;
      logSimTerminal(`[RX CMD '3'] Relay IN4 (Pump 3 / D8 Manual Valve) Triggered (${(finalDur / 1000).toFixed(1)}s pulse)`, 'cmd');
      triggerSimPump(3, finalDur, false);
    } else if (sCmd === 'WATER_ALL') {
      logSimTerminal("[RX CMD 'WATER_ALL'] Multi-Pot Sequence: Pulsing Pump 1 & Pump 2", 'cmd');
      triggerSimPump(1, 3000, false);
      setTimeout(() => triggerSimPump(2, 3000, false), 3200);
    } else if (sCmd === 'MIST') {
      logSimTerminal("[RX CMD 'MIST'] Foliage Misting Valve Triggered (+5% RH)", 'cmd');
      SimState.humidity = Math.min(98, SimState.humidity + 5);
      if (simCustomHum) simCustomHum.value = Math.round(SimState.humidity);
      if (simCustomHumVal) simCustomHumVal.textContent = `${Math.round(SimState.humidity)}%`;
      emitSimTelemetry();
    } else if (sCmd === 'A' || sCmd === 'AUTO') {
      window.arduinoMode = 'AUTO';
      logSimTerminal(`[RX CMD 'A'] Irrigation Mode set to AUTO (<${SimState.autoThreshold}% threshold)`, 'cmd');
      updateSettingsUI();
      emitSimTelemetry();
    } else if (sCmd === 'M' || sCmd === 'MANUAL') {
      window.arduinoMode = 'MANUAL';
      logSimTerminal("[RX CMD 'M'] Irrigation Mode set to MANUAL (Auto-irrigation paused)", 'cmd');
      updateSettingsUI();
      emitSimTelemetry();
    } else if (sCmd === 'X' || sCmd === 'STOP') {
      logSimTerminal("[EMERGENCY STOP] Command 'X': Shutting down all pumps immediately!", 'err');
      [1, 2, 3].forEach(p => {
        if (SimState.pumpTimers[p]) {
          clearTimeout(SimState.pumpTimers[p]);
          SimState.pumpTimers[p] = null;
        }
        SimState.pumps[p] = false;
        if (window.PlantZoneApp && typeof window.PlantZoneApp.setPumpState === 'function') {
          window.PlantZoneApp.setPumpState(p, false);
        }
      });
      if (typeof window.handleTelemetryLine === 'function') {
        window.handleTelemetryLine('All pumps shut OFF immediately');
      }
    } else if (sCmd === 'D' || sCmd === 'DRY') {
      SimState.calibDry = 820;
      logSimTerminal("[CALIB 'D'] Recorded dry soil reading (0% moisture baseline = 820 ADC)", 'cmd');
      emitSimTelemetry();
    } else if (sCmd === 'W' || sCmd === 'WET') {
      SimState.calibWet = 280;
      logSimTerminal("[CALIB 'W'] Recorded saturated soil reading (100% moisture baseline = 280 ADC)", 'cmd');
      emitSimTelemetry();
    } else if (sCmd === 'R' || sCmd === 'RESET') {
      SimState.calibDry = 800;
      SimState.calibWet = 300;
      logSimTerminal("[CALIB 'R'] Reset calibration to factory defaults (800 Dry / 300 Wet)", 'cmd');
      emitSimTelemetry();
    } else if (sCmd === 'S' || sCmd === 'STATUS') {
      logSimTerminal("[RX CMD 'S'] Status query received -> Emitting telemetry packet", 'cmd');
      emitSimTelemetry();
    } else {
      logSimTerminal(`[RX CMD] Received: '${cmd}'`, 'cmd');
      emitSimTelemetry();
    }
  };

  function simTick() {
    if (!SimState.running) return;
    SimState.tickCount++;

    // 1. Soil evaporation
    if (SimState.evapRateSec > 0 && SimState.tickCount % SimState.evapRateSec === 0) {
      if (!SimState.pumps[1]) {
        SimState.soil1 = Math.max(5, SimState.soil1 - 1);
        if (simSoil1Range) simSoil1Range.value = SimState.soil1;
        if (simSoil1Val) simSoil1Val.textContent = `${SimState.soil1}%`;
      }
      if (!SimState.pumps[2]) {
        SimState.soil2 = Math.max(5, SimState.soil2 - 1);
        if (simSoil2Range) simSoil2Range.value = SimState.soil2;
        if (simSoil2Val) simSoil2Val.textContent = `${SimState.soil2}%`;
      }
    }

    // 2. Auto-irrigation check (when in AUTO mode)
    const isAuto = (window.arduinoMode || 'AUTO') === 'AUTO';
    if (isAuto) {
      if (!SimState.faultSensor1 && SimState.soil1 < SimState.autoThreshold && !SimState.pumps[1]) {
        logSimTerminal(`[AUTO-IRRIGATION] Soil 1 moisture (${SimState.soil1}%) < threshold (${SimState.autoThreshold}%) -> Firing Relay IN1 (Pump 1)`, 'pump');
        showToast(`🌱 [Auto-Irrigation] Pot 1 moisture dropped below ${SimState.autoThreshold}%! Triggering Pump 1.`);
        triggerSimPump(1, 3000, true);
      }
      if (!SimState.faultSensor2 && SimState.soil2 < SimState.autoThreshold && !SimState.pumps[2]) {
        logSimTerminal(`[AUTO-IRRIGATION] Soil 2 moisture (${SimState.soil2}%) < threshold (${SimState.autoThreshold}%) -> Firing Relay IN2 (Pump 2)`, 'pump');
        showToast(`🌱 [Auto-Irrigation] Pot 2 moisture dropped below ${SimState.autoThreshold}%! Triggering Pump 2.`);
        triggerSimPump(2, 3000, true);
      }
    }

    // 3. Subtle ambient fluctuation (every 4 ticks)
    if (SimState.tickCount % 4 === 0 && !SimState.faultDHT11) {
      const deltaTemp = (Math.random() - 0.5) * 0.2;
      const deltaHum = (Math.random() - 0.5) * 0.4;
      SimState.temp = Math.max(10, Math.min(45, Number((SimState.temp + deltaTemp).toFixed(1))));
      SimState.humidity = Math.max(20, Math.min(95, Number((SimState.humidity + deltaHum).toFixed(1))));
      if (simCustomTempVal) simCustomTempVal.textContent = `${SimState.temp.toFixed(1)}°C`;
      if (simCustomHumVal) simCustomHumVal.textContent = `${Math.round(SimState.humidity)}%`;
      if (simCustomTemp) simCustomTemp.value = SimState.temp;
      if (simCustomHum) simCustomHum.value = SimState.humidity;
    }

    // 4. Emit periodic telemetry pulse every 2 ticks
    if (SimState.tickCount % 2 === 0) {
      emitSimTelemetry();
    }
  }

  function startSimulation() {
    if (SimState.running) return;
    SimState.running = true;
    window.isSimulationMode = true;

    clearInterval(SimState.ticker);
    SimState.tickCount = 0;
    SimState.ticker = setInterval(simTick, 1000);

    updateSettingsUI();
    if (window.PlantZoneApp && typeof window.PlantZoneApp.onHardwareConnectionChange === 'function') {
      window.PlantZoneApp.onHardwareConnectionChange(true);
    }
    logSimTerminal('[SIMULATOR ONLINE] PlantoPRO Virtual Arduino Controller started (9600 baud)', 'pump');
    emitSimTelemetry();
    showToast('🎮 Virtual IoT Simulation Mode Started! Live virtual telemetry is active.');
  }

  function stopSimulation() {
    if (!SimState.running && !window.isSimulationMode) return;
    SimState.running = false;
    window.isSimulationMode = false;

    if (SimState.ticker) {
      clearInterval(SimState.ticker);
      SimState.ticker = null;
    }

    [1, 2, 3].forEach(p => {
      if (SimState.pumpTimers[p]) {
        clearTimeout(SimState.pumpTimers[p]);
        SimState.pumpTimers[p] = null;
      }
      SimState.pumps[p] = false;
      if (window.PlantZoneApp && typeof window.PlantZoneApp.setPumpState === 'function') {
        window.PlantZoneApp.setPumpState(p, false);
      }
    });

    updateSettingsUI();
    if (window.PlantZoneApp && typeof window.PlantZoneApp.onHardwareConnectionChange === 'function') {
      window.PlantZoneApp.onHardwareConnectionChange(false);
    }
    logSimTerminal('[SIMULATOR STOPPED] Virtual Arduino offline. Telemetry paused.', 'err');
    showToast('⏹️ Virtual IoT Simulation Stopped.');
  }

  window.startSimulation = startSimulation;
  window.stopSimulation = stopSimulation;

  // Simulator UI Listeners
  if (btnToggleSimulation) {
    btnToggleSimulation.addEventListener('click', () => {
      if (SimState.running) {
        stopSimulation();
      } else {
        startSimulation();
      }
    });
  }

  if (btnSimStepOnce) {
    btnSimStepOnce.addEventListener('click', () => {
      emitSimTelemetry();
      showToast('⚡ Emitted simulated telemetry pulse to dashboard.');
    });
  }

  if (btnClearSimTerminal) {
    btnClearSimTerminal.addEventListener('click', () => {
      if (simTerminal) {
        simTerminal.innerHTML = '<div class="term-line prompt">[CONSOLE CLEARED] Telemetry log reset.</div>';
      }
    });
  }

  if (simEvapRate) {
    simEvapRate.addEventListener('change', (e) => {
      SimState.evapRateSec = parseInt(e.target.value, 10);
      const labels = {
        0: 'Paused (Static)',
        12: 'Slow (-1% / 12s)',
        5: 'Normal (-1% / 5s)',
        2: 'Fast (-1% / 2s)',
        1: 'Rapid (-1% / 1s)'
      };
      if (simEvapRateLabel) {
        simEvapRateLabel.textContent = labels[SimState.evapRateSec] || `${SimState.evapRateSec}s`;
      }
      logSimTerminal(`[CONFIG] Evaporation speed set to: ${labels[SimState.evapRateSec] || SimState.evapRateSec + 's'}`, 'cmd');
    });
  }

  if (simAutoThreshold) {
    simAutoThreshold.addEventListener('input', (e) => {
      SimState.autoThreshold = parseInt(e.target.value, 10);
      if (simAutoThresholdVal) simAutoThresholdVal.textContent = `< ${SimState.autoThreshold}%`;
      logSimTerminal(`[CONFIG] Auto-irrigation trigger threshold set to: < ${SimState.autoThreshold}%`, 'cmd');
    });
  }

  if (simSoil1Range) {
    simSoil1Range.addEventListener('input', (e) => {
      SimState.soil1 = parseInt(e.target.value, 10);
      if (simSoil1Val) simSoil1Val.textContent = `${SimState.soil1}%`;
      emitSimTelemetry();
    });
  }

  if (simSoil2Range) {
    simSoil2Range.addEventListener('input', (e) => {
      SimState.soil2 = parseInt(e.target.value, 10);
      if (simSoil2Val) simSoil2Val.textContent = `${SimState.soil2}%`;
      emitSimTelemetry();
    });
  }

  const simPresetBtns = document.querySelectorAll('.sim-preset-btn');
  simPresetBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      simPresetBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      SimState.temp = parseFloat(btn.dataset.temp);
      SimState.humidity = parseFloat(btn.dataset.hum);
      if (simClimateLabel) {
        simClimateLabel.textContent = `${btn.textContent.split(' ')[0]} (${SimState.temp}°C / ${SimState.humidity}% RH)`;
      }
      if (simCustomTemp) simCustomTemp.value = SimState.temp;
      if (simCustomTempVal) simCustomTempVal.textContent = `${SimState.temp.toFixed(1)}°C`;
      if (simCustomHum) simCustomHum.value = SimState.humidity;
      if (simCustomHumVal) simCustomHumVal.textContent = `${Math.round(SimState.humidity)}%`;
      logSimTerminal(`[CONFIG] Climate preset applied: ${SimState.temp}°C / ${SimState.humidity}% RH`, 'cmd');
      emitSimTelemetry();
    });
  });

  if (simCustomTemp) {
    simCustomTemp.addEventListener('input', (e) => {
      SimState.temp = parseFloat(e.target.value);
      if (simCustomTempVal) simCustomTempVal.textContent = `${SimState.temp.toFixed(1)}°C`;
      if (simClimateLabel) simClimateLabel.textContent = `Custom (${SimState.temp.toFixed(1)}°C / ${Math.round(SimState.humidity)}% RH)`;
      simPresetBtns.forEach(b => b.classList.remove('active'));
      emitSimTelemetry();
    });
  }

  if (simCustomHum) {
    simCustomHum.addEventListener('input', (e) => {
      SimState.humidity = parseFloat(e.target.value);
      if (simCustomHumVal) simCustomHumVal.textContent = `${Math.round(SimState.humidity)}%`;
      if (simClimateLabel) simClimateLabel.textContent = `Custom (${SimState.temp.toFixed(1)}°C / ${Math.round(SimState.humidity)}% RH)`;
      simPresetBtns.forEach(b => b.classList.remove('active'));
      emitSimTelemetry();
    });
  }

  if (simFaultSensor1) {
    simFaultSensor1.addEventListener('change', (e) => {
      SimState.faultSensor1 = e.target.checked;
      logSimTerminal(`[FAULT INJECTION] Soil Sensor 1 Open-Circuit Fault: ${e.target.checked ? 'ENABLED (SOIL1=ERR)' : 'CLEARED'}`, e.target.checked ? 'err' : 'pump');
      emitSimTelemetry();
    });
  }

  if (simFaultSensor2) {
    simFaultSensor2.addEventListener('change', (e) => {
      SimState.faultSensor2 = e.target.checked;
      logSimTerminal(`[FAULT INJECTION] Soil Sensor 2 Open-Circuit Fault: ${e.target.checked ? 'ENABLED (SOIL2=ERR)' : 'CLEARED'}`, e.target.checked ? 'err' : 'pump');
      emitSimTelemetry();
    });
  }

  if (simFaultDHT11) {
    simFaultDHT11.addEventListener('change', (e) => {
      SimState.faultDHT11 = e.target.checked;
      logSimTerminal(`[FAULT INJECTION] DHT11 Climate Sensor Fault: ${e.target.checked ? 'ENABLED (TEMP=ERR HUMIDITY=ERR)' : 'CLEARED'}`, e.target.checked ? 'err' : 'pump');
      emitSimTelemetry();
    });
  }

  if (btnScenarioDrought) {
    btnScenarioDrought.addEventListener('click', () => {
      SimState.soil1 = 32;
      SimState.soil2 = 28;
      if (simSoil1Range) simSoil1Range.value = 32;
      if (simSoil1Val) simSoil1Val.textContent = '32%';
      if (simSoil2Range) simSoil2Range.value = 28;
      if (simSoil2Val) simSoil2Val.textContent = '28%';
      logSimTerminal('[SCENARIO] Drought conditions forced (<35% moisture). Auto-irrigation threshold armed.', 'cmd');
      emitSimTelemetry();
      showToast('🌵 Drought simulated (<35%). If in Auto mode, pump will auto-trigger!');
    });
  }

  if (btnScenarioSoak) {
    btnScenarioSoak.addEventListener('click', () => {
      SimState.soil1 = 92;
      SimState.soil2 = 88;
      if (simSoil1Range) simSoil1Range.value = 92;
      if (simSoil1Val) simSoil1Val.textContent = '92%';
      if (simSoil2Range) simSoil2Range.value = 88;
      if (simSoil2Val) simSoil2Val.textContent = '88%';
      logSimTerminal('[SCENARIO] Deep soak applied (Soil 1: 92%, Soil 2: 88%).', 'pump');
      emitSimTelemetry();
      showToast('💧 Deep soak applied! Pots saturated at ~90% moisture.');
    });
  }

  if (btnScenarioReset) {
    btnScenarioReset.addEventListener('click', () => {
      SimState.soil1 = 78;
      SimState.soil2 = 64;
      SimState.temp = 24.0;
      SimState.humidity = 55.0;
      SimState.evapRateSec = 5;
      SimState.autoThreshold = 40;
      SimState.faultSensor1 = false;
      SimState.faultSensor2 = false;
      SimState.faultDHT11 = false;

      if (simSoil1Range) simSoil1Range.value = 78;
      if (simSoil1Val) simSoil1Val.textContent = '78%';
      if (simSoil2Range) simSoil2Range.value = 64;
      if (simSoil2Val) simSoil2Val.textContent = '64%';
      if (simEvapRate) simEvapRate.value = '5';
      if (simEvapRateLabel) simEvapRateLabel.textContent = 'Normal (-1% / 5s)';
      if (simAutoThreshold) simAutoThreshold.value = '40';
      if (simAutoThresholdVal) simAutoThresholdVal.textContent = '< 40%';
      if (simCustomTemp) simCustomTemp.value = 24.0;
      if (simCustomTempVal) simCustomTempVal.textContent = '24.0°C';
      if (simCustomHum) simCustomHum.value = 55;
      if (simCustomHumVal) simCustomHumVal.textContent = '55%';
      if (simClimateLabel) simClimateLabel.textContent = 'Room (24°C / 55% RH)';
      simPresetBtns.forEach((b, i) => b.classList.toggle('active', i === 0));
      if (simFaultSensor1) simFaultSensor1.checked = false;
      if (simFaultSensor2) simFaultSensor2.checked = false;
      if (simFaultDHT11) simFaultDHT11.checked = false;

      logSimTerminal('[RESET] Simulator configurations reset to default values.', 'cmd');
      emitSimTelemetry();
      showToast('🔄 Simulator settings reset to default values.');
    });
  }

  // 6. Garden Sanctuary Data Management
  if (btnRestoreDefaultGarden) {
    btnRestoreDefaultGarden.addEventListener('click', () => {
      gardenState = JSON.parse(JSON.stringify(defaultGarden));
      saveGarden();
      renderGarden();
      closeSettings();
      showToast('🌿 Restored default 2 pots to Garden Sanctuary.');
    });
  }

  if (btnClearGardenState) {
    btnClearGardenState.addEventListener('click', () => {
      if (confirm('Are you sure you want to clear all plants from your garden?')) {
        gardenState = [];
        saveGarden();
        renderGarden();
        closeSettings();
        showToast('🗑️ Cleared all plants from garden.');
      }
    });
  }

  // ---------------- Sliders & Carousels ----------------
  whyPrevBtn.addEventListener('click', () => {
    whyCardsContainer.scrollBy({ left: -300, behavior: 'smooth' });
    showToast('Viewing previous plant benefits 🌿');
  });

  whyNextBtn.addEventListener('click', () => {
    whyCardsContainer.scrollBy({ left: 300, behavior: 'smooth' });
    showToast('Viewing more plant benefits 🌿');
  });

  lovedPrevBtn.addEventListener('click', () => {
    lovedGrid.scrollBy({ left: -300, behavior: 'smooth' });
  });

  lovedNextBtn.addEventListener('click', () => {
    lovedGrid.scrollBy({ left: 300, behavior: 'smooth' });
  });

  // ---------------- Header Scroll Effect ----------------
  window.addEventListener('scroll', () => {
    if (window.scrollY > 40) {
      siteHeader.classList.add('scrolled');
    } else {
      siteHeader.classList.remove('scrolled');
    }
  });

  // ---------------- Mobile Menu Toggle ----------------
  mobileMenuToggle.addEventListener('click', () => {
    navMenu.classList.toggle('active');
  });

  navLinks.forEach(link => {
    link.addEventListener('click', () => {
      navMenu.classList.remove('active');
    });
  });

  // ---------------- Newsletter Submission ----------------
  if (newsletterForm) {
    newsletterForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const input = newsletterForm.querySelector('input');
      const email = input.value;
      if (email) {
        showToast('🌱 Welcome to PlantZone! Your 15% discount has been sent to ' + email);
        input.value = '';
      }
    });
  }

  // ---------------- View All Plants Buttons ----------------
  const viewAllPlantsBtn = document.getElementById('viewAllPlantsBtn');
  if (viewAllPlantsBtn) {
    viewAllPlantsBtn.addEventListener('click', () => {
      showToast('Showing all 24 curated indoor plants in catalog!');
    });
  }

  const viewAllNewsBtn = document.getElementById('viewAllNewsBtn');
  if (viewAllNewsBtn) {
    viewAllNewsBtn.addEventListener('click', () => {
      showToast('Loading botanical care library and guides...');
    });
  }

  // User Account Button

  // Floating badges interactive clicks
  document.getElementById('badgeWeather')?.addEventListener('click', () => {
    showToast('Optimal climate: Moderate indoor humidity & stable 18-24°C temperature.');
  });
  document.getElementById('badgeWetness')?.addEventListener('click', () => {
    showToast('Moisture target: Allow top 2 inches of soil to dry before soaking.');
  });
  document.getElementById('badgeDaylight')?.addEventListener('click', () => {
    showToast('Light requirement: Thrives in filtered bright ambient daylight.');
  });

  // ---------------- Garden State & Management (Max 2 Plants / 2 Sensors) ----------------
  const MAX_GARDEN_PLANTS = 2;

  const defaultGarden = [
    {
      id: 2,
      potName: 'Sage Ceramic Pot',
      name: 'DRACAENA (Sage Ceramic)',
      cat: 'Top Products',
      img: 'assets/images/plant_dracaena_sage.jpg',
      sensor: 'SOIL SENSOR 1',
      sensors: ['SOIL SENSOR 1'],
      pump: 'PUMP 1',
      moisture: null,
      temperature: null,
      humidity: null,
      ph: null,
      health: 98,
      location: 'Living Room Corner',
      lastWatered: 'Never'
    },
    {
      id: 3,
      potName: 'Tribal Snake Pot',
      name: 'SNAKE PLANT (Sansevieria)',
      cat: 'Top Products',
      img: 'assets/images/tribal_snake_pot.jpg',
      sensor: 'SOIL SENSOR 2',
      sensors: ['SOIL SENSOR 2'],
      pump: 'PUMP 2',
      moisture: null,
      temperature: null,
      humidity: null,
      ph: null,
      health: 99,
      location: 'Sunny Balcony',
      lastWatered: 'Never'
    }
  ];

  let gardenState = [];
  try {
    const saved = localStorage.getItem('plantzone_garden');
    gardenState = saved ? JSON.parse(saved) : defaultGarden;
  } catch (e) {
    gardenState = defaultGarden;
  }

  // Ensure default 2 plants if legacy state only had 1
  if (!gardenState || gardenState.length === 0) {
    gardenState = defaultGarden;
  } else if (gardenState.length === 1 && gardenState[0].name === 'DRACAENA (Sage Ceramic)') {
    gardenState.push(defaultGarden[1]);
  }

  // Ensure every garden item has potName, assigned pump, and liveTelemetry flag
  gardenState.forEach(p => {
    p.liveTelemetry = false;
    if (!p.potName) {
      if (p.name === 'DRACAENA (Sage Ceramic)') {
        p.potName = 'Sage Ceramic Pot';
      } else {
        const clean = (p.name || 'Botanical').split('(')[0].trim();
        p.potName = `${clean} Pot`;
      }
    }
    const s = p.sensor || (p.sensors && p.sensors[0]);
    if (s === 'SOIL SENSOR 1') {
      p.pump = 'PUMP 1';
    } else if (s === 'SOIL SENSOR 2') {
      p.pump = 'PUMP 2';
    }
  });

  function saveGarden() {
    try {
      localStorage.setItem('plantzone_garden', JSON.stringify(gardenState));
    } catch (e) {
      console.error('Could not save garden to localStorage', e);
    }
  }

  // Helper to determine which sensors are currently occupied
  function getSensorUsage() {
    const usage = {
      'SOIL SENSOR 1': null,
      'SOIL SENSOR 2': null
    };
    gardenState.forEach(plant => {
      const s = plant.sensor || (plant.sensors && plant.sensors[0]);
      if (s && usage.hasOwnProperty(s)) {
        usage[s] = plant.potName || plant.name;
      }
    });
    return usage;
  }

  // Garden Modal DOM
  const gardenNavBtn = document.getElementById('gardenNavBtn');
  const gardenModal = document.getElementById('gardenModal');
  const closeGardenModalBtn = document.getElementById('closeGardenModalBtn');
  const btnRefreshInspect = document.getElementById('btnRefreshInspect');
  const gardenPlantsGrid = document.getElementById('gardenPlantsGrid');
  const gardenEmptyState = document.getElementById('gardenEmptyState');
  const gStatTotalPlants = document.getElementById('gStatTotalPlants');
  const gStatTotalSensors = document.getElementById('gStatTotalSensors');
  const gStatHealth = document.getElementById('gStatHealth');
  const gardenWaterAllBtn = document.getElementById('gardenWaterAllBtn');

  // Add Plant Wizard DOM
  const addPlantNavBtn = document.getElementById('addPlantNavBtn');
  const addGardenPlantModal = document.getElementById('addGardenPlantModal');
  const closeAddPlantModalBtn = document.getElementById('closeAddPlantModalBtn');
  const wizardStep1 = document.getElementById('wizardStep1');
  const wizardStep2 = document.getElementById('wizardStep2');
  const wizardCapacityAlert = document.getElementById('wizardCapacityAlert');
  const wizardPlantsGrid = document.getElementById('wizardPlantsGrid');
  const wizardViewGardenBtn = document.getElementById('wizardViewGardenBtn');
  const wzBackBtn = document.getElementById('wzBackBtn');
  const wzCancelBtn = document.getElementById('wzCancelBtn');
  const wzSavePlantBtn = document.getElementById('wzSavePlantBtn');
  const wzSelectedImg = document.getElementById('wzSelectedImg');
  const wzSelectedTitle = document.getElementById('wzSelectedTitle');
  const wzSelectedCat = document.getElementById('wzSelectedCat');
  const sensorCard1 = document.getElementById('sensorCard1');
  const sensorCard2 = document.getElementById('sensorCard2');
  const soilSensor1Radio = document.getElementById('soilSensor1Radio');
  const soilSensor2Radio = document.getElementById('soilSensor2Radio');
  const sensor1StatusBadge = document.getElementById('sensor1StatusBadge');
  const sensor2StatusBadge = document.getElementById('sensor2StatusBadge');
  const wzPotNameSection = document.getElementById('wzPotNameSection');
  const wzPotNameInput = document.getElementById('wzPotNameInput');
  const gardenAddPlantBtn = document.getElementById('gardenAddPlantBtn');
  const emptyGardenAddBtn = document.getElementById('emptyGardenAddBtn');
  const closeGardenBlurBtn = document.getElementById('closeGardenBlurBtn');
  const blurContainer = document.getElementById('blurContainer');
  const pageWrap = document.getElementById('pageWrap');

  let selectedPlantForGarden = null;

  // ---------------- Render Garden Dashboard ----------------
  function renderGarden() {
    if (!gardenPlantsGrid) return;

    // Update Stats
    const totalPlants = gardenState.length;
    let totalSensors = 0;
    let totalHealth = 0;

    gardenState.forEach(p => {
      const s = p.sensor || (p.sensors && p.sensors[0]);
      if (s) totalSensors += 1;
      totalHealth += (p.health || 95);
    });

    const avgHealth = totalPlants > 0 ? Math.round(totalHealth / totalPlants) : 100;

    if (gStatTotalPlants) gStatTotalPlants.textContent = `${totalPlants}/${MAX_GARDEN_PLANTS}`;
    if (gStatTotalSensors) gStatTotalSensors.textContent = `${totalSensors}/${MAX_GARDEN_PLANTS}`;
    if (gStatHealth) gStatHealth.textContent = `${avgHealth}%`;

    // Toggle Empty State vs Grid
    if (totalPlants === 0) {
      gardenPlantsGrid.style.display = 'none';
      if (gardenEmptyState) gardenEmptyState.style.display = 'block';
      return;
    }




    gardenPlantsGrid.style.display = 'grid';
    if (gardenEmptyState) gardenEmptyState.style.display = 'none';

    // Render Plant Cards with Pot Name instead of actual plant name
    gardenPlantsGrid.innerHTML = gardenState.map((plant, index) => {
      const sensorName = plant.sensor || (plant.sensors && plant.sensors[0]) || 'SOIL SENSOR 1';
      const isConn = isHardwareConnected();
      const hasLiveMoisture = isConn && plant.liveTelemetry && !plant.isFaulty && typeof plant.moisture === 'number' && !isNaN(plant.moisture);

      const metric = hasLiveMoisture
        ? `💧 Moisture ${plant.moisture}% • ${plant.moisture < 40 ? 'Thirsty' : 'Optimal'}`
        : (isConn && plant.isFaulty ? '⚠️ Sensor Fault (Not Available)' : '⚠️ Telemetry Not Available');
      const hydrationText = hasLiveMoisture ? `${plant.moisture}%` : 'Not Available';
      const hydrationFill = hasLiveMoisture ? `${plant.moisture}%` : '0%';
      const displayPotName = plant.potName || plant.name;

      return `
        <div class="garden-plant-card" data-index="${index}">
          <div class="g-card-top">
            <span class="g-health-badge">● Health ${plant.health || 98}%</span>
            <img src="${plant.img}" alt="${displayPotName}" class="g-card-img" loading="lazy">
          </div>
          <div class="g-card-body">
            <div class="g-card-header">
              <div>
                <div class="g-card-title-row">
                  <h3 class="g-card-title">${displayPotName}</h3>
                  <button type="button" class="g-rename-pot-btn" data-index="${index}" title="Rename Pot Name" aria-label="Rename Pot">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                      <path d="M12 20h9"/>
                      <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/>
                    </svg>
                  </button>
                </div>
                <div class="g-card-subtitles">
                  <span class="g-card-botanical">🌱 ${plant.name}</span>
                  <span class="g-card-loc">📍 ${plant.location || 'Indoor Sanctuary'}</span>
                </div>
              </div>
            </div>

            <div class="g-sensors-box">
              <span class="g-sensors-header">Dedicated Sensor (1 per plant)</span>
              <div class="g-sensor-pill">
                <span class="g-sensor-name">
                  <span class="g-sensor-dot"></span>
                  ${sensorName}
                </span>
                <span class="g-sensor-val">${metric}</span>
              </div>
            </div>

            <div class="g-metric-row">
              <span>Overall Hydration</span>
              <strong>${hydrationText}</strong>
            </div>
            <div class="g-progress-bar">
              <div class="g-progress-fill" style="width: ${hydrationFill};"></div>
            </div>

            <div class="g-card-actions">
              <button class="btn-water btn-quick-water" data-index="${index}" title="Instant 3s pump pulse (Works in both Automatic &amp; Manual mode)">
                💧 Quick Water
              </button>
              <button class="btn-remove-garden btn-remove-plant" data-index="${index}" title="Remove plant from garden" aria-label="Remove plant">
                &times;
              </button>
            </div>

            <!-- Inspect Plant & Benefits Trigger Button -->
            <button type="button" class="g-card-inspect-btn" data-index="${index}">
              🔍 Inspect Plant &amp; Benefits →
            </button>
          </div>
        </div>
      `;
    }).join('');

    // Attach listeners for Card Click (Opens Detail Split View)
    gardenPlantsGrid.querySelectorAll('.garden-plant-card').forEach(card => {
      card.addEventListener('click', (e) => {
        // If clicked on quick water, rename, or remove, don't trigger detail view
        if (e.target.closest('.g-card-actions') || e.target.closest('.g-rename-pot-btn')) {
          return;
        }
        const idx = parseInt(card.dataset.index, 10);
        openPlantDetail(idx);
      });
    });

    // Attach listeners for Quick Water, Rename, and Remove
    gardenPlantsGrid.querySelectorAll('.g-rename-pot-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const idx = parseInt(btn.dataset.index, 10);
        if (gardenState[idx]) {
          const currentPotName = gardenState[idx].potName || gardenState[idx].name;
          const newName = prompt('Enter a new Pot Name for this plant:', currentPotName);
          if (newName && newName.trim() && newName.trim() !== currentPotName) {
            gardenState[idx].potName = newName.trim();
            saveGarden();
            renderGarden();
            showToast(`✨ Renamed pot to "${gardenState[idx].potName}"!`);
          }
        }
      });
    });

    gardenPlantsGrid.querySelectorAll('.btn-quick-water').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        if (!isHardwareConnected()) {
          showToast('⚠️ Error: Arduino is not connected! Connect Arduino Nano or Bluetooth to activate pumps.', 'error');
          return;
        }
        const idx = parseInt(btn.dataset.index, 10);
        if (gardenState[idx]) {
          const plant = gardenState[idx];
          const isAuto = (window.arduinoMode || 'AUTO') === 'AUTO';
          const isS2 = (plant.sensor && plant.sensor.includes('2')) || plant.pump === 'PUMP 2';
          const pumpNum = isS2 ? '2' : '1';

          plant.moisture = Math.min(98, (plant.moisture || 80) + 12);
          plant.lastWatered = 'Just now';
          plant.health = 99;
          saveGarden();
          renderGarden();

          // Animate pump badge circle if in detail view
          const circle = document.getElementById(`pumpCircle${pumpNum}`);
          if (circle) {
            circle.classList.add('pump-watering-active');
            setTimeout(() => circle.classList.remove('pump-watering-active'), 3200);
          }

          // Send exact hardware trigger command ('1' or '2') to Arduino
          if (window.HardwareManager && typeof window.HardwareManager.sendCommand === 'function') {
            window.HardwareManager.sendCommand(pumpNum);
          }

          if (isAuto) {
            showToast(`💧 [Auto Mode Active] Quick Watered "${plant.potName || plant.name}"! Pulsed Pump ${pumpNum} for 3s (Auto-irrigation monitoring continues).`);
          } else {
            showToast(`💧 [Manual Mode Active] Quick Watered "${plant.potName || plant.name}"! Pulsed Pump ${pumpNum} for 3s.`);
          }
        }
      });
    });

    
    closeGardenBlurBtn.addEventListener('click', (e) => {
        pageWrap.classList.add('removeWrap');
        blurContainer.classList.add('remove');
        blurContainer.style.display = "none";

    })


    const userBtn = document.getElementById('userBtn');
    if (userBtn) {
      userBtn.addEventListener('click', () => {
        blurContainer.style.display = "flex";
        blurContainer.classList.remove('remove');
        blurContainer.classList.add('reverse-remove');
        pageWrap.classList.remove('removeWrap');
        pageWrap.classList.add('reverse-removeWrap');

      });
    }


    gardenPlantsGrid.querySelectorAll('.btn-remove-plant').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const idx = parseInt(btn.dataset.index, 10);
        if (gardenState[idx]) {
          const removed = gardenState.splice(idx, 1)[0];
          const freedSensor = removed.sensor || (removed.sensors && removed.sensors[0]);
          saveGarden();
          renderGarden();
          showToast(`Removed "${removed.potName || removed.name}". ${freedSensor} is now available for a new plant! 🌿`);
        }
      });
    });
  }

  // ---------------- Garden Detail View (Left: Benefits Showcase, Right: Telemetry) ----------------
  let activeGardenPlantIndex = 0;
  const gardenOverviewView = document.getElementById('gardenOverviewView');
  const gardenDetailView = document.getElementById('gardenDetailView');
  const btnBackToOverview = document.getElementById('btnBackToOverview');
  const gardenPlantTabs = document.getElementById('gardenPlantTabs');

  const detailShowcaseImg = document.getElementById('detailShowcaseImg');
  const detailPotName = document.getElementById('detailPotName');
  const detailRenameBtn = document.getElementById('detailRenameBtn');
  const detailSensorTitle = document.getElementById('detailSensorTitle');
  const detailMoistureVal = document.getElementById('detailMoistureVal');
  const detailMoistureFill = document.getElementById('detailMoistureFill');
  const detailMoistureStatus = document.getElementById('detailMoistureStatus');
  const detailTempVal = document.getElementById('detailTempVal');
  const detailPhVal = document.getElementById('detailPhVal');
  const detailHumidityVal = document.getElementById('detailHumidityVal') || document.getElementById('detailHealthVal');
  const detailWaterBtn = document.getElementById('detailWaterBtn');
  const detailMistBtn = document.getElementById('detailMistBtn');

  // Helper to determine exact showcase transparent cut-out for any plant
  function getPlantShowcaseImage(plant) {
    if (!plant) return 'assets/images/plant_dracaena_sage_transparent.png';

    // 1. If explicit transparent image provided
    if (plant.imgTransparent) return plant.imgTransparent;

    const rawImg = plant.img || '';

    // Check if replacing .jpg with _transparent.png maps to an available cutout
    if (rawImg.endsWith('.jpg')) {
      const trans = rawImg.replace('.jpg', '_transparent.png');
      return trans;
    }
    if (rawImg.endsWith('_transparent.png')) {
      return rawImg;
    }

    // Keyword matching
    const combined = ((plant.name || '') + ' ' + (plant.potName || '')).toLowerCase();
    if (combined.includes('tribal') || combined.includes('sansevieria')) {
      return 'assets/images/tribal_snake_pot_transparent.png';
    }
    if (combined.includes('snake')) {
      return 'assets/images/plant_snake_transparent.png';
    }
    if (combined.includes('anthurium') || combined.includes('ruby')) {
      return 'assets/images/plant_anthurium_transparent.png';
    }
    if (combined.includes('palm') || combined.includes('blush')) {
      return 'assets/images/plant_palm_pink_transparent.png';
    }
    if (combined.includes('ribbed')) {
      return 'assets/images/plant_ribbed_pot_transparent.png';
    }
    if (combined.includes('charcoal') || combined.includes('column') || combined.includes('cypress')) {
      return 'assets/images/plant_cypress_dark_transparent.png';
    }
    if (combined.includes('zz')) {
      return 'assets/images/plant_zz_transparent.png';
    }
    if (combined.includes('sage')) {
      return 'assets/images/plant_dracaena_sage_transparent.png';
    }
    if (combined.includes('lily')) {
      return 'assets/images/plant_peace_lily_transparent.png';
    }
    if (combined.includes('pilea')) {
      return 'assets/images/plant_pilea_transparent.png';
    }

    return rawImg || 'assets/images/plant_dracaena_sage_transparent.png';
  }

  function updateInspectPageTelemetry(plant) {
    if (!plant) return;
    const isConn = isHardwareConnected();
    const hasLiveMoisture = isConn && plant.liveTelemetry && !plant.isFaulty && typeof plant.moisture === 'number' && !isNaN(plant.moisture);
    const hasLiveTemp = isConn && plant.liveTelemetry && !plant.isTempFault && typeof plant.temperature === 'number' && !isNaN(plant.temperature);
    const hasLiveHum = isConn && plant.liveTelemetry && !plant.isHumFault && typeof plant.humidity === 'number' && !isNaN(plant.humidity);
    const hasLivePh = isConn && typeof plant.ph === 'number' && !isNaN(plant.ph);

    // Indicator dot in sensor badge
    const detailSensorIndicator = document.getElementById('detailSensorIndicator');
    if (detailSensorIndicator) {
      if (isConn) {
        detailSensorIndicator.classList.remove('offline');
      } else {
        detailSensorIndicator.classList.add('offline');
      }
    }

    // 1. Soil Moisture
    if (detailMoistureVal) {
      if (hasLiveMoisture) {
        detailMoistureVal.textContent = `${plant.moisture}%`;
        detailMoistureVal.className = 'metric-val text-green';
      } else {
        detailMoistureVal.textContent = 'Not Available';
        detailMoistureVal.className = 'metric-val not-available';
        if (isConn && plant.isFaulty) {
          detailMoistureVal.classList.add('text-red');
        }
      }
    }

    if (detailMoistureFill) {
      detailMoistureFill.style.width = hasLiveMoisture ? `${plant.moisture}%` : '0%';
    }

    if (detailMoistureStatus) {
      if (!isConn) {
        detailMoistureStatus.textContent = '⚠️ Arduino not connected (Not Available)';
        detailMoistureStatus.style.color = '#ef4444';
      } else if (plant.isFaulty) {
        detailMoistureStatus.textContent = '⚠️ Sensor fault / Open circuit (Not Available)';
        detailMoistureStatus.style.color = '#ef4444';
      } else if (hasLiveMoisture) {
        if (plant.moisture < 40) {
          detailMoistureStatus.textContent = '⚠️ Low moisture (<40% auto threshold)';
          detailMoistureStatus.style.color = '#eab308';
        } else {
          detailMoistureStatus.textContent = (typeof plant.rawADC === 'number')
            ? `Optimal hydration level (ADC: ${plant.rawADC})`
            : 'Optimal hydration level';
          detailMoistureStatus.style.color = '';
        }
      } else {
        detailMoistureStatus.textContent = 'Waiting for Arduino sensor reading...';
        detailMoistureStatus.style.color = '#8c9b90';
      }
    }

    // 2. Atmosphere Temperature (DHT11)
    const detailTempStatus = document.getElementById('detailTempStatus');
    if (detailTempVal) {
      if (hasLiveTemp) {
        detailTempVal.textContent = `${plant.temperature}°C`;
        detailTempVal.className = 'metric-val';
        if (detailTempStatus) {
          detailTempStatus.textContent = `DHT11 Live: ${plant.temperature}°C (Optimal 18°C – 28°C)`;
          detailTempStatus.style.color = '';
        }
      } else {
        detailTempVal.textContent = 'Not Available';
        detailTempVal.className = 'metric-val not-available';
        if (isConn && plant.isTempFault) {
          detailTempVal.classList.add('text-red');
        }
        if (detailTempStatus) {
          if (!isConn) {
            detailTempStatus.textContent = 'Sensor not available (Arduino offline)';
            detailTempStatus.style.color = '#ef4444';
          } else if (plant.isTempFault) {
            detailTempStatus.textContent = '⚠️ DHT11 error / Open circuit (Not Available)';
            detailTempStatus.style.color = '#ef4444';
          } else {
            detailTempStatus.textContent = 'Waiting for DHT11 reading...';
            detailTempStatus.style.color = '#8c9b90';
          }
        }
      }
    }

    // 3. Soil pH Acidity
    const detailPhStatus = document.getElementById('detailPhStatus');
    if (detailPhVal) {
      if (hasLivePh) {
        detailPhVal.textContent = `${plant.ph}`;
        detailPhVal.className = 'metric-val text-green';
        if (detailPhStatus) {
          detailPhStatus.textContent = `Live pH Probe: ${plant.ph}`;
          detailPhStatus.style.color = '';
        }
      } else {
        detailPhVal.textContent = 'Not Available';
        detailPhVal.className = 'metric-val not-available';
        if (detailPhStatus) {
          detailPhStatus.textContent = 'Sensor not available on Arduino';
          detailPhStatus.style.color = '#8c9b90';
        }
      }
    }

    // 4. Environment Humidity (DHT11)
    const detailHumidityStatus = document.getElementById('detailHumidityStatus');
    if (detailHumidityVal) {
      if (hasLiveHum) {
        detailHumidityVal.textContent = `${plant.humidity}%`;
        detailHumidityVal.className = 'metric-val text-green';
        if (detailHumidityStatus) {
          detailHumidityStatus.textContent = `DHT11 Live: ${plant.humidity}% (Optimal 40% – 70%)`;
          detailHumidityStatus.style.color = '';
        }
      } else {
        detailHumidityVal.textContent = 'Not Available';
        detailHumidityVal.className = 'metric-val not-available';
        if (isConn && plant.isHumFault) {
          detailHumidityVal.classList.add('text-red');
        }
        if (detailHumidityStatus) {
          if (!isConn) {
            detailHumidityStatus.textContent = 'Sensor not available (Arduino offline)';
            detailHumidityStatus.style.color = '#ef4444';
          } else if (plant.isHumFault) {
            detailHumidityStatus.textContent = '⚠️ DHT11 error / Open circuit (Not Available)';
            detailHumidityStatus.style.color = '#ef4444';
          } else {
            detailHumidityStatus.textContent = 'Waiting for DHT11 reading...';
            detailHumidityStatus.style.color = '#8c9b90';
          }
        }
      }
    }

    // 5. PlantVision HUD
    const hudTurgor = document.getElementById('camHudTurgor');
    if (hudTurgor) {
      if (hasLiveMoisture) {
        hudTurgor.textContent = plant.moisture >= 40 ? `Hydrated (${plant.moisture}%)` : `Thirsty (${plant.moisture}%)`;
      } else {
        hudTurgor.textContent = 'Not Available';
      }
    }

    const hudParLight = document.getElementById('camParLight');
    if (hudParLight) {
      hudParLight.textContent = 'Not Available';
    }
  }

  function openPlantDetail(index) {
    if (!gardenState[index]) return;
    activeGardenPlantIndex = index;
    const plant = gardenState[index];

    // Populate Left Side (exact plant matching user selection)
    if (detailShowcaseImg) {
      const targetImgSrc = getPlantShowcaseImage(plant);
      detailShowcaseImg.src = targetImgSrc;
      detailShowcaseImg.alt = plant.potName || plant.name;

      // Re-trigger entrance & float animation on plant image
      detailShowcaseImg.classList.remove('plant-animated');
      void detailShowcaseImg.offsetWidth; // Force CSS reflow
      detailShowcaseImg.classList.add('plant-animated');
    }

    // Re-trigger staggered animation on the 4 benefit cards
    const badges = document.querySelectorAll('.showcase-benefit-badge');
    badges.forEach(b => {
      b.style.animation = 'none';
      void b.offsetWidth;
      b.style.animation = '';
    });

    // Populate Right Side Telemetry & Information
    const displayPotName = plant.potName || plant.name;
    if (detailPotName) detailPotName.textContent = displayPotName;

    const sensorName = plant.sensor || (plant.sensors && plant.sensors[0]) || 'SOIL SENSOR 1';
    const pumpName = plant.pump || (sensorName.includes('1') ? 'PUMP 1' : 'PUMP 2');
    if (detailSensorTitle) detailSensorTitle.textContent = `${sensorName} • ${pumpName}`;

    // Update the 3 circular pump icons in the center of garden-detail-nav
    updateDetailNavPumps(plant);

    // Update Inspect Page Telemetry & Status
    updateInspectPageTelemetry(plant);

    // Render Plant Switcher Tabs (when plants exist)
    if (gardenPlantTabs) {
      gardenPlantTabs.innerHTML = gardenState.map((p, i) => {
        const isCurrent = i === activeGardenPlantIndex;
        return `
          <button type="button" class="plant-tab-btn ${isCurrent ? 'active' : ''}" data-index="${i}">
            🪴 ${p.potName || p.name}
          </button>
        `;
      }).join('');

      gardenPlantTabs.querySelectorAll('.plant-tab-btn').forEach(tabBtn => {
        tabBtn.addEventListener('click', () => {
          const tabIdx = parseInt(tabBtn.dataset.index, 10);
          openPlantDetail(tabIdx);
        });
      });
    }

    // Switch view
    if (gardenOverviewView) gardenOverviewView.style.display = 'none';
    if (gardenDetailView) gardenDetailView.style.display = 'block';

    // Synchronize PlantVision AI Camera with active plant
    if (window.PlantVision && typeof window.PlantVision.syncPlant === 'function') {
      window.PlantVision.syncPlant(plant, index);
    }

    // Synchronize mode strip indicators
    updateSettingsUI();
  }

  function closePlantDetail() {
    if (gardenDetailView) gardenDetailView.style.display = 'none';
    if (gardenOverviewView) gardenOverviewView.style.display = 'block';
    if (window.PlantVision && typeof window.PlantVision.pauseStream === 'function') {
      window.PlantVision.pauseStream();
    }
    renderGarden();
  }

  if (btnBackToOverview) {
    btnBackToOverview.addEventListener('click', closePlantDetail);
  }

  // Detail View Action Listeners
  if (detailWaterBtn) {
    detailWaterBtn.addEventListener('click', () => {
      if (!isHardwareConnected()) {
        showToast('⚠️ Error: Arduino is not connected! Connect Arduino Nano or Bluetooth to water plants.', 'error');
        return;
      }
      const p = gardenState[activeGardenPlantIndex];
      if (p) {
        const isAuto = (window.arduinoMode || 'AUTO') === 'AUTO';
        p.moisture = Math.min(98, (p.moisture || 80) + 12);
        p.health = 99;
        p.lastWatered = 'Just now';
        saveGarden();
        openPlantDetail(activeGardenPlantIndex);

        // Animate assigned pump circle during watering
        const s = p.sensor || (p.sensors && p.sensors[0]) || '';
        const isS2 = s.includes('2') || p.pump === 'PUMP 2';
        const pumpNum = isS2 ? '2' : '1';
        const targetCircle = isS2 ? document.getElementById('pumpCircle2') : document.getElementById('pumpCircle1');
        if (targetCircle) {
          targetCircle.classList.add('pump-watering-active');
          setTimeout(() => targetCircle.classList.remove('pump-watering-active'), 3200);
        }

        // Send hardware actuator command to Arduino
        if (window.HardwareManager && typeof window.HardwareManager.sendCommand === 'function') {
          window.HardwareManager.sendCommand(pumpNum);
        }

        if (isAuto) {
          showToast(`💧 [Auto Mode Active] Quick Watered "${p.potName || p.name}"! Pulsed Pump ${pumpNum} for 3s (Auto-irrigation monitoring continues unaffected).`);
        } else {
          showToast(`💧 [Manual Mode Active] Quick Watered "${p.potName || p.name}"! Pulsed Pump ${pumpNum} for 3s.`);
        }
      }
    });
  }

  if (detailMistBtn) {
    detailMistBtn.addEventListener('click', () => {
      if (!isHardwareConnected()) {
        showToast('⚠️ Error: Arduino is not connected! Cannot trigger misting.', 'error');
        return;
      }
      const p = gardenState[activeGardenPlantIndex];
      if (p) {
        p.health = Math.min(100, (p.health || 98) + 1);
        saveGarden();
        openPlantDetail(activeGardenPlantIndex);
        if (window.HardwareManager && typeof window.HardwareManager.sendCommand === 'function') {
          window.HardwareManager.sendCommand('MIST');
        }
        showToast(`🌿 Misted foliage of "${p.potName || p.name}"! Leaf respiration optimized.`);
      }
    });
  }

  if (detailRenameBtn) {
    detailRenameBtn.addEventListener('click', () => {
      const p = gardenState[activeGardenPlantIndex];
      if (p) {
        const currentName = p.potName || p.name;
        const newName = prompt('Enter a new Pot Name:', currentName);
        if (newName && newName.trim() && newName.trim() !== currentName) {
          p.potName = newName.trim();
          saveGarden();
          openPlantDetail(activeGardenPlantIndex);
          showToast(`✨ Renamed pot to "${p.potName}"!`);
        }
      }
    });
  }

  // ---------------- Pump Nav Management in Center of Inspection Bar ----------------
  const pumpBadge1 = document.getElementById('pumpBadge1');
  const pumpBadge2 = document.getElementById('pumpBadge2');
  const pumpBadge3 = document.getElementById('pumpBadge3');
  const pumpCircle1 = document.getElementById('pumpCircle1');
  const pumpCircle2 = document.getElementById('pumpCircle2');
  const pumpCircle3 = document.getElementById('pumpCircle3');

  function updateDetailNavPumps(currentPlant) {
    const activeSensor = currentPlant ? (currentPlant.sensor || (currentPlant.sensors && currentPlant.sensors[0])) : null;
    const activePump = currentPlant ? (currentPlant.pump || (activeSensor && activeSensor.includes('1') ? 'PUMP 1' : 'PUMP 2')) : null;

    const plantS1 = gardenState.find(p => (p.sensor || (p.sensors && p.sensors[0])) === 'SOIL SENSOR 1');
    const plantS2 = gardenState.find(p => (p.sensor || (p.sensors && p.sensors[0])) === 'SOIL SENSOR 2');

    // Pump 1
    if (pumpCircle1 && pumpBadge1) {
      if (plantS1) {
        const isCurrent = activePump === 'PUMP 1' || activeSensor === 'SOIL SENSOR 1';
        pumpCircle1.className = 'pump-circle active' + (isCurrent ? ' current-active' : '');
        pumpBadge1.title = `Pump 1: In use by "${plantS1.potName || plantS1.name}" (Linked with Soil Sensor 1)${isCurrent ? ' • Current Plant' : ''}`;
      } else {
        pumpCircle1.className = 'pump-circle available';
        pumpBadge1.title = 'Pump 1: Available (Links with Soil Sensor 1)';
      }
    }

    // Pump 2
    if (pumpCircle2 && pumpBadge2) {
      if (plantS2) {
        const isCurrent = activePump === 'PUMP 2' || activeSensor === 'SOIL SENSOR 2';
        pumpCircle2.className = 'pump-circle active' + (isCurrent ? ' current-active' : '');
        pumpBadge2.title = `Pump 2: In use by "${plantS2.potName || plantS2.name}" (Linked with Soil Sensor 2)${isCurrent ? ' • Current Plant' : ''}`;
      } else {
        pumpCircle2.className = 'pump-circle available';
        pumpBadge2.title = 'Pump 2: Available (Links with Soil Sensor 2)';
      }
    }

    // Pump 3 (Never assigned to anyone - Standby)
    if (pumpCircle3 && pumpBadge3) {
      pumpCircle3.className = 'pump-circle unassigned';
      pumpBadge3.title = 'Pump 3: Unassigned (Spare / Standby)';
    }
  }

  // Interactive Clicks on Pump Badges
  if (pumpBadge1) {
    pumpBadge1.addEventListener('click', () => {
      if (!isHardwareConnected()) {
        showToast('⚠️ Error: Arduino is not connected! Cannot trigger Pump 1 (IN1 / D7).', 'error');
        return;
      }
      if (pumpCircle1) {
        pumpCircle1.classList.add('pump-watering-active');
        setTimeout(() => pumpCircle1.classList.remove('pump-watering-active'), 3200);
      }
      if (window.HardwareManager && typeof window.HardwareManager.sendCommand === 'function') {
        window.HardwareManager.sendCommand('1');
      }
      const idx = gardenState.findIndex(p => (p.sensor || (p.sensors && p.sensors[0])) === 'SOIL SENSOR 1');
      if (idx !== -1) {
        openPlantDetail(idx);
        showToast(`💧 Sent command '1' to Arduino! Pulsing Pump 1 (Relay IN1 / D7 for 3s) for "${gardenState[idx].potName || gardenState[idx].name}".`);
      } else {
        showToast("💧 Sent command '1' to Arduino: Pulsing Pump 1 (Relay IN1 / D7 for 3s).");
      }
    });
  }

  if (pumpBadge2) {
    pumpBadge2.addEventListener('click', () => {
      if (!isHardwareConnected()) {
        showToast('⚠️ Error: Arduino is not connected! Cannot trigger Pump 2 (IN2 / D6).', 'error');
        return;
      }
      if (pumpCircle2) {
        pumpCircle2.classList.add('pump-watering-active');
        setTimeout(() => pumpCircle2.classList.remove('pump-watering-active'), 3200);
      }
      if (window.HardwareManager && typeof window.HardwareManager.sendCommand === 'function') {
        window.HardwareManager.sendCommand('2');
      }
      const idx = gardenState.findIndex(p => (p.sensor || (p.sensors && p.sensors[0])) === 'SOIL SENSOR 2');
      if (idx !== -1) {
        openPlantDetail(idx);
        showToast(`💧 Sent command '2' to Arduino! Pulsing Pump 2 (Relay IN2 / D6 for 3s) for "${gardenState[idx].potName || gardenState[idx].name}".`);
      } else {
        showToast("💧 Sent command '2' to Arduino: Pulsing Pump 2 (Relay IN2 / D6 for 3s).");
      }
    });
  }

  if (pumpBadge3) {
    pumpBadge3.addEventListener('click', () => {
      if (!isHardwareConnected()) {
        showToast('⚠️ Error: Arduino is not connected! Cannot trigger Pump 3 (Manual Valve / D8).', 'error');
        return;
      }
      if (pumpCircle3) {
        pumpCircle3.classList.add('pump-watering-active');
        setTimeout(() => pumpCircle3.classList.remove('pump-watering-active'), 3200);
      }
      if (window.HardwareManager && typeof window.HardwareManager.sendCommand === 'function') {
        window.HardwareManager.sendCommand('3');
      }
      showToast("💧 Sent command '3' to Arduino: Pulsing Pump 3 (Manual Valve on Relay IN4 / D8 for 3s).");
    });
  }


  // Open & Close Garden Full Screen Popup
  function openGardenModal() {
    renderGarden();
    gardenModal.classList.add('active');
    document.body.style.overflow = 'hidden';
    if (!isHardwareConnected()) {
      showToast('⚠️ Arduino is not connected. Connect via USB or Bluetooth to sync sensors & control pumps.', 'warning');
    }
  }

  function closeGardenModal() {
    gardenModal.classList.remove('active');
    document.body.style.overflow = '';
  }

  if (gardenNavBtn) {
    gardenNavBtn.addEventListener('click', (e) => {
      e.preventDefault();
      openGardenModal();
    });
  }

  if (closeGardenModalBtn) {
    closeGardenModalBtn.addEventListener('click', closeGardenModal);
  }

  if (btnRefreshInspect) {
    btnRefreshInspect.addEventListener('click', () => {
      // Prevent rapid spam while actively spinning
      if (btnRefreshInspect.classList.contains('spinning')) return;

      btnRefreshInspect.classList.add('spinning');

      const isConnected = isHardwareConnected();

      if (isConnected) {
        // Send 'S' telemetry query command to Arduino / simulation
        if (window.HardwareManager && typeof window.HardwareManager.queryTelemetry === 'function') {
          window.HardwareManager.queryTelemetry();
        } else if (window.HardwareManager && typeof window.HardwareManager.sendCommand === 'function') {
          window.HardwareManager.sendCommand('S');
        } else if (window.isSimulationMode && typeof window.sendSimCommand === 'function') {
          window.sendSimCommand('S');
        }

        // If virtual simulation mode is active, emit telemetry immediately to sync all views
        if (window.isSimulationMode && typeof emitSimTelemetry === 'function') {
          emitSimTelemetry();
        }

        showToast('🔄 Queried Arduino for fresh telemetry (Command \'S\')!');
      } else {
        showToast('⚠️ Arduino is not connected. Connect via USB or Bluetooth in Settings to fetch live telemetry.', 'warning');
      }

      // Synchronize inspect page telemetry immediately if currently viewing a plant
      if (gardenDetailView && gardenDetailView.style.display !== 'none' && gardenState[activeGardenPlantIndex]) {
        updateInspectPageTelemetry(gardenState[activeGardenPlantIndex]);
      } else {
        renderGarden();
      }

      // Re-enable and reset spin animation after 700ms
      setTimeout(() => {
        btnRefreshInspect.classList.remove('spinning');
      }, 700);
    });
  }

  if (gardenWaterAllBtn) {
    gardenWaterAllBtn.addEventListener('click', () => {
      if (gardenState.length === 0) {
        showToast('Your garden is empty! Add plants first.');
        return;
      }
      if (!isHardwareConnected()) {
        showToast('⚠️ Error: Arduino is not connected! Cannot trigger pumps without an active connection.', 'error');
        return;
      }
      gardenState.forEach(p => {
        p.moisture = 95;
        p.health = 99;
        p.lastWatered = 'Just now';
      });
      saveGarden();
      renderGarden();

      if (pumpCircle1) {
        pumpCircle1.classList.add('pump-watering-active');
        setTimeout(() => pumpCircle1.classList.remove('pump-watering-active'), 3200);
      }
      if (pumpCircle2) {
        setTimeout(() => {
          pumpCircle2.classList.add('pump-watering-active');
          setTimeout(() => pumpCircle2.classList.remove('pump-watering-active'), 3200);
        }, 1500);
      }

      if (window.HardwareManager && typeof window.HardwareManager.sendCommand === 'function') {
        window.HardwareManager.sendCommand('WATER_ALL');
      }
      const isAuto = (window.arduinoMode || 'AUTO') === 'AUTO';
      if (isAuto) {
        showToast('💧 [Auto Mode Active] Sent sequence commands: Watering Pump 1 & Pump 2 (3s each)! Automatic monitoring continues unaffected.');
      } else {
        showToast('💧 [Manual Mode Active] Sent sequence commands: Watering Pump 1 & Pump 2 (3s each)!');
      }
    });
  }

  // =========================================================================
  // PlantVision™ AI Optical Monitor & Foliage Diagnostic Controller
  // =========================================================================
  const PlantVision = (() => {
    // DOM Elements
    const screenWrap = document.getElementById('gardenCameraScreen');
    const canvas = document.getElementById('plantCameraCanvas');
    const video = document.getElementById('plantCameraVideo');
    const shutterFlash = document.getElementById('camShutterFlash');
    const fillLightOverlay = document.getElementById('camFillLightOverlay');
    const laserScanline = document.getElementById('camLaserScanline');
    const hudOverlay = document.getElementById('camHudOverlay');
    const standbyScreen = document.getElementById('camStandbyScreen');
    const btnStandbyStart = document.getElementById('btnStandbyStart');
    const btnToggleCam = document.getElementById('btnToggleCamera');
    const btnToggleCamText = document.getElementById('btnToggleCamText');
    const btnSwitchSource = document.getElementById('btnSwitchCamSource');
    const camSourceBtnText = document.getElementById('camSourceBtnText');
    const camSourceBadge = document.getElementById('camSourceBadge');
    const btnCapture = document.getElementById('btnCameraCapture');
    const filterButtons = document.querySelectorAll('.cam-filter-btn');
    const btnToggleLight = document.getElementById('btnToggleCamLight');
    const btnCycleZoom = document.getElementById('btnCycleZoom');
    const zoomBtnLabel = document.getElementById('zoomBtnLabel');
    const camZoomIndicator = document.getElementById('camZoomIndicator');
    const btnToggleHud = document.getElementById('btnToggleHud');
    const camStatusPill = document.getElementById('camStatusPill');
    const camStatusText = document.getElementById('camStatusText');

    // HUD Elements
    const hudTargetPlantName = document.getElementById('camTargetPlantName');
    const hudTargetHealthTag = document.getElementById('camTargetHealthTag');
    const hudTurgor = document.getElementById('camHudTurgor');
    const hudParLight = document.getElementById('camParLight');
    const hudClock = document.getElementById('camClock');
    const hudRecTimer = document.getElementById('camRecTimer');

    // Diagnostic Drawer Elements
    const diagDrawer = document.getElementById('camDiagnosticDrawer');
    const btnCloseDiag = document.getElementById('btnCloseDiagnostic');
    const diagThumbImg = document.getElementById('diagnosticThumbImg');
    const diagTimestamp = document.getElementById('diagTimestamp');
    const diagScoreVal = document.getElementById('diagScoreVal');
    const diagScoreHeading = document.getElementById('diagScoreHeading');
    const diagScoreDesc = document.getElementById('diagScoreDesc');
    const diagChlorophyll = document.getElementById('diagChlorophyll');
    const diagPests = document.getElementById('diagPests');
    const diagTranspiration = document.getElementById('diagTranspiration');
    const diagAdvice = document.getElementById('diagAdvice');
    const btnDownloadSnap = document.getElementById('btnDownloadSnapshot');
    const btnRetakeScan = document.getElementById('btnRetakeScan');

    if (!canvas) {
      return { syncPlant: () => {}, pauseStream: () => {}, resumeStream: () => {} };
    }

    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    const CANVAS_WIDTH = 1280;
    const CANVAS_HEIGHT = 720;
    canvas.width = CANVAS_WIDTH;
    canvas.height = CANVAS_HEIGHT;

    // Internal State
    let isRunning = true;
    let mode = 'simulated'; // 'simulated' | 'webcam'
    let visionFilter = 'rgb'; // 'rgb' | 'ndvi' | 'edge'
    let zoomLevel = 1.0;
    const ZOOM_STEPS = [1.0, 1.5, 2.0];
    let isLightOn = false;
    let isHudVisible = true;
    let currentPlant = null;
    let plantImage = new Image();
    let isImageLoaded = false;
    let webcamStream = null;
    let animFrameId = null;
    let recSeconds = 258; // 00:04:18 initial
    let lastClockUpdate = 0;

    // Ambient floating particles for greenhouse canopy realism
    const particles = Array.from({ length: 28 }, () => ({
      x: Math.random() * CANVAS_WIDTH,
      y: Math.random() * CANVAS_HEIGHT,
      radius: Math.random() * 2.5 + 1,
      speedY: Math.random() * 0.4 + 0.2,
      flutter: Math.random() * Math.PI * 2,
      opacity: Math.random() * 0.45 + 0.15
    }));

    // Helper: Format timer
    function formatTimer(secs) {
      const h = Math.floor(secs / 3600);
      const m = Math.floor((secs % 3600) / 60);
      const s = secs % 60;
      return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
    }

    // Helper: Format date
    function getFormattedTimestamp() {
      const d = new Date();
      const pad = n => String(n).padStart(2, '0');
      return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
    }

    // Plant Synchronization
    function syncPlant(plant, index) {
      currentPlant = plant || (gardenState && gardenState[0]);
      if (!currentPlant) return;

      const plantDisplayName = currentPlant.potName || currentPlant.name || 'Botanical Specimen';
      const healthVal = currentPlant.health !== undefined ? currentPlant.health : 98;
      const moistureVal = currentPlant.moisture !== undefined ? currentPlant.moisture : 85;

      if (hudTargetPlantName) {
        hudTargetPlantName.textContent = `🌿 ${plantDisplayName}`;
      }
      if (hudTargetHealthTag) {
        hudTargetHealthTag.textContent = `HEALTH: ${healthVal.toFixed(1)}%`;
      }
      if (hudTurgor) {
        const isConn = isHardwareConnected();
        const hasLiveMoisture = isConn && currentPlant && currentPlant.liveTelemetry && !currentPlant.isFaulty && typeof currentPlant.moisture === 'number' && !isNaN(currentPlant.moisture);
        if (hasLiveMoisture) {
          hudTurgor.textContent = currentPlant.moisture >= 40 ? `Hydrated (${currentPlant.moisture}%)` : `Thirsty (${currentPlant.moisture}%)`;
        } else {
          hudTurgor.textContent = 'Not Available';
        }
      }
      if (hudParLight) {
        hudParLight.textContent = 'Not Available';
      }

      // Load plant cutout image
      const targetImgSrc = getPlantShowcaseImage(currentPlant);
      isImageLoaded = false;
      plantImage = new Image();
      plantImage.crossOrigin = 'anonymous';
      plantImage.onload = () => {
        isImageLoaded = true;
      };
      plantImage.onerror = () => {
        // Fallback to dracaena
        plantImage.src = 'assets/images/plant_dracaena_sage_transparent.png';
      };
      plantImage.src = targetImgSrc;

      if (!isRunning) {
        resumeStream();
      }
    }

    // Canvas Background Drawing (High-Tech Horticultural Chamber)
    function drawGreenhouseBackground(timestamp) {
      // 1. Radial Vignette Gradient
      const grad = ctx.createRadialGradient(
        CANVAS_WIDTH / 2, CANVAS_HEIGHT * 0.35, 120,
        CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2, CANVAS_WIDTH * 0.75
      );
      grad.addColorStop(0, '#102816');
      grad.addColorStop(0.5, '#0b1c10');
      grad.addColorStop(1, '#050c07');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

      // 2. High-Tech Perspective Alignment Grid
      ctx.save();
      ctx.strokeStyle = 'rgba(74, 222, 128, 0.07)';
      ctx.lineWidth = 1;
      const gridStep = 48;
      for (let x = 0; x <= CANVAS_WIDTH; x += gridStep) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, CANVAS_HEIGHT);
        ctx.stroke();
      }
      for (let y = 0; y <= CANVAS_HEIGHT; y += gridStep) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(CANVAS_WIDTH, y);
        ctx.stroke();
      }

      // Chamber Floor Horizon Line
      ctx.strokeStyle = 'rgba(74, 222, 128, 0.18)';
      ctx.beginPath();
      ctx.moveTo(0, CANVAS_HEIGHT * 0.78);
      ctx.lineTo(CANVAS_WIDTH, CANVAS_HEIGHT * 0.78);
      ctx.stroke();

      // Top Botanical LED Grow Light Array Caustic Beams
      const beamGrad = ctx.createLinearGradient(CANVAS_WIDTH / 2, 0, CANVAS_WIDTH / 2, CANVAS_HEIGHT * 0.6);
      beamGrad.addColorStop(0, isLightOn ? 'rgba(255, 250, 220, 0.16)' : 'rgba(103, 168, 56, 0.08)');
      beamGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = beamGrad;
      ctx.beginPath();
      ctx.moveTo(CANVAS_WIDTH * 0.25, 0);
      ctx.lineTo(CANVAS_WIDTH * 0.75, 0);
      ctx.lineTo(CANVAS_WIDTH * 0.9, CANVAS_HEIGHT * 0.75);
      ctx.lineTo(CANVAS_WIDTH * 0.1, CANVAS_HEIGHT * 0.75);
      ctx.closePath();
      ctx.fill();
      ctx.restore();

      // 3. Floating Micro-Motes / Botanical Spores
      ctx.save();
      particles.forEach(p => {
        p.y -= p.speedY;
        p.flutter += 0.02;
        p.x += Math.sin(p.flutter) * 0.35;
        if (p.y < -10) {
          p.y = CANVAS_HEIGHT + 10;
          p.x = Math.random() * CANVAS_WIDTH;
        }
        ctx.fillStyle = `rgba(167, 243, 208, ${p.opacity * (isLightOn ? 1.5 : 1)})`;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fill();
      });
      ctx.restore();
    }

    // Render Plant Cutout with Organic Breathing & Sway
    function drawSimulatedPlant(timestamp) {
      if (!isImageLoaded || !plantImage.naturalWidth) return;

      const now = timestamp || performance.now();
      const swayAngle = Math.sin(now * 0.0011) * 0.012; // Gentle organic breeze
      const breatheY = Math.sin(now * 0.002) * 5; // Subtle vertical respiration

      ctx.save();
      const targetHeight = CANVAS_HEIGHT * 0.68;
      const targetWidth = (plantImage.naturalWidth / plantImage.naturalHeight) * targetHeight;
      const baseX = CANVAS_WIDTH / 2;
      const baseY = CANVAS_HEIGHT * 0.82;

      // Soft Shadow on chamber pedestal
      ctx.beginPath();
      ctx.ellipse(baseX, baseY + 4, targetWidth * 0.38, 16, 0, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(2, 6, 3, 0.65)';
      ctx.fill();

      // Transform with sway pivot at plant base
      ctx.translate(baseX, baseY);
      ctx.rotate(swayAngle);
      ctx.drawImage(
        plantImage,
        -targetWidth / 2,
        -targetHeight + breatheY,
        targetWidth,
        targetHeight
      );
      ctx.restore();
    }

    // Fast NDVI False-Color Shader (Normal Difference Vegetation Index)
    function applyNdviFilter() {
      const imgData = ctx.getImageData(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
      const data = imgData.data;
      const len = data.length;

      for (let i = 0; i < len; i += 4) {
        const r = data[i];
        const g = data[i + 1];
        const b = data[i + 2];
        const a = data[i + 3];

        if (a < 20 || (r < 25 && g < 35 && b < 25)) {
          // Dark chamber background -> Deep marine / indigo telemetry color
          data[i] = 12;
          data[i + 1] = 22;
          data[i + 2] = 40;
          continue;
        }

        // Chlorophyll NDVI ratio: (NIR - Red) / (NIR + Red)
        // High green reflection corresponds to active chlorophyll
        const diff = (g * 1.3) - (r * 0.8 + b * 0.2);
        const sum = (g * 1.3) + (r * 0.8 + b * 0.2) + 1.0;
        const ndvi = diff / sum;

        if (ndvi > 0.35) {
          // Ultra High Chlorophyll Activity -> Electric Emerald / Cyan
          data[i] = 16;
          data[i + 1] = 235;
          data[i + 2] = 150;
        } else if (ndvi > 0.15) {
          // Healthy Foliage -> Vivid Lime Green
          data[i] = 120;
          data[i + 1] = 220;
          data[i + 2] = 40;
        } else if (ndvi > 0.0) {
          // Moderate -> Amber / Yellow Gold
          data[i] = 234;
          data[i + 1] = 179;
          data[i + 2] = 8;
        } else {
          // Woody Stem / Soil / Pot -> Thermal Rust Orange-Red
          data[i] = 225;
          data[i + 1] = 65;
          data[i + 2] = 45;
        }
      }

      ctx.putImageData(imgData, 0, 0);
    }

    // Edge & Leaf Vein Extraction Shader
    function applyEdgeFilter() {
      const imgData = ctx.getImageData(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
      const src = imgData.data;
      const w = CANVAS_WIDTH;
      const h = CANVAS_HEIGHT;
      const output = ctx.createImageData(w, h);
      const dst = output.data;

      // Sobel kernel filter along horizontal and vertical gradients
      for (let y = 1; y < h - 1; y += 2) {
        for (let x = 1; x < w - 1; x += 2) {
          const idx = (y * w + x) * 4;
          // Grayscale luminance
          const l1 = (src[idx - 4] + src[idx - 3] + src[idx - 2]) / 3;
          const l2 = (src[idx + 4] + src[idx + 5] + src[idx + 6]) / 3;
          const l3 = (src[idx - w * 4] + src[idx - w * 4 + 1] + src[idx - w * 4 + 2]) / 3;
          const l4 = (src[idx + w * 4] + src[idx + w * 4 + 1] + src[idx + w * 4 + 2]) / 3;

          const dx = l2 - l1;
          const dy = l4 - l3;
          const edge = Math.min(255, Math.sqrt(dx * dx + dy * dy) * 3.2);

          const r = edge > 45 ? 40 : 8;
          const g = edge > 45 ? Math.min(255, edge * 1.8) : 16;
          const b = edge > 45 ? 120 : 20;

          // Fill 2x2 block for speed and thick aesthetic lines
          for (let dy2 = 0; dy2 < 2; dy2++) {
            for (let dx2 = 0; dx2 < 2; dx2++) {
              const targetIdx = ((y + dy2) * w + (x + dx2)) * 4;
              dst[targetIdx] = r;
              dst[targetIdx + 1] = g;
              dst[targetIdx + 2] = b;
              dst[targetIdx + 3] = 255;
            }
          }
        }
      }

      ctx.putImageData(output, 0, 0);
    }

    // Auxiliary Light Glow
    function applyFillLightEffect() {
      ctx.save();
      ctx.globalCompositeOperation = 'screen';
      const grad = ctx.createRadialGradient(
        CANVAS_WIDTH / 2, CANVAS_HEIGHT * 0.25, 40,
        CANVAS_WIDTH / 2, CANVAS_HEIGHT * 0.45, CANVAS_WIDTH * 0.6
      );
      grad.addColorStop(0, 'rgba(255, 245, 210, 0.42)');
      grad.addColorStop(0.5, 'rgba(254, 240, 138, 0.18)');
      grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
      ctx.restore();
    }

    // Main Animation Render Frame
    function renderFrame(timestamp) {
      if (!isRunning) return;

      // Handle Zoom Transformation
      ctx.save();
      if (zoomLevel > 1.0) {
        ctx.translate(CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2);
        ctx.scale(zoomLevel, zoomLevel);
        ctx.translate(-CANVAS_WIDTH / 2, -CANVAS_HEIGHT / 2);
      }

      if (mode === 'webcam' && video && video.readyState >= 2) {
        // Draw live webcam feed
        ctx.drawImage(video, 0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
      } else {
        // Draw simulated botanical feed
        drawGreenhouseBackground(timestamp);
        drawSimulatedPlant(timestamp);
      }

      // Apply Vision Filter
      if (visionFilter === 'ndvi') {
        applyNdviFilter();
      } else if (visionFilter === 'edge') {
        applyEdgeFilter();
      }

      // Apply Grow LED Spotlight
      if (isLightOn) {
        applyFillLightEffect();
      }

      ctx.restore();

      // Throttled HUD update (~250ms)
      const now = timestamp || performance.now();
      if (now - lastClockUpdate > 250) {
        lastClockUpdate = now;
        if (hudClock) hudClock.textContent = getFormattedTimestamp();
        if (hudParLight) {
          hudParLight.textContent = 'Not Available';
        }
      }

      animFrameId = requestAnimationFrame(renderFrame);
    }

    // Start/Resume Stream
    function resumeStream() {
      isRunning = true;
      if (standbyScreen) standbyScreen.style.display = 'none';
      if (camStatusPill) {
        camStatusPill.className = 'cam-status-pill pill-live';
      }
      if (camStatusText) camStatusText.textContent = 'LIVE OPTICAL FEED';
      if (btnToggleCam) btnToggleCam.classList.add('active');
      if (btnToggleCamText) btnToggleCamText.textContent = 'Pause Stream';

      if (animFrameId) cancelAnimationFrame(animFrameId);
      animFrameId = requestAnimationFrame(renderFrame);
    }

    // Pause Stream
    function pauseStream() {
      isRunning = false;
      if (standbyScreen) standbyScreen.style.display = 'flex';
      if (camStatusPill) {
        camStatusPill.className = 'cam-status-pill pill-standby';
      }
      if (camStatusText) camStatusText.textContent = 'STREAM PAUSED';
      if (btnToggleCam) btnToggleCam.classList.remove('active');
      if (btnToggleCamText) btnToggleCamText.textContent = 'Resume Stream';
      if (animFrameId) cancelAnimationFrame(animFrameId);
    }

    // Toggle Camera Power
    function toggleStream() {
      if (isRunning) {
        pauseStream();
      } else {
        resumeStream();
      }
    }

    // Switch Stream Source (Device Webcam vs Simulated IoT Camera)
    async function switchSource() {
      if (mode === 'simulated') {
        // Attempt connecting device webcam
        try {
          if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
            throw new Error('Webcam API not supported in this browser context');
          }
          const stream = await navigator.mediaDevices.getUserMedia({
            video: { width: { ideal: 1280 }, height: { ideal: 720 }, facingMode: 'environment' }
          });
          webcamStream = stream;
          if (video) {
            video.srcObject = stream;
            video.play();
          }
          mode = 'webcam';
          if (camSourceBadge) camSourceBadge.textContent = '📷 DEVICE WEBCAM';
          if (camSourceBtnText) camSourceBtnText.textContent = 'Use IoT Stream';
          if (typeof showToast === 'function') {
            showToast('📷 Device webcam connected to PlantVision™ AR viewfinder!');
          }
        } catch (err) {
          console.warn('Webcam access error:', err);
          if (typeof showToast === 'function') {
            showToast('⚠️ Webcam access unavailable. Defaulting to Simulated IoT Canopy stream.');
          }
          mode = 'simulated';
        }
      } else {
        // Disconnect webcam and return to simulated
        if (webcamStream) {
          webcamStream.getTracks().forEach(t => t.stop());
          webcamStream = null;
        }
        if (video) video.srcObject = null;
        mode = 'simulated';
        if (camSourceBadge) camSourceBadge.textContent = '🌿 IoT CANOPY CAM 01';
        if (camSourceBtnText) camSourceBtnText.textContent = 'Use Device Webcam';
        if (typeof showToast === 'function') {
          showToast('🌿 Switched to IoT Botanical Nursery Camera feed.');
        }
      }
      resumeStream();
    }

    // Cycle Zoom Step
    function cycleZoom() {
      const currentIndex = ZOOM_STEPS.indexOf(zoomLevel);
      const nextIndex = (currentIndex + 1) % ZOOM_STEPS.length;
      zoomLevel = ZOOM_STEPS[nextIndex];
      const zoomText = `${zoomLevel.toFixed(1)}x`;

      if (zoomBtnLabel) zoomBtnLabel.textContent = zoomText;
      if (camZoomIndicator) camZoomIndicator.textContent = `${zoomText} ZOOM`;
      if (typeof showToast === 'function') {
        showToast(`🔍 Optical zoom set to ${zoomText}`);
      }
    }

    // Toggle Auxiliary Grow Light
    function toggleGrowLight() {
      isLightOn = !isLightOn;
      if (btnToggleLight) {
        btnToggleLight.classList.toggle('active', isLightOn);
      }
      if (fillLightOverlay) {
        fillLightOverlay.style.display = isLightOn ? 'block' : 'none';
      }
      if (typeof showToast === 'function') {
        showToast(isLightOn ? '💡 4500K LED Horticultural Grow Light ON' : '💡 LED Grow Light OFF');
      }
    }

    // Toggle AR HUD Overlay
    function toggleHud() {
      isHudVisible = !isHudVisible;
      if (btnToggleHud) {
        btnToggleHud.classList.toggle('active', isHudVisible);
      }
      if (hudOverlay) {
        hudOverlay.style.display = isHudVisible ? 'block' : 'none';
      }
      if (laserScanline) {
        laserScanline.style.display = isHudVisible ? 'block' : 'none';
      }
      if (typeof showToast === 'function') {
        showToast(isHudVisible ? '🎯 AR Botanical HUD: Enabled' : '🎯 AR Botanical HUD: Hidden');
      }
    }

    // Set Vision Filter
    function setFilter(filter) {
      visionFilter = filter;
      filterButtons.forEach(btn => {
        btn.classList.toggle('active', btn.dataset.filter === filter);
      });
      const filterNames = {
        rgb: 'Standard RGB True-Color',
        ndvi: 'NDVI Chlorophyll False-Color',
        edge: 'Leaf Vein & Contour Isolation'
      };
      if (typeof showToast === 'function') {
        showToast(`🔬 Vision Filter: ${filterNames[filter] || filter.toUpperCase()}`);
      }
    }

    // Capture Snapshot & Generate AI Health Diagnostics
    function captureSnapshot() {
      // 1. Shutter Flash Animation
      if (shutterFlash) {
        shutterFlash.classList.add('flash');
        setTimeout(() => shutterFlash.classList.remove('flash'), 360);
      }

      // 2. Export High-Res Canvas Snapshot
      const snapUrl = canvas.toDataURL('image/png');

      // 3. Populate Diagnostic Drawer
      if (diagThumbImg) {
        diagThumbImg.src = snapUrl;
      }
      if (btnDownloadSnap) {
        btnDownloadSnap.href = snapUrl;
        const safeName = (currentPlant?.potName || currentPlant?.name || 'plant').toLowerCase().replace(/[^a-z0-9]/g, '_');
        btnDownloadSnap.download = `plantzone_scan_${safeName}_${Date.now()}.png`;
      }
      if (diagTimestamp) {
        diagTimestamp.textContent = `Scanned: ${new Date().toLocaleTimeString()} • Optical Sensor Confidence: 99.4%`;
      }

      // Dynamic AI Health Assessment based on plant state
      const plant = currentPlant || (gardenState && gardenState[0]) || {};
      const moisture = plant.moisture !== undefined ? plant.moisture : 85;
      const health = plant.health !== undefined ? plant.health : 98;
      const isFault = plant.isFaulty;

      let scoreHeading = 'Canopy Health: Exceptional';
      let scoreDesc = 'Leaf cell turgor and chlorophyll reflectance indicate optimal photosynthesis and vigorous root hydration.';
      let chlorophyll = 'High (682nm)';
      let pests = '0.0% (Clean)';
      let transpiration = 'Normal Balanced (18.4 g/h)';
      let advice = 'Foliage cellular integrity is prime. Current soil moisture aligns with healthy transpiration. Maintain regular automated irrigation schedule.';

      if (isFault) {
        scoreHeading = 'Sensor Anomaly Detected';
        scoreDesc = 'Optical sensors report high foliage integrity, but soil probe open circuit detected. Verify physical wire terminal.';
        advice = 'Inspect probe pin connections on Arduino Nano A0/A1.';
      } else if (moisture < 40) {
        scoreHeading = 'Hydration Deficit Detected';
        scoreDesc = 'Slight incipient leaf tip curling observed under optical scanning. Chlorophyll reflectance is shifting toward mild moisture stress.';
        chlorophyll = 'Moderate (640nm)';
        transpiration = 'Reduced (8.2 g/h)';
        advice = 'Moisture has dropped below 40% threshold. Recommended: Trigger a quick water pulse using the "💧 Quick Water Plant" button.';
      } else if (moisture > 92) {
        scoreHeading = 'Soil Near Saturation';
        scoreDesc = 'Foliage is fully turgid with peak transpiration. Cellular stomata are wide open.';
        chlorophyll = 'Peak (690nm)';
        transpiration = 'Elevated (24.1 g/h)';
        advice = 'Soil moisture is high. Allow 24-48 hours before supplementary misting to ensure root oxygenation.';
      }

      if (diagScoreVal) diagScoreVal.textContent = `${health}%`;
      if (diagScoreHeading) diagScoreHeading.textContent = scoreHeading;
      if (diagScoreDesc) diagScoreDesc.textContent = scoreDesc;
      if (diagChlorophyll) diagChlorophyll.textContent = chlorophyll;
      if (diagPests) diagPests.textContent = pests;
      if (diagTranspiration) diagTranspiration.textContent = transpiration;
      if (diagAdvice) diagAdvice.textContent = advice;

      // Reveal Drawer smoothly
      if (diagDrawer) {
        diagDrawer.style.display = 'block';
        diagDrawer.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      }

      if (typeof showToast === 'function') {
        showToast('📸 Snapshot captured! AI Foliage Health Diagnostic Report generated.');
      }
    }

    // Attach Event Listeners
    if (btnToggleCam) btnToggleCam.addEventListener('click', toggleStream);
    if (btnStandbyStart) btnStandbyStart.addEventListener('click', resumeStream);
    if (btnSwitchSource) btnSwitchSource.addEventListener('click', switchSource);
    if (btnCycleZoom) btnCycleZoom.addEventListener('click', cycleZoom);
    if (btnToggleLight) btnToggleLight.addEventListener('click', toggleGrowLight);
    if (btnToggleHud) btnToggleHud.addEventListener('click', toggleHud);
    if (btnCapture) btnCapture.addEventListener('click', captureSnapshot);

    filterButtons.forEach(btn => {
      btn.addEventListener('click', () => {
        setFilter(btn.dataset.filter);
      });
    });

    if (btnCloseDiag) {
      btnCloseDiag.addEventListener('click', () => {
        if (diagDrawer) diagDrawer.style.display = 'none';
      });
    }

    if (btnRetakeScan) {
      btnRetakeScan.addEventListener('click', () => {
        if (diagDrawer) diagDrawer.style.display = 'none';
        setTimeout(captureSnapshot, 200);
      });
    }

    // Live Recording Clock Timer Increment
    setInterval(() => {
      if (isRunning) {
        recSeconds++;
        if (hudRecTimer) hudRecTimer.textContent = formatTimer(recSeconds);
      }
    }, 1000);

    // Initial Plant Sync
    if (gardenState && gardenState.length > 0) {
      syncPlant(gardenState[activeGardenPlantIndex] || gardenState[0], activeGardenPlantIndex);
    } else {
      syncPlant(null, 0);
    }

    // Kick off animation loop
    requestAnimationFrame(renderFrame);

    return {
      syncPlant,
      resumeStream,
      pauseStream,
      toggleStream,
      captureSnapshot,
      setFilter,
      cycleZoom,
      toggleGrowLight,
      toggleHud
    };
  })();

  window.PlantVision = PlantVision;

  // ---------------- Wizard: "ADD PLANTS TO YOUR GARDEN" ----------------
  function openAddPlantWizard() {
    selectedPlantForGarden = null;
    wizardStep1.style.display = 'block';
    wizardStep2.style.display = 'none';

    // Check capacity (since user has only 2 sensors, maximum 2 plants)
    const isFull = gardenState.length >= MAX_GARDEN_PLANTS;
    if (wizardCapacityAlert) {
      wizardCapacityAlert.style.display = isFull ? 'flex' : 'none';
    }
    if (wizardPlantsGrid) {
      wizardPlantsGrid.style.display = isFull ? 'none' : 'grid';
    }

    addGardenPlantModal.classList.add('active');
    document.body.style.overflow = 'hidden';
  }

  function closeAddPlantWizard() {
    addGardenPlantModal.classList.remove('active');
    document.body.style.overflow = '';
  }

  if (addPlantNavBtn) addPlantNavBtn.addEventListener('click', openAddPlantWizard);
  if (closeAddPlantModalBtn) closeAddPlantModalBtn.addEventListener('click', closeAddPlantWizard);
  if (wzCancelBtn) wzCancelBtn.addEventListener('click', closeAddPlantWizard);
  if (gardenAddPlantBtn) gardenAddPlantBtn.addEventListener('click', openAddPlantWizard);
  if (emptyGardenAddBtn) emptyGardenAddBtn.addEventListener('click', openAddPlantWizard);

  if (wizardViewGardenBtn) {
    wizardViewGardenBtn.addEventListener('click', () => {
      closeAddPlantWizard();
      openGardenModal();
    });
  }

  addGardenPlantModal.addEventListener('click', (e) => {
    if (e.target === addGardenPlantModal) closeAddPlantWizard();
  });

  // Step 1: Plant Selection
  document.querySelectorAll('.wizard-plant-card').forEach(card => {
    card.addEventListener('click', () => {
      if (gardenState.length >= MAX_GARDEN_PLANTS) {
        showToast('⚠️ Maximum 2 plants reached! You have only 2 sensors (SOIL SENSOR 1 & SOIL SENSOR 2).');
        return;
      }

      const plantId = card.dataset.id;
      const plantName = card.dataset.name;
      const plantCat = card.dataset.cat;
      const plantImg = card.dataset.img;

      selectedPlantForGarden = {
        id: plantId,
        name: plantName,
        cat: plantCat,
        img: plantImg
      };

      // Populate Step 2 banner
      wzSelectedImg.src = plantImg;
      wzSelectedImg.alt = plantName;
      wzSelectedTitle.textContent = plantName;
      wzSelectedCat.textContent = `${plantCat} • Ready to cultivate`;

      // Reset Pot Name input and provide contextual placeholder
      if (wzPotNameInput) {
        wzPotNameInput.value = '';
        const shortName = plantName.split('(')[0].trim();
        wzPotNameInput.placeholder = `e.g. Living Room ${shortName} Pot`;
      }

      // Configure sensor availability (Mutual Exclusivity: 1 plant = 1 sensor)
      const usage = getSensorUsage();

      // Sensor 1 configuration
      if (usage['SOIL SENSOR 1']) {
        sensorCard1.classList.add('disabled');
        sensorCard1.classList.remove('active');
        soilSensor1Radio.disabled = true;
        soilSensor1Radio.checked = false;
        sensor1StatusBadge.className = 'sensor-status-badge in-use';
        sensor1StatusBadge.textContent = `In use by ${usage['SOIL SENSOR 1']}`;
      } else {
        sensorCard1.classList.remove('disabled');
        soilSensor1Radio.disabled = false;
        sensor1StatusBadge.className = 'sensor-status-badge available';
        sensor1StatusBadge.textContent = 'Available';
      }

      // Sensor 2 configuration
      if (usage['SOIL SENSOR 2']) {
        sensorCard2.classList.add('disabled');
        sensorCard2.classList.remove('active');
        soilSensor2Radio.disabled = true;
        soilSensor2Radio.checked = false;
        sensor2StatusBadge.className = 'sensor-status-badge in-use';
        sensor2StatusBadge.textContent = `In use by ${usage['SOIL SENSOR 2']}`;
      } else {
        sensorCard2.classList.remove('disabled');
        soilSensor2Radio.disabled = false;
        sensor2StatusBadge.className = 'sensor-status-badge available';
        sensor2StatusBadge.textContent = 'Available';
      }

      // Auto-select whichever sensor is free
      if (!soilSensor1Radio.disabled) {
        soilSensor1Radio.checked = true;
        sensorCard1.classList.add('active');
        sensorCard2.classList.remove('active');
      } else if (!soilSensor2Radio.disabled) {
        soilSensor2Radio.checked = true;
        sensorCard2.classList.add('active');
        sensorCard1.classList.remove('active');
      }

      // Transition to Step 2
      wizardStep1.style.display = 'none';
      wizardStep2.style.display = 'block';

      if (usage['SOIL SENSOR 1']) {
        showToast(`SOIL SENSOR 1 is in use by "${usage['SOIL SENSOR 1']}". Assigned to SOIL SENSOR 2.`);
      } else if (usage['SOIL SENSOR 2']) {
        showToast(`SOIL SENSOR 2 is in use by "${usage['SOIL SENSOR 2']}". Assigned to SOIL SENSOR 1.`);
      } else {
        showToast(`Selected "${plantName}". Choose 1 available sensor.`);
      }
    });
  });

  // Step 2: Back Button
  if (wzBackBtn) {
    wzBackBtn.addEventListener('click', () => {
      wizardStep2.style.display = 'none';
      wizardStep1.style.display = 'block';
    });
  }

  // Sensor Selection (Radio single-choice logic with exclusivity check)
  function selectSensorOption(sensorName) {
    const usage = getSensorUsage();

    if (sensorName === 'SOIL SENSOR 1') {
      if (usage['SOIL SENSOR 1']) {
        showToast(`⚠️ SOIL SENSOR 1 is already in use by "${usage['SOIL SENSOR 1']}". You must use SOIL SENSOR 2.`);
        return;
      }
      soilSensor1Radio.checked = true;
      sensorCard1.classList.add('active');
      sensorCard2.classList.remove('active');
    } else if (sensorName === 'SOIL SENSOR 2') {
      if (usage['SOIL SENSOR 2']) {
        showToast(`⚠️ SOIL SENSOR 2 is already in use by "${usage['SOIL SENSOR 2']}". You must use SOIL SENSOR 1.`);
        return;
      }
      soilSensor2Radio.checked = true;
      sensorCard2.classList.add('active');
      sensorCard1.classList.remove('active');
    }

    if (wzPotNameSection) {
      wzPotNameSection.classList.add('highlight');
      setTimeout(() => wzPotNameSection.classList.remove('highlight'), 1200);
    }
  }

  if (sensorCard1) {
    sensorCard1.addEventListener('click', (e) => {
      e.preventDefault();
      selectSensorOption('SOIL SENSOR 1');
    });
  }

  if (sensorCard2) {
    sensorCard2.addEventListener('click', (e) => {
      e.preventDefault();
      selectSensorOption('SOIL SENSOR 2');
    });
  }

  // Step 2: Save to Garden
  if (wzSavePlantBtn) {
    wzSavePlantBtn.addEventListener('click', () => {
      if (!selectedPlantForGarden) {
        showToast('Please select a plant first.');
        return;
      }

      if (gardenState.length >= MAX_GARDEN_PLANTS) {
        showToast('⚠️ Maximum 2 plants reached! You have only 2 sensors in total.');
        return;
      }

      let chosenSensor = null;
      if (soilSensor1Radio && soilSensor1Radio.checked && !soilSensor1Radio.disabled) {
        chosenSensor = 'SOIL SENSOR 1';
      } else if (soilSensor2Radio && soilSensor2Radio.checked && !soilSensor2Radio.disabled) {
        chosenSensor = 'SOIL SENSOR 2';
      }

      if (!chosenSensor) {
        showToast('⚠️ Please select an available soil sensor for this plant.');
        return;
      }

      const usage = getSensorUsage();
      if (usage[chosenSensor]) {
        showToast(`⚠️ ${chosenSensor} is already in use by "${usage[chosenSensor]}". Please pick the other sensor.`);
        return;
      }

      const enteredPotName = wzPotNameInput ? wzPotNameInput.value.trim() : '';
      const finalPotName = enteredPotName || `${selectedPlantForGarden.name.split('(')[0].trim()} Pot`;

      const locations = ['Living Room Corner', 'Balcony Garden', 'Study Table', 'Master Bedroom', 'Sunny Patio'];
      const randomLoc = locations[Math.floor(Math.random() * locations.length)];

      const chosenPump = chosenSensor.includes('1') ? 'PUMP 1' : 'PUMP 2';

      const newGardenItem = {
        id: Date.now(),
        potName: finalPotName,
        name: selectedPlantForGarden.name,
        cat: selectedPlantForGarden.cat,
        img: selectedPlantForGarden.img,
        sensor: chosenSensor,
        sensors: [chosenSensor],
        pump: chosenPump,
        moisture: null,
        temperature: null,
        humidity: null,
        ph: null,
        health: 98,
        location: randomLoc,
        lastWatered: 'Never'
      };

      gardenState.push(newGardenItem);
      saveGarden();
      renderGarden();
      closeAddPlantWizard();

      // Immediately open Garden Modal & show inspection screen for newly saved plant!
      openGardenModal();
      openPlantDetail(gardenState.length - 1);

      showToast(`🌱 Added "${newGardenItem.potName}" to Garden connected to ${chosenSensor} & ${chosenPump}! Inspecting plant & benefits.`);
    });
  }

  // Global ESC key listener for modals & drawers
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeSearch();
      closeSettings();
      closeQuickView();
      closeAddPlantWizard();
      closeGardenModal();
      if (videoModal && videoModal.classList.contains('active')) {
        videoModal.classList.remove('active');
        document.body.style.overflow = '';
      }
    }
  });

  // Expose global interface for Hardware (Web Serial / Web Bluetooth) integrations
  window.PlantZoneApp = {
    showToast,
    isHardwareConnected,
    saveGarden,
    renderGarden,
    openPlantDetail,
    openGardenModal,
    openSettings,
    closeSettings,
    updateSettingsUI,
    updateInspectPageTelemetry,
    activateDryPump3: async (seconds = 5) => {
      const durSec = typeof seconds === 'number' && seconds > 0 ? seconds : 5;
      const durationMs = Math.round(durSec * 1000);
      const c = document.getElementById('pumpCircle3');
      if (c) {
        c.classList.add('pump-watering-active');
        setTimeout(() => c.classList.remove('pump-watering-active'), durationMs);
      }
      if (window.HardwareManager && typeof window.HardwareManager.sendCommand === 'function') {
        await window.HardwareManager.sendCommand('D');
        await new Promise(r => setTimeout(r, 100));
        await window.HardwareManager.sendCommand('3', durationMs);
      } else if (window.isSimulationMode && typeof window.sendSimCommand === 'function') {
        window.sendSimCommand('3', durationMs);
      }
      showToast(`🌵 Calibrated DRY & Turned ON Pump 3 for ${durSec}s!`);
    },
    onHardwareConnectionChange: () => {
      const isConn = isHardwareConnected();
      if (!isConn) {
        gardenState.forEach(p => {
          p.liveTelemetry = false;
        });
      }
      if (gardenDetailView && gardenDetailView.style.display !== 'none' && gardenState[activeGardenPlantIndex]) {
        updateInspectPageTelemetry(gardenState[activeGardenPlantIndex]);
        if (window.PlantVision && typeof window.PlantVision.syncPlant === 'function') {
          window.PlantVision.syncPlant(gardenState[activeGardenPlantIndex], activeGardenPlantIndex);
        }
      }
      renderGarden();
      updateSettingsUI();
    },
    getGardenState: () => gardenState,
    setPumpState: (pumpNum, isOn) => {
      const circle = document.getElementById(`pumpCircle${pumpNum}`);
      if (circle) {
        if (isOn) {
          circle.classList.add('pump-watering-active');
        } else {
          circle.classList.remove('pump-watering-active');
        }
      }
    },
    updateTelemetry: (data) => {
      if (!gardenState || gardenState.length === 0) return;

      // Find the specific plant connected to this sensor
      let targetIdx = -1;
      if (data.sensorName) {
        targetIdx = gardenState.findIndex(p =>
          (p.sensor && p.sensor.toUpperCase() === data.sensorName.toUpperCase()) ||
          (p.sensors && p.sensors.some(s => s.toUpperCase() === data.sensorName.toUpperCase()))
        );
      }
      if (targetIdx === -1 && typeof data.sensorIndex === 'number' && gardenState[data.sensorIndex]) {
        targetIdx = data.sensorIndex;
      }
      if (targetIdx === -1 && typeof activeGardenPlantIndex === 'number' && gardenState[activeGardenPlantIndex]) {
        targetIdx = activeGardenPlantIndex;
      }
      if (targetIdx === -1) targetIdx = 0;

      const plant = gardenState[targetIdx];
      if (!plant) return;

      let hasChange = false;

      // Soil Moisture
      if (data.isFaulty) {
        plant.isFaulty = true;
        plant.moisture = null;
        plant.liveTelemetry = true;
        hasChange = true;
      } else if (typeof data.moisture === 'number' && !isNaN(data.moisture)) {
        plant.isFaulty = false;
        plant.moisture = Math.min(100, Math.max(0, Math.round(data.moisture)));
        plant.liveTelemetry = true;
        hasChange = true;
      }

      // Atmosphere Temperature (DHT11)
      if (data.isTempFault) {
        plant.isTempFault = true;
        plant.temperature = null;
        plant.liveTelemetry = true;
        hasChange = true;
      } else if (typeof data.temperature === 'number' && !isNaN(data.temperature)) {
        plant.isTempFault = false;
        plant.temperature = Number(data.temperature.toFixed(1));
        plant.liveTelemetry = true;
        hasChange = true;
      }

      // Environment Humidity (DHT11)
      if (data.isHumFault) {
        plant.isHumFault = true;
        plant.humidity = null;
        plant.liveTelemetry = true;
        hasChange = true;
      } else if (typeof data.humidity === 'number' && !isNaN(data.humidity)) {
        plant.isHumFault = false;
        plant.humidity = Number(data.humidity.toFixed(1));
        plant.liveTelemetry = true;
        hasChange = true;
      }

      // Raw ADC
      if (typeof data.rawADC === 'number') {
        plant.rawADC = data.rawADC;
        hasChange = true;
      }

      // Soil pH (only if genuine reading sent from hardware)
      if (typeof data.ph === 'number' && !isNaN(data.ph)) {
        plant.ph = Number(data.ph.toFixed(1));
        hasChange = true;
      }

      // Mode
      if (data.mode) {
        window.arduinoMode = data.mode;
        updateSettingsUI();
      }

      if (hasChange) {
        plant.lastWatered = 'Live Telemetry';
        saveGarden();
        renderGarden();

        if (gardenDetailView && gardenDetailView.style.display !== 'none' && targetIdx === activeGardenPlantIndex) {
          updateInspectPageTelemetry(plant);
          if (window.PlantVision && typeof window.PlantVision.syncPlant === 'function') {
            window.PlantVision.syncPlant(plant, targetIdx);
          }
        }
      }
    },
    plantVision: PlantVision
  };
  window.showToast = showToast;

  // Initial garden render
  renderGarden();

  // URL Hash handling for direct testing
  if (window.location.hash === '#open-add-plant') {
    openAddPlantWizard();
  } else if (window.location.hash === '#open-wizard-step2') {
    openAddPlantWizard();
    const firstCard = document.querySelector('.wizard-plant-card');
    if (firstCard) firstCard.click();
  } else if (window.location.hash === '#open-garden') {
    openGardenModal();
  } else if (window.location.hash === '#open-garden-detail') {
    openGardenModal();
    openPlantDetail(0);
  } else if (window.location.hash === '#test-2plants') {
    if (gardenState.length < 2) {
      gardenState.push({
        id: Date.now(),
        potName: 'Tribal Snake Pot',
        name: 'SNAKE PLANT (Sansevieria)',
        cat: 'Trending Plants',
        img: 'assets/images/tribal_snake_pot_transparent.png',
        sensor: 'SOIL SENSOR 2',
        sensors: ['SOIL SENSOR 2'],
        moisture: 72,
        temperature: 24,
        ph: 6.8,
        health: 99,
        location: 'Sunny Balcony',
        lastWatered: '1 day ago'
      });
      saveGarden();
    }
    openGardenModal();
    openPlantDetail(1);
  }
});

