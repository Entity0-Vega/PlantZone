/**
 * Garden Hardware Integration (Arduino Nano & Bluetooth)
 * Connects over Chrome Web Serial API (Arduino Nano USB) and Web Bluetooth API
 * Updates live telemetry to PlantZone dashboard
 */

const modal      = document.querySelector('.modal');
const listView   = document.getElementById('list-view');
const detailView = document.getElementById('detail-view');
const dConnect   = document.getElementById('d-connect');
const statusText = document.getElementById('status');
const FADE       = matchMedia('(prefers-reduced-motion: reduce)').matches ? 0 : 200;

const info = {
  'Arduino Nano': {
    desc: 'Connect over USB serial.',
    steps: ['Plug the Nano into your PC with a USB cable', 'Select the COM port when prompted', 'Set the baud rate to 9600']
  },
  'Bluetooth': {
    desc: 'Connect wirelessly to a nearby device.',
    steps: ['Turn on Bluetooth on your PC and the device', 'Put the device in pairing mode', 'Pick it from the list when it appears']
  }
};

// Hardware State
let currentHardwareType = 'Arduino Nano';
let activeSerialPort = null;
let serialReader = null;
let serialKeepReading = false;
let activeBluetoothDevice = null;
let activeBluetoothServer = null;
let bluetoothChar = null;

function notify(message, type = 'info') {
  if (window.PlantZoneApp && typeof window.PlantZoneApp.showToast === 'function') {
    window.PlantZoneApp.showToast(message, type);
  } else if (typeof window.showToast === 'function') {
    window.showToast(message, type);
  } else {
    const t = document.getElementById('toast');
    if (t) {
      t.textContent = message;
      t.className = 'toast';
      if (type === 'error') t.classList.add('toast-error');
      else if (type === 'warning') t.classList.add('toast-warning');
      t.classList.add('show');
      setTimeout(() => t.classList.remove('show'), 3500);
    }
  }
}

function updateConnectionUI() {
  const isArduinoConn = !!activeSerialPort;
  const isBtConn = !!(activeBluetoothDevice && activeBluetoothDevice.gatt && activeBluetoothDevice.gatt.connected);

  // Update List View items
  document.querySelectorAll('.wallet').forEach(btn => {
    const name = btn.dataset.name;
    if (name === 'Arduino Nano') {
      btn.setAttribute('aria-pressed', isArduinoConn ? 'true' : 'false');
    } else if (name === 'Bluetooth') {
      btn.setAttribute('aria-pressed', isBtConn ? 'true' : 'false');
    }
  });

  // Update status message
  if (statusText) {
    if (window.isSimulationMode) {
      statusText.textContent = `✓ Virtual IoT Simulation Active (Simulated 9600 baud)`;
      statusText.style.color = '#0284c7';
    } else if (isArduinoConn && isBtConn) {
      statusText.textContent = `✓ Arduino Nano (Serial) & Bluetooth connected`;
      statusText.style.color = '#22c55e';
    } else if (isArduinoConn) {
      statusText.textContent = `✓ Arduino Nano connected (Serial 9600 baud)`;
      statusText.style.color = '#22c55e';
    } else if (isBtConn) {
      statusText.textContent = `✓ Bluetooth connected (${activeBluetoothDevice.name || 'Wireless Device'})`;
      statusText.style.color = '#22c55e';
    } else {
      statusText.textContent = '⚠️ Arduino not connected. Connect via USB or Bluetooth.';
      statusText.style.color = '#ef4444';
    }
  }

  // Update Detail View Connect Button
  if (dConnect) {
    const isCurrentConnected = (currentHardwareType === 'Arduino Nano' && isArduinoConn) ||
                               (currentHardwareType === 'Bluetooth' && isBtConn);
    dConnect.textContent = isCurrentConnected ? 'Connected, Go to Garden' : 'Connect';
  }

  // Keep Settings Modal hardware status pill synchronized
  if (window.PlantZoneApp && typeof window.PlantZoneApp.updateSettingsUI === 'function') {
    window.PlantZoneApp.updateSettingsUI();
  }
  if (window.PlantZoneApp && typeof window.PlantZoneApp.onHardwareConnectionChange === 'function') {
    window.PlantZoneApp.onHardwareConnectionChange(isArduinoConn || isBtConn);
  }
}

function swap(from, to, after){
  from.classList.add('fading');
  setTimeout(() => {
    from.hidden = true;
    from.classList.remove('fading');
    to.hidden = false;
    to.classList.add('fading');
    to.offsetHeight;                    // force reflow so the fade-in runs
    to.classList.remove('fading');
    after && after();
  }, FADE);
}

document.querySelectorAll('.wallet').forEach(btn => {
  btn.addEventListener('click', () => {
    const name = btn.dataset.name;
    const data = info[name];
    currentHardwareType = name;

    document.getElementById('d-title').textContent = name;
    document.getElementById('d-desc').textContent  = data.desc;
    document.getElementById('d-icon').innerHTML    = btn.querySelector('svg').outerHTML;
    document.getElementById('d-steps').innerHTML   = data.steps.map(s => `<li>${s}</li>`).join('');

    updateConnectionUI();

    swap(listView, detailView, () => {
      modal.setAttribute('aria-labelledby', 'd-title');
      document.getElementById('d-title').focus();
    });
  });
});

document.getElementById('back').addEventListener('click', () => {
  swap(detailView, listView, () => {
    modal.setAttribute('aria-labelledby', 't');
    updateConnectionUI();
    document.querySelector('.wallet').focus();
  });
});

// ---------------- Telemetry Parser ----------------
function handleTelemetryLine(rawLine) {
  if (!rawLine || typeof rawLine !== 'string') return;
  const line = rawLine.trim();
  if (!line) return;

  // 1. PlantoPRO Telemetry Output:
  // "SOIL1=78%  SOIL2=64%  TEMP=24.5C  HUMIDITY=55.0%  MODE=AUTO  BT=CONNECTED  RAW1=420  RAW2=510"
  // "SOIL1=ERR  SOIL2=88%  TEMP=23.0C  HUMIDITY=50.0%  MODE=AUTO  BT=STANDBY  RAW1=20  RAW2=340"
  if (/SOIL1\s*=|SOIL2\s*=/i.test(line)) {
    const s1Match = line.match(/SOIL1\s*=\s*(?:(\d+(?:\.\d+)?)|(ERR))%?/i);
    const s2Match = line.match(/SOIL2\s*=\s*(?:(\d+(?:\.\d+)?)|(ERR))%?/i);
    const tempMatch = line.match(/TEMP\s*=\s*(?:(\d+(?:\.\d+)?)|(ERR))C?/i);
    const humMatch = line.match(/HUMIDITY\s*=\s*(?:(\d+(?:\.\d+)?)|(ERR))%?/i);
    const modeMatch = line.match(/MODE\s*=\s*(AUTO|MANUAL)/i);
    const btMatch = line.match(/BT\s*=\s*(CONNECTED|STANDBY)/i);
    const raw1Match = line.match(/RAW1\s*=\s*(\d+)/i);
    const raw2Match = line.match(/RAW2\s*=\s*(\d+)/i);

    const s1Moisture = s1Match && s1Match[1] ? parseFloat(s1Match[1]) : null;
    const s1Fault = s1Match && s1Match[2] === 'ERR';

    const s2Moisture = s2Match && s2Match[1] ? parseFloat(s2Match[1]) : null;
    const s2Fault = s2Match && s2Match[2] === 'ERR';

    const tempVal = tempMatch && tempMatch[1] ? parseFloat(tempMatch[1]) : null;
    const humVal = humMatch && humMatch[1] ? parseFloat(humMatch[1]) : null;
    const tempFault = tempMatch && tempMatch[2] === 'ERR';
    const humFault = humMatch && humMatch[2] === 'ERR';
    const modeVal = modeMatch ? modeMatch[1] : null;
    const btConnected = btMatch ? btMatch[1] === 'CONNECTED' : null;

    // Apply Sensor 1 (Soil Sensor 1 on A0)
    applyTelemetry({
      sensorName: 'SOIL SENSOR 1',
      sensorIndex: 0,
      moisture: s1Moisture,
      isFaulty: s1Fault,
      temperature: tempVal,
      isTempFault: tempFault,
      humidity: humVal,
      isHumFault: humFault,
      rawADC: raw1Match ? parseInt(raw1Match[1], 10) : null,
      mode: modeVal,
      btConnected
    });

    // Apply Sensor 2 (Soil Sensor 2 on A1)
    applyTelemetry({
      sensorName: 'SOIL SENSOR 2',
      sensorIndex: 1,
      moisture: s2Moisture,
      isFaulty: s2Fault,
      temperature: tempVal,
      isTempFault: tempFault,
      humidity: humVal,
      isHumFault: humFault,
      rawADC: raw2Match ? parseInt(raw2Match[1], 10) : null,
      mode: modeVal,
      btConnected
    });
    return;
  }

  // 2. Arduino Pump State Notifications: "Pump 1 ON", "Pump 2 OFF", "Pump 3 ON", etc.
  const pumpStateMatch = line.match(/Pump\s*([123])\s*(ON|OFF)/i);
  if (pumpStateMatch) {
    const pumpNum = parseInt(pumpStateMatch[1], 10);
    const isOn = pumpStateMatch[2].toUpperCase() === 'ON';
    if (window.PlantZoneApp && typeof window.PlantZoneApp.setPumpState === 'function') {
      window.PlantZoneApp.setPumpState(pumpNum, isOn);
    }
    return;
  }

  // 3. Arduino Manual Relay Trigger Confirmation
  if (/\[MANUAL\]\s*Triggering\s*Pump\s*([123])/i.test(line)) {
    const pMatch = line.match(/Pump\s*([123])/i);
    if (pMatch) {
      const pNum = parseInt(pMatch[1], 10);
      if (window.PlantZoneApp && typeof window.PlantZoneApp.setPumpState === 'function') {
        window.PlantZoneApp.setPumpState(pNum, true);
      }
    }
    return;
  }

  // 4. Emergency Stop
  if (/All pumps shut OFF immediately/i.test(line)) {
    if (window.PlantZoneApp && typeof window.PlantZoneApp.setPumpState === 'function') {
      window.PlantZoneApp.setPumpState(1, false);
      window.PlantZoneApp.setPumpState(2, false);
      window.PlantZoneApp.setPumpState(3, false);
    }
    notify('⚠️ Emergency Stop: All pumps shut OFF immediately.');
    return;
  }

  // 5. Arduino Firmware Boot Announcement
  if (/PlantoPRO Controller Online/i.test(line)) {
    notify('🌿 PlantoPRO Arduino Controller Online (Anti-Fake Precision Filter Active)!');
    return;
  }

  // 6. JSON Format Fallback: {"sensor": 1, "moisture": 78, "temperature": 23.5, "humidity": 55, "ph": 6.8}
  if (line.startsWith('{') && line.endsWith('}')) {
    try {
      const data = JSON.parse(line);
      if (data.moisture1 !== undefined || data.moisture2 !== undefined) {
        if (data.moisture1 !== undefined) {
          applyTelemetry({
            sensorIndex: 0,
            sensorName: 'SOIL SENSOR 1',
            moisture: parseFloat(data.moisture1),
            temperature: (data.temp !== undefined || data.temperature !== undefined) ? parseFloat(data.temp || data.temperature) : null,
            humidity: (data.humidity !== undefined || data.hum !== undefined) ? parseFloat(data.humidity || data.hum) : null,
            ph: data.ph !== undefined ? parseFloat(data.ph) : null
          });
        }
        if (data.moisture2 !== undefined) {
          applyTelemetry({
            sensorIndex: 1,
            sensorName: 'SOIL SENSOR 2',
            moisture: parseFloat(data.moisture2),
            temperature: (data.temp !== undefined || data.temperature !== undefined) ? parseFloat(data.temp || data.temperature) : null,
            humidity: (data.humidity !== undefined || data.hum !== undefined) ? parseFloat(data.humidity || data.hum) : null,
            ph: data.ph !== undefined ? parseFloat(data.ph) : null
          });
        }
        return;
      }
      const sIdx = (data.sensor == 2 || String(data.sensor).includes('2')) ? 1 : 0;
      applyTelemetry({
        sensorIndex: sIdx,
        sensorName: sIdx === 1 ? 'SOIL SENSOR 2' : 'SOIL SENSOR 1',
        moisture: data.moisture !== undefined ? parseFloat(data.moisture) : null,
        temperature: (data.temp !== undefined || data.temperature !== undefined) ? parseFloat(data.temp || data.temperature) : null,
        humidity: (data.humidity !== undefined || data.hum !== undefined) ? parseFloat(data.humidity || data.hum) : null,
        ph: data.ph !== undefined ? parseFloat(data.ph) : null
      });
    } catch (_) {}
    return;
  }

  // 7. Key-value line: "moisture: 79" or "moisture=79"
  const singleMoistureMatch = line.match(/^(?:soil\s*)?moisture\s*[:=]\s*(\d+(?:\.\d+)?)/i);
  if (singleMoistureMatch) {
    applyTelemetry({
      sensorName: 'SOIL SENSOR 1',
      sensorIndex: 0,
      moisture: parseFloat(singleMoistureMatch[1])
    });
    return;
  }
}

function applyTelemetry(data) {
  if (window.PlantZoneApp && typeof window.PlantZoneApp.updateTelemetry === 'function') {
    window.PlantZoneApp.updateTelemetry(data);
  }
}

// ---------------- Web Serial API (Arduino Nano) ----------------
async function readSerialStream(port) {
  serialKeepReading = true;
  const decoder = new TextDecoder();
  let buffer = '';

  while (port.readable && serialKeepReading) {
    try {
      serialReader = port.readable.getReader();
      while (true) {
        const { value, done } = await serialReader.read();
        if (done) break;
        if (value) {
          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split(/[\r\n]+/);
          buffer = lines.pop(); // keep remainder
          for (const line of lines) {
            if (line.trim()) handleTelemetryLine(line.trim());
          }
        }
      }
    } catch (err) {
      if (serialKeepReading && err.name !== 'NetworkError') {
        console.warn('Serial read warning:', err);
      }
      break;
    } finally {
      if (serialReader) {
        try {
          serialReader.releaseLock();
        } catch (_) {}
        serialReader = null;
      }
    }
  }
}

async function connectSerial() {
  if (!('serial' in navigator)) {
    notify('⚠️ Error: Web Serial API is not supported in this browser. Please use Chrome or Edge.', 'error');
    return;
  }

  let port;
  try {
    // MUST be called directly in the user click event to open Chrome's serial port selection popup
    port = await navigator.serial.requestPort();
  } catch (err) {
    if (err.name === 'NotFoundError') {
      // User cancelled port selection dialog
      notify('⚠️ Arduino not connected. Serial port selection was cancelled.', 'warning');
      return;
    }
    console.error('Serial port request error:', err);
    notify('⚠️ Error selecting serial port: ' + (err.message || err), 'error');
    return;
  }

  try {
    await port.open({ baudRate: 9600 });
  } catch (err) {
    console.error('Serial port open error:', err);
    notify('⚠️ Error: Could not open Arduino serial port (check if Arduino IDE Serial Monitor is open): ' + (err.message || err), 'error');
    return;
  }

  activeSerialPort = port;
  updateConnectionUI();
  notify('✓ Connected to Arduino Nano over Serial (9600 baud)! 🌿');

  readSerialStream(port);

  // ATmega328P resets on serial port connection (DTR toggle).
  // Wait 1.8 seconds for bootloader to finish, then send 'S' to query immediate telemetry.
  setTimeout(() => {
    if (activeSerialPort && window.HardwareManager) {
      window.HardwareManager.sendCommand('S');
    }
  }, 1800);
}

async function disconnectSerial() {
  serialKeepReading = false;
  if (serialReader) {
    try {
      await serialReader.cancel();
    } catch (_) {}
  }
  if (activeSerialPort) {
    try {
      await activeSerialPort.close();
    } catch (err) {
      console.warn('Error closing serial port:', err);
    }
    activeSerialPort = null;
  }
  updateConnectionUI();
  notify('⚠️ Arduino Nano disconnected.', 'warning');
}

if ('serial' in navigator) {
  navigator.serial.addEventListener('disconnect', (event) => {
    if (activeSerialPort && event.target === activeSerialPort) {
      disconnectSerial();
      notify('⚠️ Error: Arduino Nano USB cable was disconnected!', 'error');
    }
  });
}

// ---------------- Web Bluetooth API ----------------
async function setupBluetoothNotifications(server) {
  const decoder = new TextDecoder();
  let btBuffer = '';

  const handleCharValue = (e) => {
    const val = decoder.decode(e.target.value);
    btBuffer += val;
    const lines = btBuffer.split(/[\r\n]+/);
    btBuffer = lines.pop();
    for (const line of lines) {
      if (line.trim()) handleTelemetryLine(line.trim());
    }
  };

  // Try HM-10 UART Service
  try {
    const hmService = await server.getPrimaryService('0000ffe0-0000-1000-8000-00805f9b34fb');
    const hmChar = await hmService.getCharacteristic('0000ffe1-0000-1000-8000-00805f9b34fb');
    await hmChar.startNotifications();
    hmChar.addEventListener('characteristicvaluechanged', handleCharValue);
    bluetoothChar = hmChar;
    return;
  } catch (_) {}

  // Try Nordic UART Service (NUS)
  try {
    const nusService = await server.getPrimaryService('6e400001-b5a3-f393-e0a9-e50e24dcca9e');
    const nusTx = await nusService.getCharacteristic('6e400003-b5a3-f393-e0a9-e50e24dcca9e');
    await nusTx.startNotifications();
    nusTx.addEventListener('characteristicvaluechanged', handleCharValue);
    bluetoothChar = nusTx;
    return;
  } catch (_) {}

  // Try Environmental Sensing Service
  try {
    const envService = await server.getPrimaryService('environmental_sensing');
    // Try humidity
    try {
      const humChar = await envService.getCharacteristic('00002a6f-0000-1000-8000-00805f9b34fb');
      await humChar.startNotifications();
      humChar.addEventListener('characteristicvaluechanged', (e) => {
        const raw = e.target.value.getUint16(0, true) / 100;
        handleTelemetryLine(`moisture: ${Math.round(raw)}`);
      });
    } catch (_) {}
  } catch (_) {}
}

async function connectBluetooth() {
  if (!('bluetooth' in navigator)) {
    notify('⚠️ Error: Web Bluetooth API is not supported in this browser. Please use Google Chrome or Edge.', 'error');
    return;
  }

  let device;
  try {
    // MUST be called directly in the user click event to open Chrome's bluetooth chooser popup
    device = await navigator.bluetooth.requestDevice({
      acceptAllDevices: true,
      optionalServices: [
        '0000ffe0-0000-1000-8000-00805f9b34fb', // HM-10 UART
        '6e400001-b5a3-f393-e0a9-e50e24dcca9e', // Nordic UART
        'battery_service',
        'environmental_sensing',
        'device_information',
        'generic_access'
      ]
    });
  } catch (err) {
    if (err.name === 'NotFoundError') {
      // User cancelled device selection dialog
      notify('⚠️ Bluetooth not connected. Device selection was cancelled.', 'warning');
      return;
    }
    console.error('Bluetooth selection error:', err);
    notify('⚠️ Error selecting Bluetooth device: ' + (err.message || err), 'error');
    return;
  }

  try {
    device.addEventListener('gattserverdisconnected', () => {
      activeBluetoothDevice = null;
      activeBluetoothServer = null;
      bluetoothChar = null;
      updateConnectionUI();
      notify('⚠️ Bluetooth connection lost: Device disconnected.', 'error');
    });

    const server = await device.gatt.connect();
    activeBluetoothDevice = device;
    activeBluetoothServer = server;

    updateConnectionUI();
    notify(`✓ Connected to Bluetooth device: ${device.name || 'Plant Sensor'}! 🌿`);

    setupBluetoothNotifications(server);

    // Send 'S' command to request live telemetry immediately over Bluetooth
    setTimeout(() => {
      if (window.HardwareManager) {
        window.HardwareManager.sendCommand('S');
      }
    }, 1200);
  } catch (err) {
    console.error('Bluetooth GATT connection error:', err);
    notify('⚠️ Error connecting to Bluetooth GATT: ' + (err.message || err), 'error');
  }
}

function disconnectBluetooth() {
  if (activeBluetoothDevice && activeBluetoothDevice.gatt && activeBluetoothDevice.gatt.connected) {
    activeBluetoothDevice.gatt.disconnect();
  }
  activeBluetoothDevice = null;
  activeBluetoothServer = null;
  bluetoothChar = null;
  updateConnectionUI();
  notify('⚠️ Bluetooth disconnected.', 'warning');
}

// ---------------- Garden Navigation & Connect Button Handler ----------------
function goToGarden() {
  const closeGardenBlurBtn = document.getElementById('closeGardenBlurBtn');
  if (closeGardenBlurBtn) {
    closeGardenBlurBtn.click();
  } else {
    const blurContainer = document.getElementById('blurContainer');
    if (blurContainer) blurContainer.style.display = 'none';
  }

  if (window.PlantZoneApp && typeof window.PlantZoneApp.openGardenModal === 'function') {
    window.PlantZoneApp.openGardenModal();
  } else {
    const gardenNavBtn = document.getElementById('gardenNavBtn');
    if (gardenNavBtn) gardenNavBtn.click();
  }
}

// ONLY the connect button is used to open Chrome's popup requesting permission & hardware
if (dConnect) {
  dConnect.addEventListener('click', () => {
    const isArduino = currentHardwareType === 'Arduino Nano';
    const isBluetooth = currentHardwareType === 'Bluetooth';

    const isCurrentConnected = (isArduino && activeSerialPort) ||
                               (isBluetooth && activeBluetoothDevice && activeBluetoothDevice.gatt && activeBluetoothDevice.gatt.connected);

    // If already paired/connected, clicking takes user to their Garden
    if (isCurrentConnected) {
      goToGarden();
      return;
    }

    if (isArduino) {
      connectSerial();
    } else if (isBluetooth) {
      connectBluetooth();
    }
  });
}

async function writeRaw(charStr) {
  if (!charStr) return false;
  const isSerial = !!(activeSerialPort && activeSerialPort.writable);
  const isBt = !!(bluetoothChar && bluetoothChar.service);

  if (!isSerial && !isBt) {
    notify('⚠️ Error: Arduino is not connected! Connect USB or Bluetooth to send commands.', 'error');
    return false;
  }

  const data = new TextEncoder().encode(charStr);

  // Send to Serial if connected
  if (isSerial) {
    try {
      const writer = activeSerialPort.writable.getWriter();
      await writer.write(data);
      writer.releaseLock();
    } catch (err) {
      console.warn('Serial write error:', err);
      notify('⚠️ Error writing to Arduino Serial: ' + (err.message || err), 'error');
      return false;
    }
  }

  // Send to Bluetooth characteristic if writable
  if (isBt) {
    try {
      if (bluetoothChar.writeValueWithoutResponse) {
        await bluetoothChar.writeValueWithoutResponse(data);
      } else if (bluetoothChar.writeValue) {
        await bluetoothChar.writeValue(data);
      }
    } catch (err) {
      console.warn('Bluetooth write error:', err);
      notify('⚠️ Error writing to Bluetooth: ' + (err.message || err), 'error');
      return false;
    }
  }
  return true;
}

// ---------------- Hardware Manager (Sending commands & external access) ----------------
window.HardwareManager = {
  isConnected: () => !!window.isSimulationMode || !!activeSerialPort || !!(activeBluetoothDevice && activeBluetoothDevice.gatt && activeBluetoothDevice.gatt.connected),
  isArduinoConnected: () => !!activeSerialPort,
  isBluetoothConnected: () => !!(activeBluetoothDevice && activeBluetoothDevice.gatt && activeBluetoothDevice.gatt.connected),
  sendCommand: async (command, customDurationMs) => {
    if (!command) return false;
    if (window.isSimulationMode && typeof window.sendSimCommand === 'function') {
      window.sendSimCommand(command, customDurationMs);
      return true;
    }
    if (!window.HardwareManager.isConnected()) {
      notify('⚠️ Error: Arduino is not connected! Please connect via USB or Bluetooth.', 'error');
      return false;
    }
    let cmd = String(command).trim();

    // Map higher-level command strings to exact Arduino PlantoPRO firmware single-character codes:
    // '1' = Pump 1 (IN1) | '2' = Pump 2 (IN2) | '3' = Pump 3 (IN4 Manual) | 'A' = Auto | 'M' = Manual | 'X' = Stop | 'S' = Telemetry Query
    if (/pump\s*1|water.*1|^1$/i.test(cmd)) {
      cmd = '1';
    } else if (/pump\s*2|water.*2|^2$/i.test(cmd)) {
      cmd = '2';
    } else if (/pump\s*3|water.*3|^3$/i.test(cmd)) {
      cmd = '3';
      const dur = typeof customDurationMs === 'number' && customDurationMs > 0 ? customDurationMs : 3000;
      await writeRaw('3\n');
      if (dur > 3000) {
        let elapsed = 3000;
        const interval = setInterval(async () => {
          if (elapsed >= dur) {
            clearInterval(interval);
            await writeRaw('X\n');
          } else {
            await writeRaw('3\n');
            elapsed += 3000;
          }
        }, 3000);
      }
      return true;
    } else if (/water(?:_|\s*)all/i.test(cmd)) {
      await writeRaw('1\n');
      setTimeout(() => writeRaw('2\n'), 3200);
      return true;
    } else if (/stop|halt|emergency|^x$/i.test(cmd)) {
      cmd = 'X';
    } else if (/auto|^a$/i.test(cmd)) {
      cmd = 'A';
    } else if (/manual|^m$/i.test(cmd)) {
      cmd = 'M';
    } else if (/status|telemetry|query|\?|^s$/i.test(cmd)) {
      cmd = 'S';
    } else if (/calib|^c$/i.test(cmd)) {
      cmd = 'C';
    } else if (/dry|^d$/i.test(cmd)) {
      cmd = 'D';
    } else if (/wet|^w$/i.test(cmd)) {
      cmd = 'W';
    } else if (/reset|^r$/i.test(cmd)) {
      cmd = 'R';
    } else {
      cmd = cmd.charAt(0);
    }

    return await writeRaw(cmd + '\n');
  },
  triggerPump: (pumpNum) => window.HardwareManager.sendCommand(String(pumpNum)),
  queryTelemetry: () => window.HardwareManager.sendCommand('S'),
  disconnectSerial,
  disconnectBluetooth,
  disconnectAll: () => {
    if (window.isSimulationMode && typeof window.stopSimulation === 'function') {
      window.stopSimulation();
    }
    if (activeSerialPort) disconnectSerial();
    if (activeBluetoothDevice) disconnectBluetooth();
  }
};

window.handleTelemetryLine = handleTelemetryLine;

// Initial UI setup
updateConnectionUI();